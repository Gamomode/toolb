(function () {
  'use strict';

  var KEY = 'ai-reverse-workbench.v1';
  var listeners = [];
  var persistTimer = 0;
  var state;

  function pad(n) {
    return String(n).length < 2 ? '0' + n : String(n);
  }

  function stamp() {
    var d = new Date();
    return pad(d.getHours()) + ':' + pad(d.getMinutes()) + ':' + pad(d.getSeconds());
  }

  function lines(arr) {
    return arr.join('\n');
  }

  var SEED = [
    {
      path: '/srv/app/index.html',
      content: lines([
        '<!DOCTYPE html>',
        '<html lang="zh-CN">',
        '<head>',
        '  <meta charset="UTF-8">',
        '  <meta name="viewport" content="width=device-width, initial-scale=1">',
        '  <title>客户数据门户</title>',
        '  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/normalize.css@8.0.1/normalize.css">',
        '  <link rel="stylesheet" href="./style.css">',
        '</head>',
        '<body>',
        '  <div id="app"></div>',
        '  <script src="https://cdn.jsdelivr.net/npm/vue@3.4.21/dist/vue.global.prod.js"></script>',
        '  <script src="https://unpkg.com/axios@1.6.8/dist/axios.min.js"></script>',
        '  <script src="./main.js"></script>',
        '</body>',
        '</html>'
      ])
    },
    {
      path: '/srv/app/main.js',
      content: lines([
        '// 入口：初始化页面并拉取报表数据',
        'const API_BASE = "https://api.example.com/v1";',
        '',
        'async function loadReport(userId) {',
        '  const token = window.Api.sign({ uid: userId, ts: Date.now() });',
        '  const res = await fetch(API_BASE + "/report?uid=" + userId, {',
        '    headers: { "X-Token": token }',
        '  });',
        '  const data = await res.json();',
        '  localStorage.setItem("cache:" + userId, JSON.stringify(data));',
        '  return data;',
        '}',
        '',
        'function render(data) {',
        '  document.getElementById("app").textContent = JSON.stringify(data);',
        '}',
        '',
        'loadReport(10086).then(render).catch(function (e) {',
        '  console.error("load failed", e);',
        '  const cached = localStorage.getItem("cache:10086");',
        '  if (cached) render(JSON.parse(cached));',
        '});'
      ])
    },
    {
      path: '/srv/app/api.js',
      content: lines([
        '// 签名与请求封装',
        'window.Api = {',
        '  key: "s3cr3t-key",',
        '  sign(params) {',
        '    const raw = Object.keys(params).sort().map(function (k) {',
        '      return k + "=" + params[k];',
        '    }).join("&");',
        '    return CryptoJS.MD5(raw + this.key).toString();',
        '  },',
        '  request(path, body) {',
        '    return axios.post("https://api.example.com/v1" + path, body, {',
        '      headers: { "X-Client": btoa("web:" + Date.now()) }',
        '    });',
        '  }',
        '};'
      ])
    },
    {
      path: '/srv/app/plugin.js',
      content: lines([
        '// 授权校验模块',
        '(function () {',
        '  var p = "d2luZG93Ll9saWNlbnNlPSJvayI7";',
        '  eval(atob(p));',
        '  var el = document.createElement("script");',
        '  el.src = "https://static.example.com/analytics/track.min.js";',
        '  document.head.appendChild(el);',
        '})();'
      ])
    }
  ];

  function defaultState() {
    return {
      connection: {
        status: 'local',
        host: '',
        port: '8765',
        token: '',
        mode: 'local',
        latency: 0,
        lastSync: 0
      },
      files: SEED.map(function (f) {
        return { path: f.path, content: f.content, mtime: Date.now() };
      }),
      activeFile: null,
      logs: [],
      report: null,
      apk: {
        appName: 'AI 逆向工作台',
        packageName: 'com.offline.workbench',
        versionName: '1.0.0',
        versionCode: 1,
        lastBuild: 0
      }
    };
  }

  function load() {
    var raw = null;
    try {
      raw = JSON.parse(localStorage.getItem(KEY) || 'null');
    } catch (e) {
      raw = null;
    }
    if (!raw || !raw.files || !raw.files.length) return defaultState();
    var base = defaultState();
    return {
      connection: Object.assign(base.connection, raw.connection || {}),
      files: raw.files,
      activeFile: raw.activeFile || null,
      logs: Array.isArray(raw.logs) ? raw.logs.slice(-120) : [],
      report: raw.report || null,
      apk: Object.assign(base.apk, raw.apk || {})
    };
  }

  function persist() {
    try {
      localStorage.setItem(KEY, JSON.stringify(state));
    } catch (e) {
      /* 存储超限时静默失败，页面内数据仍然可用 */
    }
  }

  function commit() {
    clearTimeout(persistTimer);
    persistTimer = setTimeout(persist, 200);
    listeners.forEach(function (fn) {
      try {
        fn(state);
      } catch (e) {
        /* 单个订阅者异常不影响其它渲染 */
      }
    });
  }

  state = load();

  function find(path) {
    for (var i = 0; i < state.files.length; i++) {
      if (state.files[i].path === path) return state.files[i];
    }
    return null;
  }

  function cleanPath(p) {
    var s = String(p || '').trim().replace(/\\/g, '/');
    if (!s) return '';
    if (s.charAt(0) !== '/') s = '/' + s;
    return s.replace(/\/{2,}/g, '/').replace(/\.\./g, '');
  }

  var Store = {
    get: function () {
      return state;
    },

    subscribe: function (fn) {
      listeners.push(fn);
      return function () {
        listeners = listeners.filter(function (x) {
          return x !== fn;
        });
      };
    },

    addLog: function (text, level) {
      state.logs.push({ t: stamp(), level: level || 'info', text: String(text) });
      if (state.logs.length > 120) state.logs = state.logs.slice(-120);
      commit();
    },

    clearLogs: function () {
      state.logs = [];
      commit();
    },

    setConnection: function (patch) {
      state.connection = Object.assign({}, state.connection, patch || {});
      commit();
    },

    setReport: function (report) {
      state.report = report;
      commit();
    },

    setActiveFile: function (path) {
      state.activeFile = path;
      commit();
    },

    findFile: find,

    upsertFile: function (path, content) {
      var p = cleanPath(path);
      if (!p) return null;
      var f = find(p);
      if (f) {
        f.content = content;
        f.mtime = Date.now();
      } else {
        f = { path: p, content: content, mtime: Date.now() };
        state.files.push(f);
        state.files.sort(function (a, b) {
          return a.path.localeCompare(b.path);
        });
      }
      commit();
      return f;
    },

    removeFile: function (path) {
      state.files = state.files.filter(function (f) {
        return f.path !== path;
      });
      if (state.activeFile === path) state.activeFile = null;
      commit();
    },

    renameFile: function (from, to) {
      var f = find(from);
      var t = cleanPath(to);
      if (!f || !t) return;
      if (find(t)) return;
      f.path = t;
      state.files.sort(function (a, b) {
        return a.path.localeCompare(b.path);
      });
      commit();
    },

    stats: function () {
      var size = state.files.reduce(function (a, f) {
        return a + (f.content ? f.content.length : 0);
      }, 0);
      return { count: state.files.length, size: size };
    },

    setApk: function (patch) {
      state.apk = Object.assign({}, state.apk, patch || {});
      commit();
    },

    reset: function () {
      state = defaultState();
      commit();
      persist();
    },

    cleanPath: cleanPath,
    stamp: stamp
  };

  window.Store = Store;
})();