package com.lg.toolbox

import android.content.ContentValues
import android.content.Context
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.io.File

enum class ToolKind { HASH, SALT, CONVERT, ENCRYPT, GARBLED }

fun saveTextFile(ctx: Context, name: String, content: String): String {
    return try {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val values = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, name)
                put(MediaStore.Downloads.MIME_TYPE, "text/html")
            }
            val uri = ctx.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                ?: return "保存失败，请重试"
            ctx.contentResolver.openOutputStream(uri)?.use { it.write(content.toByteArray(Charsets.UTF_8)) }
            "已保存到「下载」文件夹：$name"
        } else {
            val dir = File(ctx.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS), "")
            dir.mkdirs()
            val f = File(dir, name)
            f.writeText(content, Charsets.UTF_8)
            "已保存：${f.absolutePath}"
        }
    } catch (e: Exception) {
        "保存失败：${e.message}"
    }
}

@Composable
fun ToolScreen(th: ThemeSpec, store: Store, kind: ToolKind, notify: (String) -> Unit) {
    var input by remember { mutableStateOf("") }
    var second by remember { mutableStateOf("") }
    var alg by remember { mutableStateOf("SHA-256") }
    var mode by remember { mutableStateOf("entity") }
    var result by remember { mutableStateOf("") }
    var isError by remember { mutableStateOf(false) }
    val clipboard = LocalClipboardManager.current
    val ctx = LocalContext.current

    fun run() {
        val text = input
        if (text.isBlank()) {
            result = when (kind) {
                ToolKind.CONVERT -> "请输入有效的十六进制字符串。"
                else -> "请先输入内容。"
            }
            isError = true
            return
        }
        isError = false
        when (kind) {
            ToolKind.HASH -> {
                result = try {
                    Logic.digestHex(alg, text).also { store.autoClaimDaily("d2") }
                } catch (e: Exception) {
                    isError = true; "计算失败：${e.message}"
                }
            }
            ToolKind.SALT -> {
                if (second.isBlank()) {
                    result = "请输入内容和盐值。"; isError = true; return
                }
                result = try {
                    Logic.pbkdf2Hex(text, second, alg)
                } catch (e: Exception) {
                    isError = true; "计算失败：${e.message}"
                }
            }
            ToolKind.CONVERT -> {
                result = Logic.hexToBase64(text.trim()) ?: run {
                    isError = true; "请输入有效的十六进制字符串。"
                }
                if (!isError) store.autoClaimDaily("d3")
            }
            ToolKind.ENCRYPT -> {
                result = Logic.buildEncryptedPage(text, second.ifBlank { null })
            }
            ToolKind.GARBLED -> {
                result = if (mode == "entity") Logic.toEntityGarbled(text) else Logic.toScriptGarbled(text)
            }
        }
    }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        Box(
            Modifier
                .fillMaxWidth()
                .background(th.panel, RoundedCornerShape(16.dp))
                .border(1.dp, th.line, RoundedCornerShape(16.dp))
                .padding(14.dp)
        ) {
            Column {
                Text(toolTitle(kind), fontSize = 15.sp, fontWeight = FontWeight.Bold, color = th.ink)
                Spacer(Modifier.height(10.dp))
                OutlinedTextField(
                    value = input,
                    onValueChange = { input = it },
                    label = { Text(toolHint(kind)) },
                    modifier = Modifier.fillMaxWidth(),
                    minLines = 4,
                    maxLines = 8
                )
                if (kind == ToolKind.SALT || kind == ToolKind.ENCRYPT) {
                    Spacer(Modifier.height(10.dp))
                    OutlinedTextField(
                        value = second,
                        onValueChange = { second = it },
                        label = { Text(if (kind == ToolKind.SALT) "盐值" else "访问密码（留空则无密码）") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
                if (kind == ToolKind.HASH || kind == ToolKind.SALT) {
                    Spacer(Modifier.height(10.dp))
                    Text("算法", fontSize = 13.sp, color = th.muted)
                    Spacer(Modifier.height(6.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        val algs = if (kind == ToolKind.HASH) listOf("MD5", "SHA-1", "SHA-256", "SHA-384", "SHA-512") else listOf("SHA-1", "SHA-256", "SHA-384", "SHA-512")
                        algs.forEach { a ->
                            val sel = a == alg
                            Box(
                                Modifier
                                    .background(if (sel) th.accent else th.accentSoft, RoundedCornerShape(999.dp))
                                    .clickable { alg = a }
                                    .padding(horizontal = 12.dp, vertical = 6.dp)
                            ) {
                                Text(a, fontSize = 12.sp, color = if (sel) Color.White else th.accent)
                            }
                        }
                    }
                }
                if (kind == ToolKind.GARBLED) {
                    Spacer(Modifier.height(10.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf("entity" to "实体编码（可还原）", "script" to "JS 混淆（不可逆）").forEach { (m, label) ->
                            val sel = m == mode
                            Box(
                                Modifier
                                    .background(if (sel) th.accent else th.accentSoft, RoundedCornerShape(999.dp))
                                    .clickable { mode = m }
                                    .padding(horizontal = 12.dp, vertical = 6.dp)
                            ) {
                                Text(label, fontSize = 12.sp, color = if (sel) Color.White else th.accent)
                            }
                        }
                    }
                }
                Spacer(Modifier.height(14.dp))
                Button(
                    onClick = { run() },
                    colors = ButtonDefaults.buttonColors(containerColor = th.accent),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        when (kind) {
                            ToolKind.HASH -> "计算哈希"
                            ToolKind.SALT -> "计算慢哈希"
                            ToolKind.CONVERT -> "转换为 Base64"
                            ToolKind.ENCRYPT -> "生成加密网页"
                            ToolKind.GARBLED -> "转为乱码"
                        },
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        if (result.isNotEmpty()) {
            Spacer(Modifier.height(14.dp))
            Box(
                Modifier
                    .fillMaxWidth()
                    .background(th.panel, RoundedCornerShape(16.dp))
                    .border(1.dp, th.line, RoundedCornerShape(16.dp))
                    .padding(14.dp)
            ) {
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("处理结果", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = th.ink)
                        Spacer(Modifier.weight(1f))
                        Text("${result.length} 字符", fontSize = 12.sp, color = th.muted)
                    }
                    Spacer(Modifier.height(8.dp))
                    Box(
                        Modifier
                            .fillMaxWidth()
                            .background(th.bg, RoundedCornerShape(10.dp))
                            .padding(10.dp)
                    ) {
                        Text(
                            result,
                            fontSize = 13.sp,
                            color = if (isError) Color(0xFFE5484D) else th.ink,
                            lineHeight = 20.sp
                        )
                    }
                    Spacer(Modifier.height(10.dp))
                    Row {
                        Button(
                            onClick = {
                                clipboard.setText(AnnotatedString(result))
                                notify("已复制到剪贴板")
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = th.accentSoft),
                            shape = RoundedCornerShape(10.dp)
                        ) { Text("复制", color = th.accent) }
                        Spacer(Modifier.width(8.dp))
                        Button(
                            onClick = {
                                val name = when (kind) {
                                    ToolKind.ENCRYPT -> "加密网页.html"
                                    ToolKind.GARBLED -> "乱码.html"
                                    else -> "结果.txt"
                                }
                                notify(saveTextFile(ctx, name, result))
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = th.accentSoft),
                            shape = RoundedCornerShape(10.dp)
                        ) { Text("保存", color = th.accent) }
                        Spacer(Modifier.width(8.dp))
                        Button(
                            onClick = { result = ""; input = ""; second = "" },
                            colors = ButtonDefaults.buttonColors(containerColor = th.accentSoft),
                            shape = RoundedCornerShape(10.dp)
                        ) { Text("清空", color = th.accent) }
                    }
                }
            }
        }
        Spacer(Modifier.height(30.dp))
    }
}

fun toolTitle(kind: ToolKind) = when (kind) {
    ToolKind.HASH -> "基础哈希计算"
    ToolKind.SALT -> "加盐慢哈希"
    ToolKind.CONVERT -> "格式转换"
    ToolKind.ENCRYPT -> "加密网页"
    ToolKind.GARBLED -> "HTML 转乱码"
}

fun toolHint(kind: ToolKind) = when (kind) {
    ToolKind.HASH -> "输入要计算的内容"
    ToolKind.SALT -> "输入要计算的内容"
    ToolKind.CONVERT -> "输入十六进制字符串"
    ToolKind.ENCRYPT -> "输入要加密的网页或文字"
    ToolKind.GARBLED -> "输入要转换的 HTML 或文字"
}
