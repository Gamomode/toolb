package com.lg.toolbox

import android.content.ContentValues
import android.content.Context
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.util.Base64
import android.webkit.WebView
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import java.io.File
import java.util.zip.ZipFile
import kotlin.random.Random

object Extra {
    val TEXT_EXT = setOf(
        "html", "htm", "js", "mjs", "cjs", "css", "scss", "less", "py", "java", "kt", "kts",
        "json", "xml", "ts", "tsx", "jsx", "md", "txt", "svg", "sh", "bat", "c", "cpp", "h",
        "hpp", "rs", "go", "rb", "php", "properties", "yml", "yaml", "ini", "conf", "csv",
        "sql", "lua", "pl", "swift", "gradle"
    )
    val PWD_RES = listOf(
        Regex("""(?:password|passwd|userpass|dbpass|db_pass|pwd|pass)\s*[=:]\s*["'`]?([^\s"'`,;<>]{4,64})""", RegexOption.IGNORE_CASE),
        Regex("""密码\s*[=:：]\s*["']?([^\s"'`,;<>]{4,64})""")
    )
    private val HEAD = "APKENC1".toByteArray(Charsets.UTF_8)

    fun saveOut(ctx: Context, name: String, mime: String, bytes: ByteArray): String {
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val values = ContentValues().apply {
                    put(MediaStore.Downloads.DISPLAY_NAME, name)
                    put(MediaStore.Downloads.MIME_TYPE, mime)
                }
                val uri = ctx.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                    ?: return "保存失败，请重试"
                ctx.contentResolver.openOutputStream(uri)?.use { it.write(bytes) }
                "已保存到「下载」：$name"
            } else {
                val dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
                dir.mkdirs()
                File(dir, name).writeBytes(bytes)
                "已保存到「下载」：$name"
            }
        } catch (e: Exception) {
            "保存失败：${e.message}"
        }
    }

    fun xorBytes(data: ByteArray, pw: String): ByteArray {
        val ks = Logic.keyStream(pw, data.size)
        val out = ByteArray(data.size)
        for (i in out.indices) out[i] = (data[i].toInt() xor ks[i]).toByte()
        return out
    }

    fun toGarbled(bytes: ByteArray): String {
        val hex = bytes.joinToString("") { "%02x".format(it) }
        val sb = StringBuilder()
        var pos = 0
        while (pos < hex.length) {
            val take = minOf(64 + Random.nextInt(64), hex.length - pos)
            sb.append(hex, pos, pos + take)
            pos += take
            if (pos < hex.length) repeat(8 + Random.nextInt(24)) { sb.append('A' + Random.nextInt(26)) }
        }
        return sb.toString()
    }

    fun fromGarbled(text: String): ByteArray? {
        val hex = text.replace(Regex("[^0-9a-f]"), "")
        if (hex.length < 16 || hex.length % 2 != 0) return null
        return try {
            ByteArray(hex.length / 2) { hex.substring(it * 2, it * 2 + 2).toInt(16).toByte() }
        } catch (e: Exception) {
            null
        }
    }

    fun encApk(data: ByteArray, pw: String): ByteArray = HEAD + xorBytes(data, pw)

    fun decApk(raw: ByteArray, pw: String): ByteArray? {
        var payload: ByteArray? = null
        if (raw.size > HEAD.size && raw.copyOfRange(0, HEAD.size).contentEquals(HEAD)) {
            payload = raw.copyOfRange(HEAD.size, raw.size)
        } else {
            val text = String(raw, Charsets.ISO_8859_1)
            val bytes = fromGarbled(text) ?: return null
            if (bytes.size > HEAD.size && bytes.copyOfRange(0, HEAD.size).contentEquals(HEAD)) {
                payload = bytes.copyOfRange(HEAD.size, bytes.size)
            }
        }
        payload ?: return null
        val dec = xorBytes(payload, pw)
        if (dec.size < 4 || dec[0] != 0x50.toByte() || dec[1] != 0x4B.toByte() || dec[2] != 3.toByte() || dec[3] != 4.toByte()) return null
        return dec
    }

    fun scanPasswords(text: String): List<String> {
        val out = mutableListOf<String>()
        val lines = text.split("\n")
        for (i in lines.indices) {
            for (re in PWD_RES) {
                val m = re.findAll(lines[i])
                for (hit in m) out.add("第 ${i + 1} 行：${hit.groupValues[1]}")
            }
        }
        return out.distinct()
    }

    fun scanCodes(text: String): List<String> {
        val out = mutableListOf<String>()
        val lines = text.split("\n")
        for (i in lines.indices) {
            val b64 = Regex("[A-Za-z0-9+/]{24,}={0,2}").findAll(lines[i])
            for (m in b64) out.add("第 ${i + 1} 行 Base64（${m.value.length} 字符）：${m.value.take(48)}…")
            val hex = Regex("[0-9a-fA-F]{32,}").findAll(lines[i])
            for (m in hex) out.add("第 ${i + 1} 行 十六进制（${m.value.length} 字符）：${m.value.take(48)}…")
        }
        return out.distinct()
    }

    fun decodeSel(text: String): String {
        val t = text.trim()
        if (t.isEmpty()) return "没有选中内容"
        if (t.matches(Regex("[0-9a-fA-F]+")) && t.length % 2 == 0) {
            return try {
                val bytes = ByteArray(t.length / 2) { t.substring(it * 2, it * 2 + 2).toInt(16).toByte() }
                "十六进制解码：\n" + String(bytes, Charsets.UTF_8)
            } catch (e: Exception) {
                "十六进制解码失败"
            }
        }
        if (t.matches(Regex("[A-Za-z0-9+/=\\-_.]+"))) {
            val b64 = try {
                String(Base64.decode(t.replace('-', '+').replace('_', '/'), Base64.DEFAULT), Charsets.UTF_8)
            } catch (e: Exception) { null }
            if (b64 != null && b64.isNotEmpty()) return "Base64 解码：\n" + b64
        }
        return try {
            "URL 解码：\n" + java.net.URLDecoder.decode(t, "UTF-8")
        } catch (e: Exception) {
            "认不出这段编码，试试 Base64 / 十六进制 / URL"
        }
    }

    fun manifestLabel(data: ByteArray): String? {
        return try {
            var strings: List<String>? = null
            var label: String? = null
            var pos = 0
            while (pos + 8 <= data.size) {
                val type = u16(data, pos).toInt()
                if (type == 3) {
                    pos += 8
                    continue
                }
                val size = u32(data, pos + 4).toInt()
                if (size <= 0 || pos + size > data.size) break
                if (type == 1) {
                    strings = parsePool(data, pos)
                } else if (type == 0x0102 && strings != null) {
                    val nameIdx = u32(data, pos + 20).toInt()
                    if (strings.getOrNull(nameIdx) == "application") {
                        val attrStart = u16(data, pos + 24).toInt()
                        val attrCount = u16(data, pos + 28).toInt()
                        var ap = pos + 16 + attrStart
                        for (i in 0 until attrCount) {
                            val aNameIdx = u32(data, ap + 4).toInt()
                            val dataType = data[ap + 15].toInt() and 0xFF
                            val dataVal = u32(data, ap + 16)
                            if (strings.getOrNull(aNameIdx) == "label" && dataType == 3) {
                                val v = strings.getOrNull(dataVal.toInt())
                                if (v != null && !v.startsWith("@")) label = v
                            }
                            ap += 20
                        }
                    }
                }
                pos += size
            }
            label
        } catch (e: Exception) {
            null
        }
    }

    private fun parsePool(data: ByteArray, chunkStart: Int): List<String> {
        val stringCount = u32(data, chunkStart + 8).toInt()
        val flags = u32(data, chunkStart + 16)
        val stringsStart = u32(data, chunkStart + 20).toInt()
        val utf8 = (flags and 0x100L) != 0L
        val out = ArrayList<String>(stringCount)
        for (i in 0 until stringCount) {
            val off = u32(data, chunkStart + 28 + i * 4).toInt()
            var p = chunkStart + stringsStart + off
            if (p >= data.size) {
                out.add("")
                continue
            }
            if (utf8) {
                var r = readLen8(data, p)
                p += r.second
                r = readLen8(data, p)
                p += r.second
                val len = r.first
                out.add(if (len <= 0 || p + len > data.size) "" else String(data, p, len, Charsets.UTF_8))
            } else {
                val r = readLen16(data, p)
                p += r.second
                val len = r.first
                val sb = StringBuilder()
                for (j in 0 until len) {
                    if (p + j * 2 + 1 >= data.size) break
                    sb.append(u16(data, p + j * 2).toInt().toChar())
                }
                out.add(sb.toString())
            }
        }
        return out
    }

    private fun readLen8(d: ByteArray, p: Int): Pair<Int, Int> {
        if (p >= d.size) return 0 to 1
        val b = d[p].toInt() and 0xFF
        return if (b and 0x80 != 0) {
            if (p + 1 >= d.size) 0 to 2
            else (((b and 0x7F) shl 8) or (d[p + 1].toInt() and 0xFF)) to 2
        } else b to 1
    }

    private fun readLen16(d: ByteArray, p: Int): Pair<Int, Int> {
        if (p + 1 >= d.size) return 0 to 2
        val v = u16(d, p).toInt()
        return if (v and 0x8000 != 0) {
            if (p + 3 >= d.size) 0 to 4
            else (((v and 0x7FFF) shl 16) or u16(d, p + 2).toInt()) to 4
        } else v to 2
    }

    private fun u16(d: ByteArray, p: Int): Long =
        ((d[p].toInt() and 0xFF) or ((d[p + 1].toInt() and 0xFF) shl 8)).toLong()

    private fun u32(d: ByteArray, p: Int): Long = u16(d, p) or (u16(d, p + 2) shl 16)
}

@Composable
fun XPanel(title: String, th: ThemeSpec, content: @Composable ColumnScope.() -> Unit) {
    Spacer(Modifier.height(14.dp))
    Box(
        Modifier
            .fillMaxWidth()
            .background(th.panel, RoundedCornerShape(20.dp))
            .border(1.dp, th.line, RoundedCornerShape(20.dp))
            .padding(16.dp)
    ) {
        Column {
            Text(title, fontSize = 16.sp, fontWeight = FontWeight.Bold, color = th.accent)
            Spacer(Modifier.height(10.dp))
            content()
        }
    }
}

@Composable
fun XBtn(label: String, th: ThemeSpec, primary: Boolean = true, enabled: Boolean = true, onClick: () -> Unit) {
    Button(
        onClick = onClick,
        enabled = enabled,
        colors = ButtonDefaults.buttonColors(
            containerColor = if (primary) th.accent else th.accentSoft,
            contentColor = if (primary) Color.White else th.accent
        ),
        shape = RoundedCornerShape(14.dp),
        contentPadding = PaddingValues(horizontal = 14.dp, vertical = 8.dp),
        modifier = Modifier.padding(end = 8.dp, bottom = 8.dp)
    ) {
        Text(label, fontSize = 13.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun XField(value: String, onChange: (String) -> Unit, label: String, th: ThemeSpec, single: Boolean = true, mono: Boolean = false) {
    OutlinedTextField(
        value = value,
        onValueChange = onChange,
        label = { Text(label) },
        singleLine = single,
        shape = FieldShape,
        colors = fieldColors(th),
        textStyle = if (mono) LocalTextStyle.current.copy(fontFamily = FontFamily.Monospace, fontSize = 13.sp) else LocalTextStyle.current,
        modifier = Modifier
            .fillMaxWidth()
            .padding(bottom = 10.dp)
    )
}

@Composable
fun XStatus(msg: String, th: ThemeSpec) {
    if (msg.isNotEmpty()) {
        Spacer(Modifier.height(8.dp))
        Text(msg, fontSize = 13.sp, color = th.ink, lineHeight = 20.sp)
    }
}

@Composable
fun ApkEncScreen(th: ThemeSpec, notify: (String) -> Unit) {
    val ctx = LocalContext.current
    var encName by remember { mutableStateOf("") }
    var encData by remember { mutableStateOf<ByteArray?>(null) }
    var encPw by remember { mutableStateOf("") }
    var garble by remember { mutableStateOf(false) }
    var decName by remember { mutableStateOf("") }
    var decData by remember { mutableStateOf<ByteArray?>(null) }
    var decPw by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("") }

    val encPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            try {
                encData = ctx.contentResolver.openInputStream(uri)?.use { it.readBytes() }
                encName = uri.lastPathSegment ?: "安装包.apk"
                status = ""
            } catch (e: Exception) {
                notify("读取失败：${e.message}")
            }
        }
    }
    val decPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            try {
                decData = ctx.contentResolver.openInputStream(uri)?.use { it.readBytes() }
                decName = uri.lastPathSegment ?: "加密文件"
                status = ""
            } catch (e: Exception) {
                notify("读取失败：${e.message}")
            }
        }
    }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        Box(
            Modifier
                .fillMaxWidth()
                .background(th.accentSoft, RoundedCornerShape(20.dp))
                .padding(14.dp)
        ) {
            Text(
                "把安装包加密成一个装不了也拆不了的文件，拿到的人没有密码打不开；输入正确密码随时还原成原来的 APK。勾选「加乱码」后导出的是乱码文本文件，还原时同样直接选进来即可。全程本机完成，不上传任何数据。",
                fontSize = 13.sp,
                color = th.ink,
                lineHeight = 21.sp
            )
        }
        XPanel("加密 APK", th) {
            Box(
                Modifier
                    .fillMaxWidth()
                    .background(th.accentSoft, RoundedCornerShape(14.dp))
                    .tap { encPicker.launch("*/*") }
                    .padding(vertical = 20.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    if (encData == null) "点击选择 .apk 安装包" else "$encName（${humanSize(encData!!.size.toLong())}）",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = th.ink
                )
            }
            Spacer(Modifier.height(10.dp))
            XField(encPw, { encPw = it }, "加密密码（至少 2 位）", th)
            PackCheckRow("加乱码（导出成乱码文件，防止别人看出是安装包）", garble, { garble = it }, th)
            Spacer(Modifier.height(6.dp))
            XBtn("加密并保存", th, enabled = !busy && encData != null) {
                if (encPw.length < 2) {
                    notify("密码至少 2 位")
                } else {
                    busy = true
                    status = try {
                        val full = Extra.encApk(encData!!, encPw)
                        val base = encName.removeSuffix(".apk").removeSuffix(".APK")
                        if (garble) {
                            Extra.saveOut(ctx, "$base.txt", "text/plain", Extra.toGarbled(full).toByteArray(Charsets.UTF_8))
                        } else {
                            Extra.saveOut(ctx, "$base.apkc", "application/octet-stream", full)
                        } + " 密码丢了就还原不回来了，务必记牢。"
                    } catch (e: Exception) {
                        "加密失败：${e.message}"
                    }
                    busy = false
                }
            }
        }
        XPanel("还原 APK", th) {
            Box(
                Modifier
                    .fillMaxWidth()
                    .background(th.accentSoft, RoundedCornerShape(14.dp))
                    .tap { decPicker.launch("*/*") }
                    .padding(vertical = 20.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    if (decData == null) "点击选择加密文件（.apkc 或 .txt）" else decName,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = th.ink
                )
            }
            Spacer(Modifier.height(10.dp))
            XField(decPw, { decPw = it }, "解密密码", th)
            XBtn("解密并保存 APK", th, enabled = !busy && decData != null) {
                if (decPw.isEmpty()) {
                    notify("先输入解密密码")
                } else {
                    busy = true
                    status = try {
                        val dec = Extra.decApk(decData!!, decPw)
                        if (dec == null) {
                            "密码不对或文件已损坏，还原失败。"
                        } else {
                            val base = decName.removeSuffix(".apkc").removeSuffix(".txt").removeSuffix(".APKC").removeSuffix(".TXT")
                            Extra.saveOut(ctx, "$base.apk", "application/vnd.android.package-archive", dec) + " 可以正常安装了。"
                        }
                    } catch (e: Exception) {
                        "解密失败：${e.message}"
                    }
                    busy = false
                }
            }
        }
        XStatus(status, th)
        Spacer(Modifier.height(30.dp))
    }
}

@Composable
fun ApkModScreen(th: ThemeSpec, notify: (String) -> Unit) {
    val ctx = LocalContext.current
    var fileName by remember { mutableStateOf("") }
    var fileSize by remember { mutableStateOf(0L) }
    var entries by remember { mutableStateOf<List<Pair<String, ByteArray>>>(emptyList()) }
    val edits = remember { mutableStateMapOf<String, ByteArray?>() }
    var info by remember { mutableStateOf<ApkManifest.Info?>(null) }
    var label by remember { mutableStateOf<String?>(null) }
    var verName by remember { mutableStateOf("") }
    var verCode by remember { mutableStateOf("") }
    var appName by remember { mutableStateOf("") }
    var selEntry by remember { mutableStateOf("") }
    var entryMenu by remember { mutableStateOf(false) }
    var entryText by remember { mutableStateOf("") }
    var newEntryName by remember { mutableStateOf("") }
    var newEntryText by remember { mutableStateOf("") }
    var pwdResults by remember { mutableStateOf<List<String>>(emptyList()) }
    var busy by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("") }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            busy = true
            try {
                val tmp = File(ctx.cacheDir, "apkmod_tmp.apk")
                ctx.contentResolver.openInputStream(uri)?.use { ins ->
                    tmp.outputStream().use { ins.copyTo(it) }
                }
                val list = mutableListOf<Pair<String, ByteArray>>()
                ZipFile(tmp).use { zf ->
                    val en = zf.entries()
                    while (en.hasMoreElements()) {
                        val e = en.nextElement()
                        if (e.isDirectory) continue
                        list.add(e.name to zf.getInputStream(e).readBytes())
                    }
                }
                entries = list
                edits.clear()
                fileName = uri.lastPathSegment ?: "安装包.apk"
                fileSize = tmp.length()
                val mf = list.firstOrNull { it.first == "AndroidManifest.xml" }?.second
                info = mf?.let { ApkManifest.parse(it) }
                label = mf?.let { Extra.manifestLabel(it) }
                verName = info?.versionName ?: ""
                verCode = ""
                appName = label ?: ""
                selEntry = ""
                entryText = ""
                pwdResults = emptyList()
                status = ""
                tmp.delete()
            } catch (e: Exception) {
                notify("读取失败：${e.message}")
            }
            busy = false
        }
    }

    fun textEntries(): List<String> {
        val list = entries.filter { (name, data) ->
            if (data.isEmpty() || data.size > 2 * 1024 * 1024) return@filter false
            val dot = name.lastIndexOf(".")
            val ext = if (dot >= 0) name.substring(dot + 1).lowercase() else ""
            Extra.TEXT_EXT.contains(ext)
        }.map { it.first }.toMutableList()
        for (k in edits.keys) if (edits[k] != null && !list.contains(k)) list.add(k)
        return list.sorted()
    }

    fun loadEntry(name: String) {
        selEntry = name
        entryText = if (edits.containsKey(name) && edits[name] != null) {
            String(edits[name]!!, Charsets.UTF_8)
        } else {
            entries.firstOrNull { it.first == name }?.second?.let { String(it, Charsets.UTF_8) } ?: ""
        }
    }

    fun generate() {
        val mfEntry = entries.firstOrNull { it.first == "AndroidManifest.xml" }
        if (mfEntry == null) {
            notify("包里没有 AndroidManifest.xml")
            return
        }
        busy = true
        status = try {
            var mf = mfEntry.second
            val oldName = info?.versionName ?: ""
            val oldLabel = label ?: ""
            val nv = verName.trim()
            val ncv = verCode.trim()
            val nl = appName.trim()
            if (ncv.isNotEmpty() && (ncv.toIntOrNull() == null || ncv.toInt() < 1)) {
                notify("版本号要填正整数")
                busy = false
                return
            }
            val reps = mutableListOf<Pair<String, String>>()
            if (nv.isNotEmpty() && oldName.isNotEmpty() && nv != oldName) reps.add(oldName to nv)
            if (nl.isNotEmpty() && oldLabel.isNotEmpty() && nl != oldLabel) reps.add(oldLabel to nl)
            if (reps.isNotEmpty()) mf = ApkBuilder.patchBinaryXml(mf, reps)
            if (ncv.isNotEmpty()) mf = ApkBuilder.patchManifestVersionCode(mf, ncv.toInt())
            val sigRe = Regex("^META-INF/(MANIFEST\\.MF|.*\\.(SF|RSA|DSA|EC))$", RegexOption.IGNORE_CASE)
            val final = mutableListOf<ApkEntry>()
            for ((name, data) in entries) {
                if (sigRe.containsMatchIn(name)) continue
                if (edits.containsKey(name) && edits[name] == null) continue
                val d = if (edits.containsKey(name) && edits[name] != null) edits[name]!! else data
                val use = if (name == "AndroidManifest.xml") mf else d
                val stored = name == "resources.arsc" || name == "AndroidManifest.xml"
                final.add(ApkEntry(name, use, if (stored) 0 else 8, if (stored) 4 else 0))
            }
            for ((name, d) in edits) {
                if (d == null || final.any { it.name == name }) continue
                final.add(ApkEntry(name, d, 8))
            }
            ApkBuilder.init(ctx)
            val bytes = ApkBuilder.repackApk(final)
            val dlName = (label ?: "应用") + "-修改版.apk"
            val nEdits = edits.size
            Extra.saveOut(ctx, dlName, "application/vnd.android.package-archive", bytes) +
                " 原包内容原样保留" + (if (nEdits > 0) "，应用了 $nEdits 处包内文件改动" else "") + "。"
        } catch (e: Exception) {
            "生成失败：${e.message}"
        }
        busy = false
    }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        Box(
            Modifier
                .fillMaxWidth()
                .background(th.accentSoft, RoundedCornerShape(20.dp))
                .padding(14.dp)
        ) {
            Text(
                "把安装包选进来，改版本号和应用名，重新打包并签名。包内文本文件可改、可加、可删，还能定位包里的密码。全程本地处理，文件不会离开这台设备。",
                fontSize = 13.sp,
                color = th.ink,
                lineHeight = 21.sp
            )
        }
        if (entries.isEmpty()) {
            Spacer(Modifier.height(14.dp))
            Box(
                Modifier
                    .fillMaxWidth()
                    .background(th.panel, RoundedCornerShape(20.dp))
                    .border(1.dp, th.line, RoundedCornerShape(20.dp))
                    .tap { picker.launch("*/*") }
                    .padding(vertical = 34.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    if (busy) "解析中…" else "点击选择 .apk 安装包",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = th.ink
                )
            }
        } else {
            XPanel("应用信息", th) {
                Text(fileName, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = th.ink)
                Spacer(Modifier.height(4.dp))
                Text("包名：${info?.pkg ?: "—"}", fontSize = 13.sp, color = th.muted)
                Text("版本：${info?.versionName ?: "—"}", fontSize = 13.sp, color = th.muted)
                Text("大小：${humanSize(fileSize)} · 内部文件 ${entries.size} 个", fontSize = 13.sp, color = th.muted)
            }
            XPanel("修改内容", th) {
                XField(verName, { verName = it }, "版本名称 versionName", th)
                XField(verCode, { verCode = it }, "版本号 versionCode（正整数，留空不改）", th)
                XField(appName, { appName = it }, "应用名称（桌面显示的名字）", th)
            }
            XPanel("包内文件（可改 / 可加 / 可删）", th) {
                Box {
                    XBtn(if (selEntry.isEmpty()) "选择包内文件" else selEntry, th, primary = false) { entryMenu = true }
                    DropdownMenu(expanded = entryMenu, onDismissRequest = { entryMenu = false }) {
                        textEntries().forEach { n ->
                            val mark = when {
                                edits.containsKey(n) && edits[n] == null -> "（已删除）"
                                edits.containsKey(n) -> "（已修改）"
                                else -> ""
                            }
                            DropdownMenuItem(
                                text = { Text(n + mark, fontSize = 13.sp) },
                                onClick = {
                                    entryMenu = false
                                    loadEntry(n)
                                }
                            )
                        }
                    }
                }
                XStatus(
                    when {
                        selEntry.isEmpty() -> ""
                        edits.containsKey(selEntry) && edits[selEntry] == null -> "这个文件已被标记删除，重新生成时不会包含它。"
                        edits.containsKey(selEntry) -> "此文件已修改，点「生成修改版」生效。"
                        else -> ""
                    },
                    th
                )
                if (selEntry.isNotEmpty() && !(edits.containsKey(selEntry) && edits[selEntry] == null)) {
                    OutlinedTextField(
                        value = entryText,
                        onValueChange = { entryText = it },
                        label = { Text("文件内容（可直接修改）") },
                        shape = FieldShape,
                        colors = fieldColors(th),
                        textStyle = LocalTextStyle.current.copy(fontFamily = FontFamily.Monospace, fontSize = 13.sp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(min = 160.dp)
                            .padding(bottom = 10.dp)
                    )
                    Row(Modifier.horizontalScroll(rememberScrollState())) {
                        XBtn("保存对此文件的修改", th) {
                            edits[selEntry] = entryText.toByteArray(Charsets.UTF_8)
                            notify("已记录修改，生成时生效")
                        }
                        XBtn("从包中删除此文件", th, primary = false) {
                            edits[selEntry] = null
                            notify("已标记删除，生成时生效")
                        }
                    }
                }
                Spacer(Modifier.height(6.dp))
                XField(newEntryName, { newEntryName = it }, "新文件名（如 assets/abc.txt）", th)
                OutlinedTextField(
                    value = newEntryText,
                    onValueChange = { newEntryText = it },
                    label = { Text("新文件内容") },
                    shape = FieldShape,
                    colors = fieldColors(th),
                    textStyle = LocalTextStyle.current.copy(fontFamily = FontFamily.Monospace, fontSize = 13.sp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(min = 80.dp)
                        .padding(bottom = 10.dp)
                )
                XBtn("添加新文件", th, primary = false) {
                    if (newEntryName.isBlank()) {
                        notify("先填新文件名")
                    } else {
                        edits[newEntryName.trim()] = newEntryText.toByteArray(Charsets.UTF_8)
                        loadEntry(newEntryName.trim())
                        notify("已加入新文件，生成时生效")
                    }
                }
            }
            XPanel("定位包内密码", th) {
                XBtn("扫描包内所有文本文件", th) {
                    val found = mutableListOf<String>()
                    for ((name, data) in entries) {
                        val dot = name.lastIndexOf(".")
                        val ext = if (dot >= 0) name.substring(dot + 1).lowercase() else ""
                        if (!Extra.TEXT_EXT.contains(ext) || data.size > 2 * 1024 * 1024) continue
                        val text = String(data, Charsets.UTF_8)
                        Extra.scanPasswords(text).take(20).forEach { found.add("$name → $it") }
                    }
                    pwdResults = found
                    if (found.isEmpty()) notify("没扫到明文密码")
                }
                pwdResults.take(30).forEach { Text(it, fontSize = 12.sp, color = th.ink, lineHeight = 18.sp) }
            }
            Spacer(Modifier.height(14.dp))
            XBtn(if (busy) "生成中…" else "生成修改版", th, enabled = !busy) { generate() }
            XBtn("换一个文件", th, primary = false) {
                entries = emptyList()
                edits.clear()
                info = null
                label = null
                selEntry = ""
                status = ""
            }
        }
        XStatus(status, th)
        Spacer(Modifier.height(30.dp))
    }
}

@Composable
fun FileEditScreen(th: ThemeSpec, notify: (String) -> Unit) {
    val ctx = LocalContext.current
    var fileName by remember { mutableStateOf("") }
    var fileSize by remember { mutableStateOf(0L) }
    var loaded by remember { mutableStateOf(false) }
    var editor by remember { mutableStateOf(TextFieldValue("")) }
    var find by remember { mutableStateOf("") }
    var repl by remember { mutableStateOf("") }
    var addText by remember { mutableStateOf("") }
    var findInfo by remember { mutableStateOf("") }
    var pwdResults by remember { mutableStateOf<List<String>>(emptyList()) }
    var codeResults by remember { mutableStateOf<List<String>>(emptyList()) }
    var decodeOut by remember { mutableStateOf("") }
    var showPreview by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            busy = true
            try {
                val bytes = ctx.contentResolver.openInputStream(uri)?.use { it.readBytes() }
                if (bytes == null || bytes.size > 4 * 1024 * 1024) {
                    notify("文件太大或读不出来（上限 4 MB）")
                } else {
                    fileName = uri.lastPathSegment ?: "文件.txt"
                    fileSize = bytes.size.toLong()
                    editor = TextFieldValue(String(bytes, Charsets.UTF_8))
                    loaded = true
                    pwdResults = emptyList()
                    codeResults = emptyList()
                    decodeOut = ""
                    findInfo = ""
                }
            } catch (e: Exception) {
                notify("读取失败：${e.message}")
            }
            busy = false
        }
    }

    fun findNext() {
        if (find.isEmpty()) {
            findInfo = "先输入要查找的内容"
            return
        }
        val text = editor.text
        var start = editor.selection.end
        if (start < 0 || start > text.length) start = 0
        var idx = text.indexOf(find, start)
        if (idx < 0) idx = text.indexOf(find)
        if (idx < 0) {
            findInfo = "没找到「$find」"
            return
        }
        editor = editor.copy(selection = TextRange(idx, idx + find.length))
        findInfo = "定位到第 ${text.take(idx).count { it == '\n' } + 1} 行"
    }

    fun replaceOne() {
        if (find.isEmpty()) return
        val text = editor.text
        val selStart = editor.selection.min
        val selEnd = editor.selection.max
        if (selEnd > selStart && text.substring(selStart, selEnd) == find) {
            val newText = text.substring(0, selStart) + repl + text.substring(selEnd)
            editor = TextFieldValue(newText, TextRange(selStart + repl.length))
            findInfo = "已替换当前一处"
        } else {
            var idx = text.indexOf(find, selEnd)
            if (idx < 0) idx = text.indexOf(find)
            if (idx < 0) {
                findInfo = "没找到「$find」"
                return
            }
            val newText = text.substring(0, idx) + repl + text.substring(idx + find.length)
            editor = TextFieldValue(newText, TextRange(idx + repl.length))
            findInfo = "已替换当前一处"
        }
    }

    fun replaceAll() {
        if (find.isEmpty()) return
        val text = editor.text
        if (!text.contains(find)) {
            findInfo = "没找到「$find」"
            return
        }
        val count = text.split(find).size - 1
        editor = TextFieldValue(text.replace(find, repl), TextRange(0))
        findInfo = if (repl.isEmpty()) "删除了 $count 处" else "替换了 $count 处"
    }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        Box(
            Modifier
                .fillMaxWidth()
                .background(th.accentSoft, RoundedCornerShape(20.dp))
                .padding(14.dp)
        ) {
            Text(
                "载入文本文件（HTML、JS、CSS、JSON、TXT 等），直接改内容，支持查找替换、增删、定位文件里的密码、Base64 / 十六进制解码和网页预览。全程本地处理，文件不会离开这台设备。",
                fontSize = 13.sp,
                color = th.ink,
                lineHeight = 21.sp
            )
        }
        if (!loaded) {
            Spacer(Modifier.height(14.dp))
            Box(
                Modifier
                    .fillMaxWidth()
                    .background(th.panel, RoundedCornerShape(20.dp))
                    .border(1.dp, th.line, RoundedCornerShape(20.dp))
                    .tap { picker.launch("*/*") }
                    .padding(vertical = 34.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    if (busy) "读取中…" else "点击选择文本文件",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = th.ink
                )
            }
        } else {
            XPanel("文件信息", th) {
                Text(fileName, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = th.ink)
                Spacer(Modifier.height(4.dp))
                Text(
                    "大小：${humanSize(fileSize)} · ${editor.text.split("\n").size} 行 / ${editor.text.length} 字符",
                    fontSize = 13.sp,
                    color = th.muted
                )
                Spacer(Modifier.height(10.dp))
                Row(Modifier.horizontalScroll(rememberScrollState())) {
                    XBtn("保存修改后的文件", th) {
                        notify(
                            Extra.saveOut(
                                ctx,
                                fileName,
                                "text/plain",
                                editor.text.toByteArray(Charsets.UTF_8)
                            )
                        )
                    }
                    XBtn("换一个文件", th, primary = false) { loaded = false }
                }
            }
            XPanel("查找 / 替换 / 删除", th) {
                XField(find, { find = it }, "查找内容", th)
                XField(repl, { repl = it }, "替换为（留空即删除）", th)
                Row(Modifier.horizontalScroll(rememberScrollState())) {
                    XBtn("定位下一处", th) { findNext() }
                    XBtn("替换当前", th) { replaceOne() }
                    XBtn("全部替换", th, primary = false) { replaceAll() }
                    XBtn("全部删除", th, primary = false) {
                        if (find.isEmpty()) findInfo = "先输入要删除的内容" else {
                            repl = ""
                            replaceAll()
                        }
                    }
                }
                XStatus(findInfo, th)
            }
            XPanel("添加内容", th) {
                OutlinedTextField(
                    value = addText,
                    onValueChange = { addText = it },
                    label = { Text("要添加的文字") },
                    shape = FieldShape,
                    colors = fieldColors(th),
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(min = 80.dp)
                        .padding(bottom = 10.dp)
                )
                Row(Modifier.horizontalScroll(rememberScrollState())) {
                    XBtn("插入到光标处", th) {
                        val pos = editor.selection.end.coerceIn(0, editor.text.length)
                        val newText = editor.text.substring(0, pos) + addText + editor.text.substring(pos)
                        editor = TextFieldValue(newText, TextRange(pos + addText.length))
                    }
                    XBtn("添加到开头", th) {
                        editor = TextFieldValue(addText + editor.text, TextRange(0))
                    }
                    XBtn("添加到结尾", th) {
                        val len = editor.text.length
                        editor = TextFieldValue(editor.text + addText, TextRange(len))
                    }
                }
            }
            XPanel("定位密码与破解", th) {
                Row(Modifier.horizontalScroll(rememberScrollState())) {
                    XBtn("定位文件里的密码", th) {
                        pwdResults = Extra.scanPasswords(editor.text)
                        if (pwdResults.isEmpty()) notify("没扫到明文密码")
                    }
                    XBtn("定位 Base64 / 十六进制", th, primary = false) {
                        codeResults = Extra.scanCodes(editor.text)
                        if (codeResults.isEmpty()) notify("没扫到编码串")
                    }
                }
                pwdResults.take(30).forEach { Text(it, fontSize = 12.sp, color = th.ink, lineHeight = 18.sp) }
                codeResults.take(30).forEach { Text(it, fontSize = 12.sp, color = th.ink, lineHeight = 18.sp) }
                Spacer(Modifier.height(8.dp))
                XBtn("解码选中内容", th) {
                    val sel = editor.selection
                    decodeOut = if (sel.end > sel.start) {
                        Extra.decodeSel(editor.text.substring(sel.min, sel.max))
                    } else {
                        "先在编辑框里选中一段编码文字"
                    }
                }
                XStatus(decodeOut, th)
            }
            XPanel("编辑内容", th) {
                OutlinedTextField(
                    value = editor,
                    onValueChange = { editor = it },
                    label = { Text("文件内容") },
                    shape = FieldShape,
                    colors = fieldColors(th),
                    textStyle = LocalTextStyle.current.copy(fontFamily = FontFamily.Monospace, fontSize = 13.sp, lineHeight = 20.sp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(min = 260.dp)
                )
                Spacer(Modifier.height(4.dp))
                Row(Modifier.horizontalScroll(rememberScrollState())) {
                    XBtn(if (showPreview) "关闭预览" else "网页预览", th, primary = false) { showPreview = !showPreview }
                }
                if (showPreview) {
                    Spacer(Modifier.height(8.dp))
                    AndroidView(
                        factory = { c -> WebView(c) },
                        update = { w -> w.loadData(editor.text, "text/html", "utf-8") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(300.dp)
                    )
                }
            }
        }
        Spacer(Modifier.height(30.dp))
    }
}
