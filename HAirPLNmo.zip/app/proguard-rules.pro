# 保持 WebView 与 JS 接口
-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}