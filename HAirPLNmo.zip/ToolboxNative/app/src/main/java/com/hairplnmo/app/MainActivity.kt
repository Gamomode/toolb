package com.hairplnmo.app

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.border
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.Brush
import androidx.compose.material.icons.filled.EditNote
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Tag
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CardGiftcard
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.Handyman
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon

import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.composed
import androidx.compose.ui.platform.LocalContext
import kotlinx.coroutines.delay
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import java.security.MessageDigest
import kotlin.system.exitProcess
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState

val BgColor = Color(0xFFF3F5F9)
val CardColor = Color(0xFFFFFFFF)
val AccentColor = Color(0xFF1A6DFF)
val MainText = Color(0xFF1B2230)
val SubText = Color(0xFF7A8499)
val LineColor = Color(0xFFE3E8F0)
val ExpectedSig = "241e92d50251dfce8965c4381888f231fb7a78d67b35ed7ee228a1533b1a1437"

fun Modifier.tap(onClick: () -> Unit): Modifier = composed {
    clickable(interactionSource = remember { MutableInteractionSource() }, indication = null, onClick = onClick)
}

@Composable
fun FloatField(
    value: String,
    onValueChange: (String) -> Unit,
    label: String,
    modifier: Modifier = Modifier,
    isPassword: Boolean = false
) {
    var focused by remember { mutableStateOf(false) }
    val up = focused || value.isNotEmpty()
    val labelSize by animateFloatAsState(if (up) 11f else 14f)
    val labelTop by animateDpAsState(if (up) 7.dp else 0.dp)
    val inputTop by animateDpAsState(if (up) 16.dp else 0.dp)
    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(56.dp)
            .border(1.dp, if (focused) AccentColor else LineColor, RoundedCornerShape(12.dp))
            .background(CardColor, RoundedCornerShape(12.dp))
    ) {
        if (up) {
            Text(
                label,
                fontSize = labelSize.sp,
                color = if (focused) AccentColor else SubText,
                modifier = Modifier
                    .align(Alignment.TopStart)
                    .padding(start = 14.dp, top = labelTop)
            )
        }
        BasicTextField(
            value = value,
            onValueChange = onValueChange,
            singleLine = true,
            textStyle = TextStyle(fontSize = 15.sp, color = MainText),
            visualTransformation = if (isPassword) PasswordVisualTransformation() else VisualTransformation.None,
            keyboardOptions = KeyboardOptions(keyboardType = if (isPassword) KeyboardType.Password else KeyboardType.Text),
            modifier = Modifier
                .align(Alignment.CenterStart)
                .padding(start = 14.dp, end = 14.dp, top = inputTop)
                .fillMaxWidth()
                .onFocusChanged { focused = it.isFocused }
        ) { inner ->
            if (!up) {
                Text(label, fontSize = 14.sp, color = SubText)
            }
            inner()
        }
    }
}

class MainActivity : ComponentActivity() {
    fun isSignatureValid(): Boolean {
        return try {
            val info = packageManager.getPackageInfo(packageName, PackageManager.GET_SIGNATURES)
            val sig = info.signatures?.firstOrNull() ?: return false
            val digest = MessageDigest.getInstance("SHA-256").digest(sig.toByteArray())
            val hex = digest.joinToString("") { "%02x".format(it) }
            hex == ExpectedSig
        } catch (e: Exception) {
            false
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        val controller = WindowCompat.getInsetsController(window, window.decorView)
        controller.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        controller.hide(WindowInsetsCompat.Type.systemBars())
        val sigOk = isSignatureValid()
        val startUser = getLoggedInUser(this)
        setContent {
            var stage by remember { mutableStateOf(if (startUser.isEmpty()) "login" else "select") }
            var currentUser by remember { mutableStateOf(startUser) }
            Surface(color = BgColor, modifier = Modifier.fillMaxSize()) {
                if (!sigOk) {
                    TamperScreen(onExit = {
                        finishAffinity()
                        exitProcess(0)
                    })
                } else {
                    when (stage) {
                        "login" -> LoginScreen(onSuccess = { u ->
                            currentUser = u
                            stage = "select"
                        })
                        "select" -> SelectScreen(
                            currentUser = currentUser,
                            onAdmin = { stage = "admin" },
                            onLogout = {
                                setLoggedInUser(applicationContext, "")
                                currentUser = ""
                                stage = "login"
                            },
                            onPremium = { stage = "premium" },
                            onFree = { stage = "loading" }
                        )
                        "admin" -> AdminScreen(onBack = { stage = "select" })
                        "premium" -> PremiumScreen(onBack = { stage = "select" }, onBuy = { stage = "purchase" }, currentUser = currentUser)
                        "purchase" -> PurchaseScreen(onBack = { stage = "premium" })
                        "loading" -> LoadingScreen(onDone = { stage = "home" })
                        "home" -> HomeScreen()
                    }
                }
            }
        }
    }
}

@Composable
fun TamperScreen(onExit: () -> Unit) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF1B2230)),
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(28.dp)
                .background(CardColor, RoundedCornerShape(22.dp))
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text("⚠", fontSize = 40.sp)
            Spacer(Modifier.height(12.dp))
            Text("检测到应用被修改", fontSize = 19.sp, fontWeight = FontWeight.Bold, color = MainText)
            Spacer(Modifier.height(8.dp))
            Text(
                "应用的文件或签名已被改动，为保护安全无法继续使用。",
                fontSize = 13.sp,
                color = SubText,
                textAlign = TextAlign.Center,
                lineHeight = 20.sp
            )
            Spacer(Modifier.height(20.dp))
            Button(
                onClick = onExit,
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = AccentColor)
            ) {
                Text("确定", fontSize = 15.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
fun SelectScreen(
    currentUser: String,
    onAdmin: () -> Unit,
    onLogout: () -> Unit,
    onPremium: () -> Unit,
    onFree: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFFFFFFF))
            .padding(horizontal = 24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Box(
            modifier = Modifier
                .size(64.dp)
                .background(Color(0xFF1C1C1E), RoundedCornerShape(18.dp)),
            contentAlignment = Alignment.Center
        ) {
            Icon(Icons.Filled.Handyman, contentDescription = null, tint = Color.White, modifier = Modifier.size(30.dp))
        }
        Spacer(Modifier.height(16.dp))
        Text("HAirPLNmo", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = MainText)
        Spacer(Modifier.height(6.dp))
        Text("选择版本，开始使用", fontSize = 14.sp, color = SubText)
        Spacer(Modifier.height(30.dp))
        OptionCard(
            iconBg = Color(0xFFFBEBC4),
            icon = Icons.Filled.Key,
            iconTint = Color(0xFFC98A1E),
            title = "高级版-卡密",
            sub = "输入卡密，解锁完整功能",
            onClick = onPremium
        )
        Spacer(Modifier.height(14.dp))
        OptionCard(
            iconBg = Color(0xFFC9EEDC),
            icon = Icons.Filled.CardGiftcard,
            iconTint = Color(0xFF1E9E6A),
            title = "免费版",
            sub = "无需卡密，加载后进入首页",
            onClick = onFree
        )
        if (currentUser == AdminUser) {
            Spacer(Modifier.height(14.dp))
            OptionCard(
                iconBg = Color(0xFFDCE4F5),
                icon = Icons.Filled.AdminPanelSettings,
                iconTint = Color(0xFF3B5BDB),
                title = "管理员面板",
                sub = "查看卡密，标记发放状态",
                onClick = onAdmin
            )
        }
        Spacer(Modifier.height(24.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                "当前账号：$currentUser",
                fontSize = 13.sp,
                color = SubText,
                modifier = Modifier.weight(1f)
            )
            TextButton(onClick = onLogout, contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp)) {
                Text("退出登录", fontSize = 13.sp, color = Color(0xFFD0453E))
            }
        }
    }
}

@Composable
fun OptionCard(
    iconBg: Color,
    icon: ImageVector,
    iconTint: Color,
    title: String,
    sub: String,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .background(Color(0xFFF6F6F4), RoundedCornerShape(18.dp))
            .tap(onClick)
            .padding(16.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .size(52.dp)
                    .background(iconBg, RoundedCornerShape(14.dp)),
                contentAlignment = Alignment.Center
            ) {
                Icon(icon, contentDescription = null, tint = iconTint, modifier = Modifier.size(26.dp))
            }
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(title, fontSize = 16.sp, fontWeight = FontWeight.Bold, color = MainText)
                Spacer(Modifier.height(3.dp))
                Text(sub, fontSize = 12.sp, color = SubText)
            }
            Icon(Icons.Filled.ChevronRight, contentDescription = null, tint = Color(0xFFB9BEC9))
        }
    }
}

@Composable
fun PremiumScreen(onBack: () -> Unit, onBuy: () -> Unit, currentUser: String) {
    val context = LocalContext.current
    var key by remember { mutableStateOf("") }
    var msg by remember { mutableStateOf("") }
    var msgColor by remember { mutableStateOf(AccentColor) }
    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(28.dp)
                .background(CardColor, RoundedCornerShape(22.dp))
                .padding(22.dp)
        ) {
            TextButton(onClick = onBack, contentPadding = PaddingValues(0.dp)) {
                Text("← 返回", fontSize = 14.sp, color = SubText)
            }
            Spacer(Modifier.height(8.dp))
            Text("请输入卡密以解锁", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = MainText)
            Spacer(Modifier.height(18.dp))
            FloatField(
                value = key,
                onValueChange = {
                    key = it
                    msg = ""
                },
                label = "输入卡密",
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(16.dp))
            Button(
                onClick = {
                    val input = key.trim().uppercase()
                    val boundAccount = getKeyBoundAccount(context, input)
                    when {
                        key.isBlank() -> {
                            msg = "请输入卡密"
                            msgColor = AccentColor
                        }
                        !ValidKeys.contains(input) -> {
                            msg = "卡密无效"
                            msgColor = AccentColor
                        }
                        boundAccount != null && boundAccount != currentUser -> {
                            msg = "该卡密已绑定其他账号"
                            msgColor = Color(0xFFD0453E)
                        }
                        isKeyUsed(context, input) -> {
                            msg = "该卡密已被使用"
                            msgColor = Color(0xFFD0453E)
                        }
                        else -> {
                            if (boundAccount == null) bindKey(context, input, currentUser)
                            msg = "卡密正确，已绑定本账号并解锁高级版"
                            msgColor = Color(0xFF1E9E6A)
                        }
                    }
                },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = AccentColor)
            ) {
                Text("确定", fontSize = 15.sp, fontWeight = FontWeight.Bold)
            }
            if (msg.isNotEmpty()) {
                Spacer(Modifier.height(12.dp))
                Text(msg, fontSize = 14.sp, color = msgColor, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
            }
            Spacer(Modifier.height(10.dp))
            TextButton(
                onClick = onBuy,
                modifier = Modifier.fillMaxWidth(),
                contentPadding = PaddingValues(6.dp)
            ) {
                Text("购买卡密", fontSize = 14.sp, color = SubText)
            }
        }
    }
}

val ValidKeys = listOf(
    "HAIR-KVMQ-WYJH-3MKY", "HAIR-TB6H-XJET-KCSF", "HAIR-WTEM-UKG4-A8DS",
    "HAIR-7MCY-NSNB-P44T", "HAIR-D28F-GHHH-522R", "HAIR-XJ6X-2JMS-Z4WV",
    "HAIR-7EZV-7KFL-7ETC", "HAIR-RS6R-5RWB-2HA3", "HAIR-BUJ3-D62Y-FHGH",
    "HAIR-4MZM-44BA-MMD6", "HAIR-FDU7-5ECA-MCHV", "HAIR-J2M6-GCQQ-T4CX",
    "HAIR-QJJR-Q83P-PAQV", "HAIR-7GDQ-NCAW-SP6G", "HAIR-E8F4-XWWK-2959",
    "HAIR-D69F-84KV-2S77", "HAIR-L3EL-4T8Q-B7KL", "HAIR-DEYZ-T6QH-Z4VE",
    "HAIR-7W8S-LBKG-9C2U", "HAIR-U5E8-NX4A-5QTV", "HAIR-YYAE-C27L-3RQ2",
    "HAIR-CE7J-D89R-GNZW", "HAIR-JWSG-K4RK-P5DJ", "HAIR-UD4S-S628-G8JD",
    "HAIR-V6EM-GK9W-BC7G", "HAIR-29P2-HADB-U9K6", "HAIR-93VD-LZ8N-73TG",
    "HAIR-5Z38-5MKF-WBPN", "HAIR-X8EJ-NATW-4EEY", "HAIR-PCKA-3CFH-HSV3"
)

fun isKeyUsed(context: Context, key: String): Boolean {
    return (context.getSharedPreferences("hairplnmo", Context.MODE_PRIVATE)
        .getStringSet("used_keys", emptySet()) ?: emptySet()).contains(key)
}

fun bindKey(context: Context, key: String, account: String) {
    val sp = context.getSharedPreferences("hairplnmo", Context.MODE_PRIVATE)
    val binds = (sp.getStringSet("bindings", emptySet()) ?: emptySet()).toMutableSet()
    binds.add("$key|$account")
    sp.edit().putStringSet("bindings", binds).apply()
}

fun getKeyBoundAccount(context: Context, key: String): String? {
    val binds = context.getSharedPreferences("hairplnmo", Context.MODE_PRIVATE)
        .getStringSet("bindings", emptySet()) ?: emptySet()
    return binds.firstOrNull { it.substringBefore('|') == key }?.substringAfter('|')
}

val AdminUser = "admin"
val AdminPass = "HAIR-ADMIN-2026"

fun getLoggedInUser(context: Context): String {
    return context.getSharedPreferences("hairplnmo", Context.MODE_PRIVATE).getString("logged_user", "") ?: ""
}

fun setLoggedInUser(context: Context, user: String) {
    context.getSharedPreferences("hairplnmo", Context.MODE_PRIVATE).edit().putString("logged_user", user).apply()
}

fun checkLogin(context: Context, user: String, pass: String): String {
    if (user == AdminUser) return if (pass == AdminPass) "ok" else "密码错误"
    if (user == "123456") return if (pass == "123456") "ok" else "密码错误"
    val users = context.getSharedPreferences("hairplnmo", Context.MODE_PRIVATE)
        .getStringSet("accounts", emptySet()) ?: emptySet()
    return if (users.contains("$user|$pass")) "ok" else "账号或密码错误"
}

fun registerAccount(context: Context, user: String, pass: String): String {
    val sp = context.getSharedPreferences("hairplnmo", Context.MODE_PRIVATE)
    val users = sp.getStringSet("accounts", emptySet()) ?: emptySet()
    return when {
        user.isBlank() || pass.isBlank() -> "账号和密码不能为空"
        user == AdminUser || user == "123456" || users.any { it.substringBefore('|') == user } -> "该账号已存在"
        else -> {
            sp.edit().putStringSet("accounts", users + "$user|$pass").apply()
            "注册成功"
        }
    }
}

fun openPayApp(context: Context, pkg: String): Boolean = try {
    context.packageManager.getLaunchIntentForPackage(pkg)?.let {
        it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(it)
        true
    } ?: false
} catch (e: Exception) {
    false
}

@Composable
fun PurchaseScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val plans = listOf(
        Triple("1元", "0.9元", "功能不完全"),
        Triple("2元", "1.99元", "功能有点完整"),
        Triple("5元", "2.99元", "功能完整"),
        Triple("10元", "9.9元", "功能全齐")
    )
    var selected by remember { mutableStateOf(0) }
    var showConfirm by remember { mutableStateOf(false) }
    var showPayMethod by remember { mutableStateOf(false) }
    var payAppName by remember { mutableStateOf("") }
    var waiting by remember { mutableStateOf(false) }
    var jumpMsg by remember { mutableStateOf("") }
    var testKey by remember { mutableStateOf("") }
    var showTestSuccess by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(BgColor)
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            TextButton(onClick = onBack, contentPadding = PaddingValues(0.dp)) {
                Text("← 返回", fontSize = 14.sp, color = SubText)
            }
        }
        Text("购买卡密", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = MainText)
        Spacer(Modifier.height(6.dp))
        Text("选择套餐，支付后联系管理员领取卡密", fontSize = 13.sp, color = SubText)
        Spacer(Modifier.height(10.dp))
        Text(
            "支付说明：支付后钱款作废删除，不会进入任何账户。",
            fontSize = 12.sp,
            color = Color(0xFFB07A1E),
            lineHeight = 18.sp,
            modifier = Modifier
                .fillMaxWidth()
                .background(Color(0xFFFDF4E3), RoundedCornerShape(10.dp))
                .padding(horizontal = 12.dp, vertical = 8.dp)
        )
        Spacer(Modifier.height(20.dp))
        plans.forEachIndexed { i, (orig, price, desc) ->
            PlanCard(orig, price, desc, selected == i) { selected = i }
            Spacer(Modifier.height(14.dp))
        }
        Spacer(Modifier.height(10.dp))
        Button(
            onClick = { showConfirm = true },
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(14.dp),
            colors = ButtonDefaults.buttonColors(containerColor = AccentColor)
        ) {
            Text("购买", fontSize = 16.sp, fontWeight = FontWeight.Bold)
        }
        if (jumpMsg.isNotEmpty()) {
            Spacer(Modifier.height(12.dp))
            Text(jumpMsg, fontSize = 13.sp, color = Color(0xFFD0453E), modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
        }
        Spacer(Modifier.height(24.dp))
    }

    if (showConfirm) {
        AlertDialog(
            onDismissRequest = { showConfirm = false },
            title = { Text("确定支付？", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = MainText) },
            text = { Text("支付后钱款将作废删除，不会进入任何账户，也无法退钱。", fontSize = 14.sp, color = SubText, lineHeight = 20.sp) },
            confirmButton = {
                TextButton(onClick = {
                    showConfirm = false
                    showPayMethod = true
                }) { Text("确定", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = AccentColor) }
            },
            dismissButton = {
                TextButton(onClick = { showConfirm = false }) { Text("取消", fontSize = 15.sp, color = SubText) }
            }
        )
    }

    if (showPayMethod) {
        AlertDialog(
            onDismissRequest = { showPayMethod = false },
            title = { Text("选择支付方式", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = MainText) },
            text = {
                Column {
                    Button(
                        onClick = {
                            showPayMethod = false
                            payAppName = "支付宝"
                            jumpMsg = if (openPayApp(context, "com.eg.android.AlipayGphone")) "" else "未安装支付宝"
                            waiting = jumpMsg.isEmpty()
                        },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1677FF))
                    ) {
                        Text("支付宝", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = Color.White)
                    }
                    Spacer(Modifier.height(10.dp))
                    Button(
                        onClick = {
                            showPayMethod = false
                            payAppName = "微信"
                            jumpMsg = if (openPayApp(context, "com.tencent.mm")) "" else "未安装微信"
                            waiting = jumpMsg.isEmpty()
                        },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E9E6A))
                    ) {
                        Text("微信", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = Color.White)
                    }
                    Spacer(Modifier.height(10.dp))
                    Button(
                        onClick = {
                            showPayMethod = false
                            val unused = ValidKeys.firstOrNull { !isKeyUsed(context, it) }
                            if (unused == null) {
                                jumpMsg = "测试购买：卡密已用完，请联系管理员补充"
                            } else {
                                testKey = unused
                                showTestSuccess = true
                            }
                        },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFB07A1E))
                    ) {
                        Text("测试购买", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = Color.White)
                    }
                }
            },
            confirmButton = {},
            dismissButton = {}
        )
    }

    if (showTestSuccess) {
        AlertDialog(
            onDismissRequest = { },
            title = { Text("支付成功（测试）", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = MainText) },
            text = {
                Column {
                    Text("测试购买成功！以下是你的卡密：", fontSize = 14.sp, color = SubText)
                    Spacer(Modifier.height(8.dp))
                    Text(testKey, fontSize = 17.sp, fontWeight = FontWeight.Bold, color = AccentColor)
                    Spacer(Modifier.height(8.dp))
                    Text("回到卡密输入框输入它即可解锁，可用来测试绑定流程。", fontSize = 14.sp, color = SubText, lineHeight = 20.sp)
                }
            },
            confirmButton = {
                TextButton(onClick = { showTestSuccess = false }) { Text("确定", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = AccentColor) }
            },
            dismissButton = {}
        )
    }

    if (waiting) {
        AlertDialog(
            onDismissRequest = { },
            title = { Text("等待支付完成", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = MainText) },
            text = { Text("已跳转到${payAppName}。完成支付后，请将付款截图发给管理员领取卡密，回到本应用输入卡密即可解锁。", fontSize = 14.sp, color = SubText, lineHeight = 20.sp) },
            confirmButton = {
                TextButton(onClick = { waiting = false }) { Text("我知道了", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = AccentColor) }
            },
            dismissButton = {
                TextButton(onClick = { waiting = false }) { Text("取消", fontSize = 15.sp, color = SubText) }
            }
        )
    }
}

@Composable
fun PlanCard(orig: String, price: String, desc: String, selected: Boolean, onClick: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(CardColor, RoundedCornerShape(18.dp))
            .then(if (selected) Modifier.border(2.dp, AccentColor, RoundedCornerShape(18.dp)) else Modifier)
            .tap(onClick)
            .padding(18.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(orig, fontSize = 13.sp, color = SubText, textDecoration = TextDecoration.LineThrough)
            Spacer(Modifier.height(4.dp))
            Text(price, fontSize = 24.sp, fontWeight = FontWeight.Bold, color = if (selected) AccentColor else MainText)
            Spacer(Modifier.height(4.dp))
            Text(desc, fontSize = 13.sp, color = SubText)
        }
        Box(
            modifier = Modifier
                .size(24.dp)
                .then(
                    if (selected) Modifier.background(AccentColor, CircleShape)
                    else Modifier.border(2.dp, Color(0xFFC6CCD8), CircleShape)
                ),
            contentAlignment = Alignment.Center
        ) {
            if (selected) {
                Icon(Icons.Filled.Check, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
            }
        }
    }
}

@Composable
fun LoginScreen(onSuccess: (String) -> Unit) {
    val context = LocalContext.current
    var mode by remember { mutableStateOf("login") }
    var user by remember { mutableStateOf("") }
    var pass by remember { mutableStateOf("") }
    var msg by remember { mutableStateOf("") }
    var msgColor by remember { mutableStateOf(AccentColor) }
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFFFFFFF))
            .padding(horizontal = 28.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Box(
            modifier = Modifier
                .size(64.dp)
                .background(Color(0xFF1C1C1E), RoundedCornerShape(18.dp)),
            contentAlignment = Alignment.Center
        ) {
            Icon(Icons.Filled.Handyman, contentDescription = null, tint = Color.White, modifier = Modifier.size(30.dp))
        }
        Spacer(Modifier.height(16.dp))
        Text("HAirPLNmo", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = MainText)
        Spacer(Modifier.height(6.dp))
        Text(if (mode == "login") "登录以继续" else "创建新账号", fontSize = 14.sp, color = SubText)
        Spacer(Modifier.height(30.dp))
        FloatField(
            value = user,
            onValueChange = { user = it; msg = "" },
            label = "账号",
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(14.dp))
        FloatField(
            value = pass,
            onValueChange = { pass = it; msg = "" },
            label = "密码",
            modifier = Modifier.fillMaxWidth(),
            isPassword = true
        )
        Spacer(Modifier.height(20.dp))
        Button(
            onClick = {
                if (mode == "login") {
                    val r = checkLogin(context, user.trim(), pass)
                    if (r == "ok") {
                        setLoggedInUser(context, user.trim())
                        onSuccess(user.trim())
                    } else {
                        msg = r
                        msgColor = Color(0xFFD0453E)
                    }
                } else {
                    val r = registerAccount(context, user.trim(), pass)
                    if (r == "注册成功") {
                        mode = "login"
                        pass = ""
                        msg = "注册成功，请登录"
                        msgColor = Color(0xFF1E9E6A)
                    } else {
                        msg = r
                        msgColor = Color(0xFFD0453E)
                    }
                }
            },
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp),
            colors = ButtonDefaults.buttonColors(containerColor = AccentColor)
        ) {
            Text(if (mode == "login") "登录" else "注册", fontSize = 15.sp, fontWeight = FontWeight.Bold)
        }
        if (msg.isNotEmpty()) {
            Spacer(Modifier.height(12.dp))
            Text(msg, fontSize = 14.sp, color = msgColor, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
        }
        Spacer(Modifier.height(10.dp))
        TextButton(onClick = {
            mode = if (mode == "login") "register" else "login"
            msg = ""
        }, contentPadding = PaddingValues(6.dp)) {
            Text(
                if (mode == "login") "没有账号？去注册" else "已有账号？去登录",
                fontSize = 13.sp,
                color = SubText
            )
        }
    }
}

@Composable
fun AdminScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    var issued by remember {
        mutableStateOf(
            context.getSharedPreferences("hairplnmo", Context.MODE_PRIVATE)
                .getStringSet("issued_keys", emptySet()) ?: emptySet()
        )
    }
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(BgColor)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            TextButton(onClick = onBack, contentPadding = PaddingValues(0.dp)) {
                Text("← 返回", fontSize = 14.sp, color = SubText)
            }
        }
        Column(Modifier.padding(horizontal = 20.dp)) {
            Text("管理员面板", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = MainText)
            Spacer(Modifier.height(6.dp))
            Text(
                "卡密共 ${ValidKeys.size} 个，已发放 ${issued.size} 个。点一下卡密可切换发放状态。",
                fontSize = 13.sp,
                color = SubText,
                lineHeight = 19.sp
            )
            Spacer(Modifier.height(16.dp))
        }
        Column(
            modifier = Modifier
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp)
        ) {
            ValidKeys.forEach { k ->
                val boundAccount = getKeyBoundAccount(context, k)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(CardColor, RoundedCornerShape(14.dp))
                        .tap {
                            val next = issued.toMutableSet()
                            if (next.contains(k)) next.remove(k) else next.add(k)
                            context.getSharedPreferences("hairplnmo", Context.MODE_PRIVATE)
                                .edit().putStringSet("issued_keys", next).apply()
                            issued = next
                        }
                        .padding(horizontal = 16.dp, vertical = 14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(Modifier.weight(1f)) {
                        Text(k, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = MainText)
                        if (boundAccount != null) {
                            Spacer(Modifier.height(3.dp))
                            Text("绑定账号：$boundAccount", fontSize = 12.sp, color = Color(0xFF3B5BDB))
                        }
                    }
                    Text(
                        if (issued.contains(k)) "已发放" else "未发放",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (issued.contains(k)) Color(0xFFD0453E) else Color(0xFF1E9E6A)
                    )
                }
                Spacer(Modifier.height(8.dp))
            }
            Spacer(Modifier.height(24.dp))
        }
    }
}

@Composable
fun LoadingScreen(onDone: () -> Unit) {
    LaunchedEffect(Unit) {
        delay(1800)
        onDone()
    }
    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            CircularProgressIndicator(color = AccentColor)
            Spacer(Modifier.height(16.dp))
            Text("加载中…", fontSize = 14.sp, color = SubText)
        }
    }
}

@Composable
fun HomeScreen() {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFF2F0EB))
            .verticalScroll(rememberScrollState())
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(44.dp)
                    .background(Color(0xFF1C1C1E), RoundedCornerShape(12.dp)),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Filled.Build, contentDescription = null, tint = Color.White, modifier = Modifier.size(22.dp))
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text("HAirPLNmo", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = MainText)
                Spacer(Modifier.height(2.dp))
                Text("本地工具箱", fontSize = 12.sp, color = SubText)
            }
            Box(
                modifier = Modifier
                    .background(Color(0xFFC9EEDC), RoundedCornerShape(999.dp))
                    .padding(horizontal = 12.dp, vertical = 5.dp)
            ) {
                Text("免费版", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color(0xFF1E9E6A))
            }
            Spacer(Modifier.width(10.dp))
            Icon(Icons.Filled.MoreVert, contentDescription = null, tint = MainText)
        }
        Column(Modifier.padding(horizontal = 20.dp)) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color.White, RoundedCornerShape(20.dp))
                    .padding(20.dp)
            ) {
                Text("欢迎使用", fontSize = 13.sp, color = SubText)
                Spacer(Modifier.height(6.dp))
                Text("HAirPLNmo 免费版", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = MainText)
                Spacer(Modifier.height(8.dp))
                Text(
                    "常用工具正在陆续恢复中，敬请期待更多功能。",
                    fontSize = 14.sp,
                    color = Color(0xFF5A5F6B),
                    lineHeight = 22.sp
                )
            }
            Spacer(Modifier.height(24.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("工具", fontSize = 17.sp, fontWeight = FontWeight.Bold, color = MainText, modifier = Modifier.weight(1f))
                Text("开发中", fontSize = 13.sp, color = SubText)
            }
            Spacer(Modifier.height(14.dp))
            Row(Modifier.fillMaxWidth()) {
                ToolCard("哈希工具", "计算各类哈希值", Icons.Filled.Tag, Modifier.weight(1f))
                Spacer(Modifier.width(14.dp))
                ToolCard("文件修改器", "查找、替换、定位", Icons.Filled.EditNote, Modifier.weight(1f))
            }
            Spacer(Modifier.height(14.dp))
            Row(Modifier.fillMaxWidth()) {
                ToolCard("打包工具", "极速打包安装包", Icons.Filled.Inventory2, Modifier.weight(1f))
                Spacer(Modifier.width(14.dp))
                ToolCard("APK 分析", "安装包信息解析", Icons.Filled.Brush, Modifier.weight(1f))
            }
            Spacer(Modifier.height(14.dp))
            Row(Modifier.fillMaxWidth()) {
                ToolCard("加密工具", "加盐哈希与乱码", Icons.Filled.VerifiedUser, Modifier.weight(1f))
                Spacer(Modifier.width(14.dp))
                ToolCard("更多工具", "陆续上架中", Icons.Filled.Apps, Modifier.weight(1f))
            }
            Spacer(Modifier.height(28.dp))
            Text(
                "HAirPLNmo · 免费版",
                fontSize = 12.sp,
                color = Color(0xFFB9B4AA),
                modifier = Modifier.fillMaxWidth(),
                textAlign = TextAlign.Center
            )
            Spacer(Modifier.height(20.dp))
        }
    }
}

@Composable
fun ToolCard(title: String, sub: String, icon: ImageVector, modifier: Modifier = Modifier) {
    Column(
        modifier = modifier
            .background(Color.White, RoundedCornerShape(18.dp))
            .padding(16.dp)
    ) {
        Box(
            modifier = Modifier
                .size(48.dp)
                .background(Color(0xFFF0EEE8), RoundedCornerShape(14.dp)),
            contentAlignment = Alignment.Center
        ) {
            Icon(icon, contentDescription = null, tint = Color(0xFF3A3F4A), modifier = Modifier.size(24.dp))
        }
        Spacer(Modifier.height(12.dp))
        Text(title, fontSize = 16.sp, fontWeight = FontWeight.Bold, color = MainText)
        Spacer(Modifier.height(3.dp))
        Text(sub, fontSize = 12.sp, color = SubText)
        Spacer(Modifier.height(10.dp))
        Box(
            modifier = Modifier
                .background(Color(0xFFEFEDE8), RoundedCornerShape(999.dp))
                .padding(horizontal = 10.dp, vertical = 4.dp)
        ) {
            Text("敬请期待", fontSize = 11.sp, color = Color(0xFF8A8A85))
        }
    }
}
