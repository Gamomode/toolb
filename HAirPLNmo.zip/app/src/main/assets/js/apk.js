(function () {
  'use strict';

  var OUTPUT_NAME = 'HAirPLNmo.zip';

  var APP_FILES = [
    'index.html',
    'manifest.json',
    'sw.js',
    'icon.svg',
    'css/base.css',
    'css/layout.css',
    'css/components.css',
    'css/chat.css',
    'css/notice.css',
    'js/store.js',
    'js/server.js',
    'js/ai.js',
    'js/export.js',
    'js/assistant.js',
    'js/apk.js',
    'js/ui.js',
    'js/app.js'
  ];

  function pkgPath(pkg) {
    return String(pkg || 'com.offline.workbench').split('.').filter(Boolean).join('/');
  }

  function safeName(pkg) {
    return String(pkg || 'com.offline.workbench').replace(/[^a-zA-Z0-9.]/g, '') || 'com.offline.workbench';
  }

  function manifestXml(pkg) {
    return [
      '<?xml version="1.0" encoding="utf-8"?>',
      '<manifest xmlns:android="http://schemas.android.com/apk/res/android">',
      '',
      '    <uses-permission android:name="android.permission.INTERNET" />',
      '',
      '    <application',
      '        android:allowBackup="true"',
      '        android:icon="@mipmap/ic_launcher"',
      '        android:label="@string/app_name"',
      '        android:supportsRtl="true"',
      '        android:usesCleartextTraffic="true"',
      '        android:theme="@style/Theme.Workbench">',
      '        <activity',
      '            android:name=".MainActivity"',
      '            android:configChanges="orientation|screenSize|keyboardHidden"',
      '            android:exported="true">',
      '            <intent-filter>',
      '                <action android:name="android.intent.action.MAIN" />',
      '                <category android:name="android.intent.category.LAUNCHER" />',
      '            </intent-filter>',
      '        </activity>',
      '    </application>',
      '',
      '</manifest>'
    ].join('\n');
  }

  function activityJava(pkg) {
    return [
      'package ' + pkg + ';',
      '',
      'import android.os.Bundle;',
      'import android.view.KeyEvent;',
      'import android.webkit.WebSettings;',
      'import android.webkit.WebView;',
      'import android.webkit.WebViewClient;',
      'import androidx.appcompat.app.AppCompatActivity;',
      '',
      'public class MainActivity extends AppCompatActivity {',
      '',
      '    private WebView webView;',
      '',
      '    @Override',
      '    protected void onCreate(Bundle savedInstanceState) {',
      '        super.onCreate(savedInstanceState);',
      '        webView = new WebView(this);',
      '        setContentView(webView);',
      '',
      '        WebSettings s = webView.getSettings();',
      '        s.setJavaScriptEnabled(true);',
      '        s.setDomStorageEnabled(true);',
      '        s.setDatabaseEnabled(true);',
      '        s.setAllowFileAccess(true);',
      '        s.setAllowContentAccess(true);',
      '        s.setSupportZoom(false);',
      '        s.setUseWideViewPort(true);',
      '        s.setLoadWithOverviewMode(true);',
      '        s.setCacheMode(WebSettings.LOAD_DEFAULT);',
      '',
      '        webView.setWebViewClient(new WebViewClient());',
      '        webView.loadUrl("file:///android_asset/index.html");',
      '    }',
      '',
      '    @Override',
      '    public boolean onKeyDown(int keyCode, KeyEvent event) {',
      '        if (keyCode == KeyEvent.KEYCODE_BACK && webView != null && webView.canGoBack()) {',
      '            webView.goBack();',
      '            return true;',
      '        }',
      '        return super.onKeyDown(keyCode, event);',
      '    }',
      '',
      '    @Override',
      '    protected void onDestroy() {',
      '        if (webView != null) {',
      '            webView.destroy();',
      '            webView = null;',
      '        }',
      '        super.onDestroy();',
      '    }',
      '}'
    ].join('\n');
  }

  function rootBuild() {
    return [
      '// 顶层构建脚本',
      'plugins {',
      '    id "com.android.application" version "8.1.4" apply false',
      '}'
    ].join('\n');
  }

  function settingsGradle(name) {
    return [
      'pluginManagement {',
      '    repositories {',
      '        google()',
      '        mavenCentral()',
      '        gradlePluginPortal()',
      '    }',
      '}',
      'dependencyResolutionManagement {',
      '    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)',
      '    repositories {',
      '        google()',
      '        mavenCentral()',
      '    }',
      '}',
      '',
      "rootProject.name = '" + name + "'",
      "include ':app'"
    ].join('\n');
  }

  function appBuild(pkg, versionName, versionCode) {
    return [
      'plugins {',
      '    id "com.android.application"',
      '}',
      '',
      'android {',
      '    namespace "' + pkg + '"',
      '    compileSdk 34',
      '',
      '    defaultConfig {',
      '        applicationId "' + pkg + '"',
      '        minSdk 23',
      '        targetSdk 34',
      '        versionCode ' + versionCode,
      '        versionName "' + versionName + '"',
      '    }',
      '',
      '    buildTypes {',
      '        release {',
      '            minifyEnabled false',
      '            signingConfig signingConfigs.debug',
      '            proguardFiles getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro"',
      '        }',
      '    }',
      '',
      '    compileOptions {',
      '        sourceCompatibility JavaVersion.VERSION_17',
      '        targetCompatibility JavaVersion.VERSION_17',
      '    }',
      '}',
      '',
      'dependencies {',
      '    implementation "androidx.appcompat:appcompat:1.6.1"',
      '}'
    ].join('\n');
  }

  function gradleProps() {
    return [
      'org.gradle.jvmargs=-Xmx2048m -Dfile.encoding=UTF-8',
      'android.useAndroidX=true',
      'android.nonTransitiveRClass=true'
    ].join('\n');
  }

  function stringsXml(appName) {
    return [
      '<?xml version="1.0" encoding="utf-8"?>',
      '<resources>',
      '    <string name="app_name">' + appName + '</string>',
      '</resources>'
    ].join('\n');
  }

  function stylesXml() {
    return [
      '<?xml version="1.0" encoding="utf-8"?>',
      '<resources>',
      '    <style name="Theme.Workbench" parent="Theme.AppCompat.NoActionBar">',
      '        <item name="android:windowBackground">#0D100E</item>',
      '        <item name="android:statusBarColor">#0D100E</item>',
      '        <item name="android:navigationBarColor">#131814</item>',
      '    </style>',
      '</resources>'
    ].join('\n');
  }

  function workflow(name) {
    return [
      'name: Build APK',
      '',
      'on:',
      '  push:',
      '    branches: [ main, master ]',
      '  workflow_dispatch:',
      '',
      'jobs:',
      '  build:',
      '    runs-on: ubuntu-latest',
      '    steps:',
      '      - uses: actions/checkout@v4',
      '      - uses: actions/setup-java@v4',
      '        with:',
      '          distribution: temurin',
      '          java-version: "17"',
      '      - name: Setup Gradle',
      '        uses: gradle/actions/setup-gradle@v3',
      '        with:',
      '          gradle-version: "8.2"',
      '      - name: Build debug APK',
      '        run: gradle assembleDebug --no-daemon',
      '      - name: Upload APK',
      '        uses: actions/upload-artifact@v4',
      '        with:',
      '          name: ' + name + '-apk',
      '          path: app/build/outputs/apk/debug/app-debug.apk'
    ].join('\n');
  }

  function readme(appName, pkg) {
    return [
      '# ' + appName + ' · Android 工程',
      '',
      '这是由「AI 逆向工作台」生成的 WebView 壳工程，网页本体已放在 `app/src/main/assets/`。',
      '导出文件名：`' + OUTPUT_NAME + '`',
      '',
      '## 方式一：GitHub Actions 编译（推荐，不用装环境）',
      '1. 打开 https://github.com/ 并新建一个仓库。',
      '2. 把 `' + OUTPUT_NAME + '` 解压后的全部文件上传到仓库根目录（包含 `.github/workflows/build-apk.yml`）。',
      '3. 推送到 main 分支后自动触发构建，进入仓库的 Actions 页面查看进度。',
      '4. 构建完成后在该次运行的 Artifacts 里下载 APK，解压即得到 `app-debug.apk`。',
      '',
      '## 方式二：本地构建',
      '1. 安装 Android Studio（含 JDK 17）。',
      '2. 用 Android Studio 打开本目录，等待 Gradle 同步。',
      '3. 菜单 Build → Build App Bundle(s) / APK(s) → Build APK(s)。',
      '4. 产物在 `app/build/outputs/apk/debug/app-debug.apk`。',
      '',
      '## 安装到手机',
      '1. 把 APK 传到手机（数据线 / 微信文件传输 / 网盘均可）。',
      '2. 在文件管理里点击 APK，允许「安装未知来源应用」。',
      '3. 安装完成后桌面出现图标，断网也能正常使用。',
      '',
      '## 包名与版本',
      '- applicationId：`' + pkg + '`',
      '- 修改包名后需要同步修改 `app/src/main/java/` 下的目录结构。',
      '',
      '## 说明',
      '- 网页资源全部内置在 APK 里，运行时不联网。',
      '- 数据保存在 WebView 的 localStorage 中，卸载应用即清除。',
      '- 导出 ZIP 功能依赖 JSZip，首次使用需联网加载，其余功能完全离线。'
    ].join('\n');
  }

  function collectAssets() {
    return Promise.all(APP_FILES.map(function (p) {
      return fetch(p, { cache: 'no-store' })
        .then(function (r) {
          return r.ok ? r.text() : null;
        })
        .catch(function () {
          return null;
        })
        .then(function (t) {
          return t == null ? null : { path: p, content: t };
        });
    })).then(function (arr) {
      return arr.filter(function (x) {
        return !!x;
      });
    });
  }

  function build(cfg) {
    var pkg = safeName(cfg.packageName);
    var appName = String(cfg.appName || 'AI 逆向工作台').replace(/[<>&"]/g, '');
    var versionName = String(cfg.versionName || '1.0.0');
    var versionCode = parseInt(cfg.versionCode, 10) || 1;
    var projectName = 'AIReverseWorkbench';

    var JSZip = window.JSZip;
    if (!JSZip) {
      return Promise.reject(new Error('JSZip 未加载，请联网后重试'));
    }

    return collectAssets().then(function (assets) {
      if (!assets.length) {
        throw new Error('无法读取自身源码，请通过 http 服务打开页面');
      }

      var zip = new JSZip();

      zip.file('settings.gradle', settingsGradle(projectName));
      zip.file('build.gradle', rootBuild());
      zip.file('gradle.properties', gradleProps());
      zip.file('app/build.gradle', appBuild(pkg, versionName, versionCode));
      zip.file('app/proguard-rules.pro', '# 保持 WebView 与 JS 接口\n-keepclassmembers class * {\n    @android.webkit.JavascriptInterface <methods>;\n}');
      zip.file('app/src/main/AndroidManifest.xml', manifestXml(pkg));
      zip.file('app/src/main/java/' + pkgPath(pkg) + '/MainActivity.java', activityJava(pkg));
      zip.file('app/src/main/res/values/strings.xml', stringsXml(appName));
      zip.file('app/src/main/res/values/styles.xml', stylesXml());
      zip.file('.github/workflows/build-apk.yml', workflow(projectName));
      zip.file('README.md', readme(appName, pkg));

      assets.forEach(function (a) {
        zip.file('app/src/main/assets/' + a.path, a.content);
      });

      return zip.generateAsync({
        type: 'blob',
        compression: 'DEFLATE',
        compressionOptions: { level: 6 }
      }).then(function (blob) {
        return {
          blob: blob,
          name: OUTPUT_NAME,
          files: assets.length
        };
      });
    });
  }

  window.Apk = {
    build: build,
    outputName: OUTPUT_NAME,
    assets: APP_FILES
  };
})();