(function () {
  'use strict';

  var root = null;
  var current = 'server';
  var sheetPath = '';

  function esc(s) {
    return String(s == null ? '' : s)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  }

  function rich(text) {
    var segs = String(text || '').split('```');
    var out = '';
    for (var i = 0; i < segs.length; i++) {
      if (i % 2 === 1) {
        var code = segs[i].replace(/^[a-zA-Z0-9#+-]*\r?\n/, '');
        out += '<pre class="code">' + esc(code.replace(/\s+$/, '')) + '</pre>';
      } else {
        out += esc(segs[i]).replace(/\n/g, '<br>');
      }
    }
    return out;
  }

  function ext(p) {
    var m = /\.([a-zA-Z0-9]+)$/.exec(String(p || ''));
    return m ? m[1].toUpperCase().slice(0, 4) : 'TXT';
  }

  function size(n) {
    if (n < 1024) return n + ' B';
    if (n < 1048576) return (n / 1024).toFixed(1) + ' KB';
    return (n / 1048576).toFixed(1) + ' MB';
  }

  function metric(label, value, pct) {
    return '<div class="metric">' +
      '<div class="metric-top"><span>' + esc(label) + '</span><b>' + esc(value) + '</b></div>' +
      '<div class="bar"><i style="width:' + Math.max(0, Math.min(100, pct)) + '%"></i></div>' +
      '</div>';
  }

  /* ---------- 服务器 ---------- */

  function viewServer(st) {
    var c = st.connection;
    var online = c.status === 'online';
    return '' +
      '<section class="card">' +
      '  <div class="card-head"><h2>连接设置</h2><span class="badge' + (online ? ' ok' : '') + '">' + (online ? '在线' : c.status === 'connecting' ? '连接中' : '离线镜像') + '</span></div>' +
      '  <label class="field"><span>主机 / WebSocket 地址</span>' +
      '    <input id="cfg-host" type="text" inputmode="url" placeholder="192.168.1.10 或 wss://host" value="' + esc(c.host) + '">' +
      '  </label>' +
      '  <label class="field"><span>端口</span>' +
      '    <input id="cfg-port" type="number" inputmode="numeric" placeholder="8765" value="' + esc(c.port) + '">' +
      '  </label>' +
      '  <label class="field"><span>Token（可选）</span>' +
      '    <input id="cfg-token" type="text" placeholder="连接凭证" value="' + esc(c.token) + '">' +
      '  </label>' +
      '  <div class="toolbar">' +
      '    <button class="btn primary" type="button" data-act="server-connect">连接</button>' +
      '    <button class="btn ghost" type="button" data-act="server-offline">离线模式</button>' +
      '  </div>' +
      '  <p class="muted mt12">连不上会自动降级为本地离线镜像，所有功能照常可用。</p>' +
      '</section>' +

      '<section class="card">' +
      '  <div class="card-head"><h2>运行状态</h2></div>' +
      metric('连接状态', online ? '在线' : '离线', online ? 100 : 45) +
      metric('延迟', online ? c.latency + ' ms' : '—', online ? Math.max(8, 100 - c.latency / 5) : 0) +
      metric('工作区文件', st.files.length + ' 个', Math.min(100, st.files.length * 12)) +
      metric('占用空间', size(st.files.reduce(function (a, f) { return a + (f.content || '').length; }, 0)), Math.min(100, st.files.length * 9)) +
      '</section>' +

      '<section class="card">' +
      '  <div class="card-head"><h2>连接日志</h2>' +
      '    <button class="btn ghost" type="button" data-act="server-clear">清空</button>' +
      '  </div>' +
      (st.logs.length ? '<ul class="log">' + st.logs.slice().reverse().map(function (l) {
        return '<li><span class="t">' + esc(l.t) + '</span><span class="' + esc(l.level) + '">' + esc(l.text) + '</span></li>';
      }).join('') + '</ul>' : '<div class="empty">暂无日志</div>') +
      '</section>';
  }

  /* ---------- 文件 ---------- */

  function viewFiles(st) {
    var list = st.files.length
      ? '<div class="file-list">' + st.files.map(function (f) {
        return '<div class="file' + (st.activeFile === f.path ? ' sel' : '') + '" data-act="file-open" data-path="' + esc(f.path) + '">' +
          '<div class="fi-icon">' + esc(ext(f.path)) + '</div>' +
          '<div class="fi-main">' +
          '<div class="fi-name">' + esc(f.path.split('/').pop()) + '</div>' +
          '<div class="fi-path">' + esc(f.path) + '</div>' +
          '</div>' +
          '<div class="fi-meta">' + size((f.content || '').length) + '</div>' +
          '<button class="btn ghost" type="button" data-act="file-del" data-path="' + esc(f.path) + '" style="padding:6px 9px;font-size:12px">×</button>' +
          '</div>';
      }).join('') + '</div>'
      : '<div class="empty">还没有文件，新建一个开始吧</div>';

    return '' +
      '<section class="card">' +
      '  <div class="card-head"><h2>工作区</h2><span class="badge">' + st.files.length + ' 个文件</span></div>' +
      '  <div class="inline-form">' +
      '    <input id="new-path" type="text" placeholder="/srv/app/new.js" autocapitalize="off" autocorrect="off">' +
      '    <button class="btn primary" type="button" data-act="file-new">新建</button>' +
      '  </div>' +
      '  <div class="toolbar">' +
      '    <button class="btn" type="button" data-act="file-refresh">从服务器同步</button>' +
      '    <button class="btn ghost" type="button" data-act="file-reset">恢复示例</button>' +
      '  </div>' +
      '</section>' +
      '<section class="card">' + list + '</section>' +
      '<section class="card">' +
      '  <div class="card-head"><h2>当前选中</h2></div>' +
      (st.activeFile
        ? '<p class="muted">' + esc(st.activeFile) + '</p><div class="toolbar mt12">' +
        '<button class="btn" type="button" data-act="file-ask">让 AI 分析它</button>' +
        '</div>'
        : '<div class="empty">点击文件进行编辑</div>') +
      '</section>';
  }

  /* ---------- 逆向 + AI 助手 ---------- */

  function viewReverse(st) {
    var A = window.Assistant;
    var msgs = A ? A.getMessages() : [];
    var quick = A ? A.quick : [];

    var chat = '';
    if (!msgs.length) {
      chat = '<div class="empty">直接提问，或用下面的快捷指令。<br>我能读你工作区里的文件，并给出可应用的修改。</div>';
    } else {
      chat = '<div class="chat-log" id="chat-log">' + msgs.map(function (m, i) {
        var acts = '';
        if (m.actions && m.actions.length) {
          acts = '<div class="acts">' + m.actions.map(function (a, j) {
            return '<button type="button" data-act="ai-action" data-mi="' + i + '" data-ai="' + j + '">' + esc(a.label) + '</button>';
          }).join('') + '</div>';
        }
        return '<div class="msg ' + (m.role === 'user' ? 'me' : 'ai') + '">' +
          '<div class="bubble">' + rich(m.text) + acts + '</div>' +
          '</div>';
      }).join('') + '</div>';
    }

    var chips = quick.map(function (q) {
      return '<button class="chip" type="button" data-act="chat-quick" data-q="' + esc(q) + '">' + esc(q) + '</button>';
    }).join('');

    var cfg = A ? A.getConfig() : { url: '', key: '', model: '' };

    var report = '';
    if (st.report) {
      var r = st.report;
      report = '' +
        '<div class="rep-sec"><h3>概览</h3><ul>' +
        '<li>文件 ' + r.summary.files + ' 个，共 ' + size(r.summary.size) + '</li>' +
        '<li>外部依赖 ' + r.externals.length + ' 个，压缩文件 ' + r.summary.minified + ' 个</li>' +
        '<li>风险点 ' + r.risks.length + ' 类</li>' +
        '</ul></div>' +
        (r.risks.length ? '<div class="rep-sec"><h3>关键点</h3><ul>' + r.risks.map(function (x) {
          return '<li>[' + esc(x.level) + '] ' + esc(x.title) + ' — ' + esc(x.file) + '（' + x.count + ' 处）</li>';
        }).join('') + '</ul></div>' : '') +
        (r.plan.length ? '<div class="rep-sec"><h3>改造方案</h3><ul>' + r.plan.map(function (p) {
          return '<li><b>' + esc(p.title) + '</b>：' + esc(p.detail) + '</li>';
        }).join('') + '</ul></div>' : '');
    } else {
      report = '<div class="empty">还没有分析结果，点右上角「分析」</div>';
    }

    return '' +
      '<section class="card">' +
      '  <div class="card-head"><h2>AI 助手</h2>' +
      '    <button class="btn ghost" type="button" data-act="chat-clear">清空</button>' +
      '  </div>' +
      chat +
      '  <div class="chips mt12">' + chips + '</div>' +
      '  <div class="chat-input">' +
      '    <textarea id="chat-text" rows="1" placeholder="例如：把 main.js 改成离线版" autocapitalize="off" autocorrect="off"></textarea>' +
      '    <button class="btn primary" type="button" data-act="chat-send">发送</button>' +
      '  </div>' +
      '  <div class="cfg-box">' +
      '    <details>' +
      '      <summary class="muted" style="cursor:pointer">接入在线模型（可选，不填则纯本地运行）</summary>' +
      '      <label class="field mt12"><span>接口地址（OpenAI 兼容）</span>' +
      '        <input id="ai-url" type="text" inputmode="url" placeholder="https://api.openai.com/v1" value="' + esc(cfg.url) + '">' +
      '      </label>' +
      '      <label class="field"><span>API Key</span>' +
      '        <input id="ai-key" type="text" placeholder="sk-..." value="' + esc(cfg.key) + '">' +
      '      </label>' +
      '      <label class="field"><span>模型</span>' +
      '        <input id="ai-model" type="text" placeholder="gpt-4o-mini" value="' + esc(cfg.model) + '">' +
      '      </label>' +
      '      <button class="btn" type="button" data-act="ai-config">保存配置</button>' +
      '      <p class="muted mt12">Key 只保存在本机 localStorage，直连第三方接口，可能受浏览器跨域限制。</p>' +
      '    </details>' +
      '  </div>' +
      '</section>' +

      '<section class="card">' +
      '  <div class="card-head"><h2>分析报告</h2>' +
      '    <button class="btn" type="button" data-act="reanalyze">分析</button>' +
      '  </div>' +
      report +
      '</section>' +

      '<section class="card">' +
      '  <div class="card-head"><h2>离线化改造</h2></div>' +
      '  <p class="muted" style="margin-bottom:10px">把外链资源改写为本地 vendor 路径，并生成下载脚本，改完可直接导出或打包 APK。</p>' +
      '  <div class="toolbar">' +
      '    <button class="btn primary" type="button" data-act="offline-all">一键离线化</button>' +
      '  </div>' +
      '</section>';
  }

  /* ---------- 导出 ---------- */

  function viewExport(st) {
    return '' +
      '<section class="card">' +
      '  <div class="card-head"><h2>导出离线包</h2><span class="badge">' + st.files.length + ' 个文件</span></div>' +
      '  <p class="muted" style="margin-bottom:12px">外链会被改写成相对路径，并附带 vendor 清单与下载脚本，解压即可离线运行。</p>' +
      '  <div class="toolbar wrap">' +
      '    <button class="btn primary" type="button" data-act="export-offline">离线版 ZIP</button>' +
      '    <button class="btn" type="button" data-act="export-raw">原始 ZIP</button>' +
      '    <button class="btn" type="button" data-act="export-report">逆向报告 .md</button>' +
      '  </div>' +
      '</section>' +
      '<section class="card">' +
      '  <div class="card-head"><h2>文件清单</h2></div>' +
      (st.files.length ? '<ul class="log">' + st.files.map(function (f) {
        return '<li><span class="t">' + size((f.content || '').length) + '</span><span>' + esc(f.path) + '</span></li>';
      }).join('') + '</ul>' : '<div class="empty">工作区为空</div>') +
      '</section>' +
      '<section class="card">' +
      '  <div class="card-head"><h2>保存到手机</h2></div>' +
      '  <div class="steps">' +
      '    <div class="step"><i>1</i><span>点击上方导出按钮，支持「系统分享」的设备会直接弹出保存到文件 / 微信 / 网盘。</span></div>' +
      '    <div class="step"><i>2</i><span>不支持分享的浏览器会走下载，文件进入「下载」目录。</span></div>' +
      '    <div class="step"><i>3</i><span>想装成应用，去「APK」页生成 HAirPLNmo.zip 工程包。</span></div>' +
      '  </div>' +
      '</section>';
  }

  /* ---------- APK ---------- */

  function viewApk(st) {
    var a = st.apk;
    return '' +
      '<section class="card">' +
      '  <div class="card-head"><h2>应用信息</h2><span class="badge">WebView 壳</span></div>' +
      '  <label class="field"><span>应用名称</span>' +
      '    <input id="apk-name" type="text" value="' + esc(a.appName) + '">' +
      '  </label>' +
      '  <label class="field"><span>包名（applicationId）</span>' +
      '    <input id="apk-pkg" type="text" inputmode="url" autocapitalize="off" autocorrect="off" value="' + esc(a.packageName) + '">' +
      '  </label>' +
      '  <div class="row">' +
      '    <label class="field"><span>版本名</span>' +
      '      <input id="apk-ver" type="text" value="' + esc(a.versionName) + '">' +
      '    </label>' +
      '    <label class="field"><span>版本号</span>' +
      '      <input id="apk-code" type="number" inputmode="numeric" value="' + esc(a.versionCode) + '">' +
      '    </label>' +
      '  </div>' +
      '  <div class="toolbar">' +
      '    <button class="btn primary" type="button" data-act="apk-build">生成并保存 HAirPLNmo.zip</button>' +
      '  </div>' +
      '  <p class="muted mt12">网页本体全部内置进 assets，编译后运行时完全离线。</p>' +
      '</section>' +

      '<section class="card">' +
      '  <div class="card-head"><h2>生成后的步骤</h2></div>' +
      '  <div class="steps">' +
      '    <div class="step"><i>1</i><span>点击生成，导出 <b>HAirPLNmo.zip</b>，里面是完整的 Gradle 工程。</span></div>' +
      '    <div class="step"><i>2</i><span>打开 https://github.com/ 新建仓库，解压后把工程代码上传上去。</span></div>' +
      '    <div class="step"><i>3</i><span>仓库自带的 Actions 会自动编译，在 Actions 页面下载 `app-debug.apk`。</span></div>' +
      '    <div class="step"><i>4</i><span>把 APK 传到手机，允许「安装未知来源应用」后安装，断网也能用。</span></div>' +
      '  </div>' +
      '  <p class="warn-text mt12">浏览器无法直接编译 APK（缺少 Android SDK 与签名环境），所以这里生成的是可直接编译的工程包，放 GitHub Actions 上编译最省事。</p>' +
      '</section>' +

      '<section class="card">' +
      '  <div class="card-head"><h2>安卓与桌面安装</h2></div>' +
      '  <p class="muted">如果只是想在手机上用这个工作台，可以直接用浏览器的「添加到主屏幕」，PWA 离线可用，无需 APK。</p>' +
      '  <div class="toolbar mt12">' +
      '    <button class="btn" type="button" data-act="apk-pwa">查看安装说明</button>' +
      '    <button class="btn ghost" type="button" data-act="apk-github">前往 GitHub</button>' +
      '  </div>' +
      '</section>';
  }

  /* ---------- 对外 ---------- */

  var UI = {
    mount: function (el) {
      root = el;
    },

    view: function () {
      return current;
    },

    setView: function (name) {
      current = name;
      document.querySelectorAll('.tab').forEach(function (t) {
        t.classList.toggle('active', t.getAttribute('data-view') === name);
      });
    },

    render: function (st) {
      if (!root) return;
      var scroll = root.scrollTop;
      var html;
      if (current === 'server') html = viewServer(st);
      else if (current === 'files') html = viewFiles(st);
      else if (current === 'reverse') html = viewReverse(st);
      else if (current === 'export') html = viewExport(st);
      else html = viewApk(st);
      root.innerHTML = html;
      root.scrollTop = scroll;

      var log = document.getElementById('chat-log');
      if (log) log.scrollTop = log.scrollHeight;
    },

    toast: function (msg) {
      var el = document.getElementById('toast');
      if (!el) return;
      el.textContent = msg;
      el.classList.add('show');
      clearTimeout(el._t);
      el._t = setTimeout(function () {
        el.classList.remove('show');
      }, 2000);
    },

    loading: function (on, text) {
      var el = document.getElementById('loading');
      var tx = document.getElementById('loading-text');
      if (!el) return;
      if (text && tx) tx.textContent = text;
      el.hidden = !on;
    },

    setConn: function (online, text) {
      var dot = document.getElementById('conn-dot');
      var t = document.getElementById('conn-text');
      if (dot) dot.classList.toggle('on', !!online);
      if (t) t.textContent = text;
    },

    notice: function (opts) {
      var el = document.getElementById('notice');
      var title = document.getElementById('notice-title');
      var body = document.getElementById('notice-body');
      var acts = document.getElementById('notice-acts');
      if (!el || !title || !body || !acts) return;

      title.textContent = (opts && opts.title) || '提示';
      body.innerHTML = (opts && opts.body) || '';
      acts.innerHTML = '';

      var list = (opts && opts.actions && opts.actions.length) ? opts.actions : [{ label: '知道了' }];

      list.forEach(function (a) {
        var node;
        if (a.href) {
          node = document.createElement('a');
          node.href = a.href;
          node.target = '_blank';
          node.rel = 'noopener noreferrer';
        } else {
          node = document.createElement('button');
          node.type = 'button';
        }
        node.className = 'btn' + (a.primary ? ' primary' : '');
        node.textContent = a.label || '确定';
        node.addEventListener('click', function () {
          try {
            if (a.onClick) a.onClick();
          } catch (e) {
            /* 忽略回调异常 */
          }
          if (a.close !== false) UI.closeNotice();
        });
        acts.appendChild(node);
      });

      el.hidden = false;
      document.body.classList.add('no-scroll');
    },

    closeNotice: function () {
      var el = document.getElementById('notice');
      if (el) el.hidden = true;
      var sheet = document.getElementById('sheet');
      if (!sheet || sheet.hidden) document.body.classList.remove('no-scroll');
    },

    openSheet: function (path, content) {
      sheetPath = path;
      var sheet = document.getElementById('sheet');
      var title = document.getElementById('sheet-title');
      var editor = document.getElementById('sheet-editor');
      if (!sheet || !editor) return;
      if (title) title.textContent = path;
      editor.value = content == null ? '' : content;
      sheet.hidden = false;
      document.body.classList.add('no-scroll');
    },

    closeSheet: function () {
      var sheet = document.getElementById('sheet');
      if (sheet) sheet.hidden = true;
      document.body.classList.remove('no-scroll');
    },

    sheetPath: function () {
      return sheetPath;
    }
  };

  window.UI = UI;
})();