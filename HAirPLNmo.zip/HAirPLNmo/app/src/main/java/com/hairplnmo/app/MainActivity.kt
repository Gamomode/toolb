package com.hairplnmo.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.composed
import kotlinx.coroutines.delay

val BgColor = Color(0xFFF3F5F9)
val CardColor = Color(0xFFFFFFFF)
val AccentColor = Color(0xFF1A6DFF)
val MainText = Color(0xFF1B2230)
val SubText = Color(0xFF7A8499)
val LineColor = Color(0xFFE3E8F0)

fun Modifier.tap(onClick: () -> Unit): Modifier = composed {
    clickable(interactionSource = remember { MutableInteractionSource() }, indication = null, onClick = onClick)
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            var stage by remember { mutableStateOf("select") }
            Surface(color = BgColor, modifier = Modifier.fillMaxSize()) {
                when (stage) {
                    "select" -> SelectScreen(onPremium = { stage = "premium" }, onFree = { stage = "loading" })
                    "premium" -> PremiumScreen(onBack = { stage = "select" })
                    "loading" -> LoadingScreen(onDone = { stage = "home" })
                    "home" -> HomeScreen()
                }
            }
        }
    }
}

@Composable
fun SelectScreen(onPremium: () -> Unit, onFree: () -> Unit) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0x66000000)),
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(28.dp)
                .background(CardColor, RoundedCornerShape(22.dp))
                .padding(22.dp)
        ) {
            Text("选择版本", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = MainText)
            Spacer(Modifier.height(6.dp))
            Text("请选择要进入的版本", fontSize = 13.sp, color = SubText)
            Spacer(Modifier.height(20.dp))
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFFEDF3FF), RoundedCornerShape(16.dp))
                    .tap { onPremium() }
                    .padding(18.dp)
            ) {
                Column {
                    Text("高级版-卡密", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = MainText)
                    Spacer(Modifier.height(4.dp))
                    Text("输入卡密解锁全部功能", fontSize = 12.sp, color = SubText)
                }
            }
            Spacer(Modifier.height(12.dp))
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFFEDF7F0), RoundedCornerShape(16.dp))
                    .tap { onFree() }
                    .padding(18.dp)
            ) {
                Column {
                    Text("免费版", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = MainText)
                    Spacer(Modifier.height(4.dp))
                    Text("直接进入，功能有限", fontSize = 12.sp, color = SubText)
                }
            }
        }
    }
}

@Composable
fun PremiumScreen(onBack: () -> Unit) {
    var key by remember { mutableStateOf("") }
    var msg by remember { mutableStateOf("") }
    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(28.dp)
                .background(CardColor, RoundedCornerShape(22.dp))
                .padding(22.dp)
        ) {
            TextButton(onClick = onBack, contentPadding = PaddingValues(0.dp)) {
                Text("← 返回", fontSize = 14.sp, color = SubText)
            }
            Spacer(Modifier.height(8.dp))
            Text("请输入卡密以解锁", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = MainText)
            Spacer(Modifier.height(18.dp))
            OutlinedTextField(
                value = key,
                onValueChange = {
                    key = it
                    msg = ""
                },
                modifier = Modifier.fillMaxWidth(),
                placeholder = { Text("输入卡密", fontSize = 14.sp, color = SubText) },
                singleLine = true,
                shape = RoundedCornerShape(12.dp)
            )
            Spacer(Modifier.height(16.dp))
            Button(
                onClick = { msg = "敬请期待" },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = AccentColor)
            ) {
                Text("确定", fontSize = 15.sp, fontWeight = FontWeight.Bold)
            }
            if (msg.isNotEmpty()) {
                Spacer(Modifier.height(12.dp))
                Text(msg, fontSize = 14.sp, color = AccentColor, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
            }
            Spacer(Modifier.height(10.dp))
            TextButton(
                onClick = { },
                modifier = Modifier.fillMaxWidth(),
                contentPadding = PaddingValues(6.dp)
            ) {
                Text("购买卡密", fontSize = 14.sp, color = SubText)
            }
        }
    }
}

@Composable
fun LoadingScreen(onDone: () -> Unit) {
    LaunchedEffect(Unit) {
        delay(1800)
        onDone()
    }
    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            CircularProgressIndicator(color = AccentColor)
            Spacer(Modifier.height(16.dp))
            Text("加载中…", fontSize = 14.sp, color = SubText)
        }
    }
}

@Composable
fun HomeScreen() {
    Column(modifier = Modifier.fillMaxSize()) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(CardColor)
                .padding(vertical = 18.dp, horizontal = 20.dp)
        ) {
            Text("HAirPLNmo", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = MainText)
        }
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("首页", fontSize = 16.sp, color = SubText)
        }
    }
}
