# AI 逆向工作台 · Android 工程

这是由「AI 逆向工作台」生成的 WebView 壳工程，网页本体已放在 `app/src/main/assets/`。
导出文件名：`HAirPLNmo.zip`

## 方式一：GitHub Actions 编译（推荐，不用装环境）
1. 打开 https://github.com/ 并新建一个仓库。
2. 把 `HAirPLNmo.zip` 解压后的全部文件上传到仓库根目录（包含 `.github/workflows/build-apk.yml`）。
3. 推送到 main 分支后自动触发构建，进入仓库的 Actions 页面查看进度。
4. 构建完成后在该次运行的 Artifacts 里下载 APK，解压即得到 `app-debug.apk`。

## 方式二：本地构建
1. 安装 Android Studio（含 JDK 17）。
2. 用 Android Studio 打开本目录，等待 Gradle 同步。
3. 菜单 Build → Build App Bundle(s) / APK(s) → Build APK(s)。
4. 产物在 `app/build/outputs/apk/debug/app-debug.apk`。

## 安装到手机
1. 把 APK 传到手机（数据线 / 微信文件传输 / 网盘均可）。
2. 在文件管理里点击 APK，允许「安装未知来源应用」。
3. 安装完成后桌面出现图标，断网也能正常使用。

## 包名与版本
- applicationId：`com.offline.workbench`
- 修改包名后需要同步修改 `app/src/main/java/` 下的目录结构。

## 说明
- 网页资源全部内置在 APK 里，运行时不联网。
- 数据保存在 WebView 的 localStorage 中，卸载应用即清除。
- 导出 ZIP 功能依赖 JSZip，首次使用需联网加载，其余功能完全离线。