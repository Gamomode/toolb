package com.lg.toolbox

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.ClipboardManager
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.io.File
import java.security.MessageDigest
import java.util.zip.ZipFile

data class ApkReport(
    val size: Long,
    val entryCount: Int,
    val md5: String,
    val sha256: String,
    val pkg: String?,
    val versionName: String?,
    val minSdk: String?,
    val targetSdk: String?,
    val permissions: List<String>,
    val topEntries: List<Pair<String, Long>>
)

fun humanSize(n: Long): String = when {
    n >= 1048576L -> "%.1f MB".format(n / 1048576.0)
    n >= 1024L -> "%.1f KB".format(n / 1024.0)
    else -> n.toString() + " B"
}

fun sdkName(v: String?): String {
    val n = v?.toIntOrNull() ?: return v ?: "—"
    val names = mapOf(
        21 to "5.0", 22 to "5.1", 23 to "6.0", 24 to "7.0", 25 to "7.1",
        26 to "8.0", 27 to "8.1", 28 to "9", 29 to "10", 30 to "11",
        31 to "12", 32 to "12L", 33 to "13", 34 to "14", 35 to "15"
    )
    return "Android " + (names[n] ?: "?") + "（API " + n + "）"
}

fun analyzeApkFile(f: File): ApkReport {
    val bytes = f.readBytes()
    val md5 = MessageDigest.getInstance("MD5").digest(bytes).joinToString("") { "%02x".format(it) }
    val sha = MessageDigest.getInstance("SHA-256").digest(bytes).joinToString("") { "%02x".format(it) }
    var count = 0
    val entries = mutableListOf<Pair<String, Long>>()
    var manifestBytes: ByteArray? = null
    ZipFile(f).use { zf ->
        val en = zf.entries()
        while (en.hasMoreElements()) {
            val e = en.nextElement()
            count++
            entries.add(e.name to e.size)
            if (e.name == "AndroidManifest.xml") manifestBytes = zf.getInputStream(e).readBytes()
        }
    }
    entries.sortByDescending { it.second }
    val info = manifestBytes?.let { ApkManifest.parse(it) }
    return ApkReport(
        bytes.size.toLong(), count, md5, sha,
        info?.pkg, info?.versionName, info?.minSdk, info?.targetSdk,
        info?.permissions ?: emptyList(),
        entries.take(8)
    )
}

object ApkManifest {
    data class Info(
        val pkg: String?,
        val versionName: String?,
        val minSdk: String?,
        val targetSdk: String?,
        val permissions: List<String>
    )

    fun parse(data: ByteArray): Info? = try {
        var strings: List<String>? = null
        var pkg: String? = null
        var verName: String? = null
        var minSdk: String? = null
        var targetSdk: String? = null
        val perms = mutableListOf<String>()
        var pos = 0
        while (pos + 8 <= data.size) {
            val type = u16(data, pos).toInt()
            if (type == 0x0003) {
                pos += 8
                continue
            }
            val size = u32(data, pos + 4).toInt()
            if (size <= 0 || pos + size > data.size) break
            if (type == 0x0001) {
                strings = parseStringPool(data, pos)
            } else if (type == 0x0102 && strings != null) {
                val nameIdx = u32(data, pos + 20).toInt()
                val elemName = strings.getOrNull(nameIdx)
                val attrStart = u16(data, pos + 24).toInt()
                val attrCount = u16(data, pos + 28).toInt()
                var ap = pos + 16 + attrStart
                val attrs = HashMap<String, String>()
                for (i in 0 until attrCount) {
                    val aNameIdx = u32(data, ap + 4).toInt()
                    val rawIdx = u32(data, ap + 8).toInt()
                    val dataType = data[ap + 15].toInt() and 0xFF
                    val dataVal = u32(data, ap + 16)
                    val aname = strings.getOrNull(aNameIdx)
                    val value: String? = when (dataType) {
                        0x03 -> strings.getOrNull(dataVal.toInt())
                        0x10 -> dataVal.toInt().toString()
                        0x12 -> "0x" + java.lang.Long.toHexString(dataVal)
                        else -> strings.getOrNull(rawIdx)
                    }
                    if (aname != null && value != null) attrs[aname] = value
                    ap += 20
                }
                when (elemName) {
                    "manifest" -> {
                        pkg = attrs["package"]
                        verName = attrs["versionName"]
                    }
                    "uses-sdk" -> {
                        minSdk = attrs["minSdkVersion"]
                        targetSdk = attrs["targetSdkVersion"]
                    }
                    "uses-permission" -> attrs["name"]?.let { perms.add(it) }
                }
            }
            pos += size
        }
        Info(pkg, verName, minSdk, targetSdk, perms)
    } catch (e: Exception) {
        null
    }

    private fun parseStringPool(data: ByteArray, chunkStart: Int): List<String> {
        val stringCount = u32(data, chunkStart + 8).toInt()
        val flags = u32(data, chunkStart + 16)
        val stringsStart = u32(data, chunkStart + 20).toInt()
        val utf8 = (flags and 0x100L) != 0L
        val out = ArrayList<String>(stringCount)
        for (i in 0 until stringCount) {
            val off = u32(data, chunkStart + 28 + i * 4).toInt()
            var p = chunkStart + stringsStart + off
            if (p >= data.size) {
                out.add("")
                continue
            }
            if (utf8) {
                var r = readLen8(data, p)
                p += r.second
                r = readLen8(data, p)
                p += r.second
                val len = r.first
                out.add(if (len <= 0 || p + len > data.size) "" else String(data, p, len, Charsets.UTF_8))
            } else {
                val r = readLen16(data, p)
                p += r.second
                val len = r.first
                val sb = StringBuilder()
                for (j in 0 until len) {
                    if (p + j * 2 + 1 >= data.size) break
                    sb.append(u16(data, p + j * 2).toInt().toChar())
                }
                out.add(sb.toString())
            }
        }
        return out
    }

    private fun readLen8(d: ByteArray, p: Int): Pair<Int, Int> {
        if (p >= d.size) return 0 to 1
        val b = d[p].toInt() and 0xFF
        return if (b and 0x80 != 0) {
            if (p + 1 >= d.size) 0 to 2
            else (((b and 0x7F) shl 8) or (d[p + 1].toInt() and 0xFF)) to 2
        } else b to 1
    }

    private fun readLen16(d: ByteArray, p: Int): Pair<Int, Int> {
        if (p + 1 >= d.size) return 0 to 2
        val v = u16(d, p).toInt()
        return if (v and 0x8000 != 0) {
            if (p + 3 >= d.size) 0 to 4
            else (((v and 0x7FFF) shl 16) or u16(d, p + 2).toInt()) to 4
        } else v to 2
    }

    private fun u16(d: ByteArray, p: Int): Long =
        ((d[p].toInt() and 0xFF) or ((d[p + 1].toInt() and 0xFF) shl 8)).toLong()

    private fun u32(d: ByteArray, p: Int): Long = u16(d, p) or (u16(d, p + 2) shl 16)
}

@Composable
fun AnalyzerScreen(th: ThemeSpec, notify: (String) -> Unit) {
    var report by remember { mutableStateOf<ApkReport?>(null) }
    var busy by remember { mutableStateOf(false) }
    val clipboard = LocalClipboardManager.current
    val ctx = LocalContext.current

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            busy = true
            try {
                val tmp = File(ctx.cacheDir, "analyze_tmp.apk")
                ctx.contentResolver.openInputStream(uri)?.use { ins ->
                    tmp.outputStream().use { ins.copyTo(it) }
                }
                report = analyzeApkFile(tmp)
                Usage.mark("analyzer")
                tmp.delete()
            } catch (e: Exception) {
                notify("读取失败：${e.message}")
            }
            busy = false
        }
    }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        Box(
            Modifier
                .fillMaxWidth()
                .background(th.accentSoft, RoundedCornerShape(20.dp))
                .padding(14.dp)
        ) {
            Text(
                "🔍 APK 分析器：选择安装包，当场拆开看。全程本地分析，文件不会离开这台设备。",
                fontSize = 13.sp,
                color = th.ink,
                lineHeight = 21.sp
            )
        }
        Spacer(Modifier.height(14.dp))
        Box(
            Modifier
                .fillMaxWidth()
                .background(th.panel, RoundedCornerShape(20.dp))
                .border(1.dp, th.line, RoundedCornerShape(20.dp))
                .tap { picker.launch("*/*") }
                .padding(vertical = 34.dp),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    if (busy) "解析中…" else "点击选择 .apk 安装包",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = th.ink
                )
                Spacer(Modifier.height(4.dp))
                Text("不会上传，只在本机内存中解析", fontSize = 12.sp, color = th.muted)
            }
        }
        report?.let { r ->
            Spacer(Modifier.height(14.dp))
            Box(
                Modifier
                    .fillMaxWidth()
                    .background(th.panel, RoundedCornerShape(20.dp))
                    .border(1.dp, th.line, RoundedCornerShape(20.dp))
                    .padding(14.dp)
            ) {
                Column {
                    Text("概览", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = th.ink)
                    Spacer(Modifier.height(8.dp))
                    Text(r.pkg ?: "未知包名", fontSize = 14.sp, fontWeight = FontWeight.Medium, color = th.accent)
                    if (r.versionName != null) {
                        Text("版本 " + r.versionName, fontSize = 12.sp, color = th.muted)
                    }
                    Spacer(Modifier.height(10.dp))
                    KvRow("文件大小", humanSize(r.size), th)
                    KvRow("内部文件数", r.entryCount.toString() + " 个", th)
                    KvRow("最低支持系统", sdkName(r.minSdk), th)
                    KvRow("适配目标系统", sdkName(r.targetSdk), th)
                    Spacer(Modifier.height(10.dp))
                    HashRow("MD5", r.md5, th, clipboard, notify)
                    HashRow("SHA-256", r.sha256, th, clipboard, notify)
                }
            }
            if (r.permissions.isNotEmpty()) {
                Spacer(Modifier.height(14.dp))
                Box(
                    Modifier
                        .fillMaxWidth()
                        .background(th.panel, RoundedCornerShape(20.dp))
                        .border(1.dp, th.line, RoundedCornerShape(20.dp))
                        .padding(14.dp)
                ) {
                    Column {
                        Text("权限（" + r.permissions.size + "）", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = th.ink)
                        Spacer(Modifier.height(6.dp))
                        r.permissions.forEach { p ->
                            Text("· " + p, fontSize = 12.sp, color = th.muted, lineHeight = 19.sp)
                        }
                    }
                }
            }
            if (r.topEntries.isNotEmpty()) {
                Spacer(Modifier.height(14.dp))
                Box(
                    Modifier
                        .fillMaxWidth()
                        .background(th.panel, RoundedCornerShape(20.dp))
                        .border(1.dp, th.line, RoundedCornerShape(20.dp))
                        .padding(14.dp)
                ) {
                    Column {
                        Text("包内最大的文件", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = th.ink)
                        Spacer(Modifier.height(6.dp))
                        r.topEntries.forEach { e ->
                            Row(Modifier.padding(vertical = 2.dp)) {
                                Text(
                                    "· " + e.first,
                                    fontSize = 12.sp,
                                    color = th.muted,
                                    modifier = Modifier.weight(1f)
                                )
                                Text(humanSize(e.second), fontSize = 12.sp, color = th.muted)
                            }
                        }
                    }
                }
            }
        }
        Spacer(Modifier.height(30.dp))
    }
}

@Composable
fun KvRow(k: String, v: String, th: ThemeSpec) {
    Row(Modifier.fillMaxWidth().padding(vertical = 3.dp)) {
        Text(k, fontSize = 12.sp, color = th.muted, modifier = Modifier.width(110.dp))
        Text(v, fontSize = 12.sp, color = th.ink)
    }
}

@Composable
fun HashRow(label: String, value: String, th: ThemeSpec, clipboard: ClipboardManager, notify: (String) -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(vertical = 3.dp)
            .tap {
                clipboard.setText(AnnotatedString(value))
                notify("已复制$label")
            }
    ) {
        Text(label, fontSize = 12.sp, color = th.muted, modifier = Modifier.width(70.dp))
        Text(value, fontSize = 11.sp, color = th.accent)
    }
}
