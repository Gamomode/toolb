package com.lg.toolbox

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

data class ThemeSpec(
    val name: String,
    val bg: Color,
    val panel: Color,
    val ink: Color,
    val muted: Color,
    val accent: Color,
    val accentSoft: Color,
    val line: Color
)

val THEMES = listOf(
    ThemeSpec("teal", Color(0xFFEAF7F4), Color(0xFFFFFFFF), Color(0xFF12312B), Color(0xFF5C7A73), Color(0xFF0E9F8A), Color(0xFFD7F2EC), Color(0xFFD8E8E4)),
    ThemeSpec("sky", Color(0xFFEAF3FB), Color(0xFFFFFFFF), Color(0xFF12283A), Color(0xFF5A7186), Color(0xFF2B7FD4), Color(0xFFD9EAF8), Color(0xFFD6E4F0)),
    ThemeSpec("violet", Color(0xFFF3EFFB), Color(0xFFFFFFFF), Color(0xFF241A3E), Color(0xFF6B5F8A), Color(0xFF6D4FD0), Color(0xFFE6DFF9), Color(0xFFE0DAF0)),
    ThemeSpec("rose", Color(0xFFFBEEF1), Color(0xFFFFFFFF), Color(0xFF3A1220), Color(0xFF8A5A6B), Color(0xFFD4436E), Color(0xFFF9DCE4), Color(0xFFF0DAE0)),
    ThemeSpec("amber", Color(0xFFFBF3E4), Color(0xFFFFFFFF), Color(0xFF3A2A10), Color(0xFF8A7350), Color(0xFFD08A1F), Color(0xFFF8EAD0), Color(0xFFF0E4CC)),
    ThemeSpec("night", Color(0xFF0F172A), Color(0xFF1B2740), Color(0xFFE2E8F0), Color(0xFF94A3B8), Color(0xFF38BDF8), Color(0xFF23324D), Color(0xFF2C3B5C))
)

data class TabInfo(
    val key: String,
    val title: String,
    val sub: String,
    val need: Level,
    val tag: String?,
    val tagColor: Long
)

val TABS = listOf(
    TabInfo("tutorial", "新手教程", "查看工具箱使用说明", Level.NONE, null, 0),
    TabInfo("convert", "格式转换", "Hex 转 Base64", Level.NORMAL, "普通版", 0xFF2FA46A),
    TabInfo("salt", "加盐慢哈希", "10 万次迭代，抗破解", Level.MID, "中级版", 0xFF2B7FD4),
    TabInfo("hash", "基础哈希计算", "SHA-1 / 256 / 384 / 512", Level.VIP, "高级版", 0xFF6D4FD0),
    TabInfo("garbled", "HTML 转乱码", "实体编码 / 不可逆混淆", Level.PAID, "付费版", 0xFFD08A1F),
    TabInfo("encrypt", "加密网页", "带密码锁的网页", Level.SVIP, "SVIP", 0xFFD4436E),
    TabInfo("fastpack", "高级打包-极速版", "一键极速打包，最少选项", Level.SVIP, "SVIP", 0xFFD4436E),
    TabInfo("analyzer", "APK 分析器", "拆包看清单、权限、签名", Level.SVIP, "SVIP", 0xFFD4436E),
    TabInfo("workshop", "深度重置 APK 工程", "生成极高APK,加密等,打包等", Level.SPECIAL, "特殊", 0xFFB8860B)
)

fun tabInfo(key: String): TabInfo = TABS.first { it.key == key }

fun tabIcon(key: String) = when (key) {
    "tutorial" -> "📖"
    "convert" -> "🔄"
    "salt" -> "🧂"
    "hash" -> "🔢"
    "garbled" -> "🌀"
    "encrypt" -> "🔒"
    "fastpack" -> "⚡"
    "analyzer" -> "🔍"
    "workshop" -> "🏭"
    else -> "📖"
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val store = Store(this)
        setContent {
            ToolboxApp(store)
        }
    }
}

@Composable
fun ToolboxApp(store: Store) {
    var themeIdx by remember { mutableStateOf(store.themeIndex()) }
    val th = THEMES[themeIdx.coerceIn(0, THEMES.size - 1)]
    var screen by remember { mutableStateOf("tutorial") }
    var userTick by remember { mutableStateOf(0) }
    var clockTick by remember { mutableStateOf(0) }
    var toast by remember { mutableStateOf<String?>(null) }
    var showAuth by remember { mutableStateOf(false) }
    var showShop by remember { mutableStateOf(false) }
    var showTasks by remember { mutableStateOf(false) }
    var showPremium by remember { mutableStateOf(false) }
    var showUserMenu by remember { mutableStateOf(false) }
    var showDelConfirm by remember { mutableStateOf(false) }
    var drawerOpen by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        while (true) {
            kotlinx.coroutines.delay(1000)
            clockTick++
        }
    }
    LaunchedEffect(toast) {
        if (toast != null) {
            kotlinx.coroutines.delay(2200)
            toast = null
        }
    }

    fun notify(msg: String) { toast = msg }

    fun openTab(key: String) {
        val info = tabInfo(key)
        val eff = store.effectiveLevel()
        if (info.need != Level.NONE && eff.weight < info.need.weight) {
            notify("当前身份为「${eff.label}」，请先登录或购买对应权限")
            return
        }
        screen = key
        drawerOpen = false
    }

    val info = tabInfo(screen)

    Box(
        Modifier
            .fillMaxSize()
            .background(th.bg)
    ) {
        Column(Modifier.fillMaxSize()) {
            Surface(color = th.panel, shadowElevation = 2.dp) {
                Row(
                    Modifier
                        .fillMaxWidth()
                        .statusBarsPadding()
                        .padding(horizontal = 14.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        "☰",
                        fontSize = 22.sp,
                        color = th.ink,
                        modifier = Modifier
                            .clickable { drawerOpen = true }
                            .padding(end = 12.dp)
                    )
                    Column(Modifier.weight(1f)) {
                        Text(info.title, fontSize = 18.sp, fontWeight = FontWeight.Bold, color = th.ink)
                        Text(info.sub, fontSize = 11.sp, color = th.muted)
                    }
                    Text(
                        "$" + "%.2f".format(store.balance()),
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = th.accent,
                        modifier = Modifier
                            .background(th.accentSoft, RoundedCornerShape(999.dp))
                            .clickable { showTasks = true }
                            .padding(horizontal = 10.dp, vertical = 5.dp)
                    )
                }
            }

            Box(Modifier.weight(1f)) {
                when (screen) {
                    "hash" -> ToolScreen(th, store, ToolKind.HASH) { notify(it) }
                    "salt" -> ToolScreen(th, store, ToolKind.SALT) { notify(it) }
                    "convert" -> ToolScreen(th, store, ToolKind.CONVERT) { notify(it) }
                    "encrypt" -> ToolScreen(th, store, ToolKind.ENCRYPT) { notify(it) }
                    "garbled" -> ToolScreen(th, store, ToolKind.GARBLED) { notify(it) }
                    "analyzer" -> AnalyzerScreen(th) { notify(it) }
                    "fastpack" -> FastpackScreen(th) { notify(it) }
                    "workshop" -> WorkshopScreen(th) { notify(it) }
                    else -> TutorialScreen(th)
                }
            }
        }

        if (drawerOpen) {
            Box(
                Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.4f))
                    .clickable { drawerOpen = false }
            )
            Surface(
                color = th.panel,
                modifier = Modifier
                    .fillMaxHeight()
                    .fillMaxWidth(0.86f)
            ) {
                Column(
                    Modifier
                        .fillMaxSize()
                        .verticalScroll(rememberScrollState())
                        .padding(16.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("🧰", fontSize = 22.sp)
                        Spacer(Modifier.width(8.dp))
                        Column(Modifier.weight(1f)) {
                            Text("工具箱", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = th.ink)
                            Text("v2.1 · 原生版", fontSize = 11.sp, color = th.muted)
                        }
                        Text(
                            "×",
                            fontSize = 22.sp,
                            color = th.muted,
                            modifier = Modifier
                                .clickable { drawerOpen = false }
                                .padding(6.dp)
                        )
                    }
                    Spacer(Modifier.height(14.dp))
                    DrawerRow("⭐", "高级版", "工具箱 · 新手教程", "下载", 0xFFFBBF24, th) {
                        showPremium = true
                        drawerOpen = false
                    }
                    TABS.forEach { t ->
                        DrawerRow(tabIcon(t.key), t.title, t.sub, t.tag, t.tagColor, th) { openTab(t.key) }
                    }
                    if (store.currentUser != null) {
                        Spacer(Modifier.height(14.dp))
                        Text("我的订单（实时倒计时）", fontSize = 12.sp, color = th.muted)
                        Spacer(Modifier.height(6.dp))
                        clockTick
                        Text(
                            store.ordersText(),
                            fontSize = 12.sp,
                            color = th.ink,
                            lineHeight = 19.sp
                        )
                    }
                    Spacer(Modifier.height(14.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            Modifier
                                .size(34.dp)
                                .background(th.accentSoft, CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                if (store.currentUser == null) "?" else store.currentUser!!.substring(0, 1),
                                fontSize = 15.sp,
                                color = th.accent,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Spacer(Modifier.width(10.dp))
                        Text(
                            store.maskedUser(),
                            fontSize = 14.sp,
                            color = th.ink,
                            modifier = Modifier
                                .weight(1f)
                                .clickable {
                                    if (store.currentUser == null) showAuth = true else showUserMenu = true
                                }
                        )
                        if (store.currentUser != null) {
                            Text(
                                "升级",
                                fontSize = 12.sp,
                                color = Color.White,
                                modifier = Modifier
                                    .background(th.accent, RoundedCornerShape(999.dp))
                                    .clickable {
                                        showShop = true
                                        drawerOpen = false
                                    }
                                    .padding(horizontal = 12.dp, vertical = 5.dp)
                            )
                            Spacer(Modifier.width(8.dp))
                            Text(
                                "⋯",
                                fontSize = 18.sp,
                                color = th.ink,
                                modifier = Modifier
                                    .clickable { showUserMenu = true }
                                    .padding(4.dp)
                            )
                        }
                    }
                    Spacer(Modifier.height(18.dp))
                    Text("背景颜色", fontSize = 12.sp, color = th.muted)
                    Spacer(Modifier.height(8.dp))
                    Row {
                        THEMES.forEachIndexed { i, t ->
                            Box(
                                Modifier
                                    .padding(end = 10.dp)
                                    .size(30.dp)
                                    .background(
                                        Brush.linearGradient(listOf(t.accent, t.accent.copy(alpha = 0.6f))),
                                        CircleShape
                                    )
                                    .border(
                                        width = if (i == themeIdx) 3.dp else 1.dp,
                                        color = if (i == themeIdx) th.ink else th.line,
                                        shape = CircleShape
                                    )
                                    .clickable {
                                        themeIdx = i
                                        store.setThemeIndex(i)
                                    }
                            )
                        }
                    }
                    Spacer(Modifier.height(20.dp))
                }
            }
        }

        if (showAuth) {
            AuthDialog(th, store, onClose = { showAuth = false }, onDone = {
                showAuth = false
                userTick++
                notify(it)
            })
        }
        if (showShop) {
            ShopDialog(th, store, onClose = { showShop = false }, notify = { notify(it); userTick++ })
        }
        if (showTasks) {
            TasksDialog(th, store, onClose = { showTasks = false }, notify = { notify(it); userTick++ })
        }
        if (showPremium) {
            PremiumDialog(th, store, onClose = { showPremium = false }, notify = { notify(it) })
        }
        if (showUserMenu) {
            AlertDialog(
                onDismissRequest = { showUserMenu = false },
                containerColor = th.panel,
                title = { Text("账号", color = th.ink, fontWeight = FontWeight.Bold) },
                text = { Text(store.maskedUser(), color = th.muted) },
                confirmButton = {
                    TextButton(onClick = {
                        showUserMenu = false
                        store.logout()
                        userTick++
                        notify("已退出登录")
                    }) { Text("退出登录", color = Color(0xFFE5484D)) }
                },
                dismissButton = {
                    TextButton(onClick = { showUserMenu = false; showDelConfirm = true }) { Text("注销账号", color = th.muted) }
                }
            )
        }
        if (showDelConfirm) {
            AlertDialog(
                onDismissRequest = { showDelConfirm = false },
                containerColor = th.panel,
                title = { Text("注销账号", color = th.ink, fontWeight = FontWeight.Bold) },
                text = { Text("将删除该账号的全部数据（订单、余额、任务记录），且无法恢复。确定注销吗？", color = th.muted) },
                confirmButton = {
                    TextButton(onClick = {
                        showDelConfirm = false
                        store.deleteAccount()
                        userTick++
                        notify("账号已注销")
                    }) { Text("确定注销", color = Color(0xFFE5484D)) }
                },
                dismissButton = {
                    TextButton(onClick = { showDelConfirm = false }) { Text("取消", color = th.muted) }
                }
            )
        }

        toast?.let { msg ->
            Box(
                Modifier
                    .align(Alignment.BottomCenter)
                    .padding(bottom = 40.dp)
                    .background(Color(0xFF141923).copy(alpha = 0.92f), RoundedCornerShape(999.dp))
                    .padding(horizontal = 20.dp, vertical = 10.dp)
            ) {
                Text(msg, color = Color.White, fontSize = 14.sp)
            }
        }
    }
}

@Composable
fun DrawerRow(icon: String, title: String, sub: String, tag: String?, tagColor: Long, th: ThemeSpec, strike: Boolean = false, onClick: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .padding(vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(icon, fontSize = 18.sp)
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text(
                title,
                fontSize = 15.sp,
                fontWeight = FontWeight.Medium,
                color = th.ink,
                textDecoration = if (strike) TextDecoration.LineThrough else null
            )
            Text(
                sub,
                fontSize = 11.sp,
                color = th.muted,
                textDecoration = if (strike) TextDecoration.LineThrough else null
            )
        }
        if (tag != null) {
            Text(
                tag,
                fontSize = 10.sp,
                color = Color.White,
                modifier = Modifier
                    .background(Color(tagColor), RoundedCornerShape(999.dp))
                    .padding(horizontal = 8.dp, vertical = 3.dp)
            )
        }
    }
}

@Composable
fun AuthDialog(th: ThemeSpec, store: Store, onClose: () -> Unit, onDone: (String) -> Unit) {
    var isLogin by remember { mutableStateOf(true) }
    var phone by remember { mutableStateOf("") }
    var pwd by remember { mutableStateOf("") }
    var err by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onClose,
        containerColor = th.panel,
        title = { Text(if (isLogin) "登录" else "注册账号", color = th.ink, fontWeight = FontWeight.Bold) },
        text = {
            Column {
                OutlinedTextField(
                    value = phone,
                    onValueChange = { phone = it },
                    label = { Text("手机号") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(10.dp))
                OutlinedTextField(
                    value = pwd,
                    onValueChange = { pwd = it },
                    label = { Text("密码（至少 6 位）") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(8.dp))
                err?.let {
                    Text(it, color = Color(0xFFE5484D), fontSize = 13.sp)
                    Spacer(Modifier.height(4.dp))
                }
                Text(
                    if (isLogin) "还没有账号？去注册" else "已有账号？去登录",
                    fontSize = 13.sp,
                    color = th.accent,
                    modifier = Modifier
                        .clickable { isLogin = !isLogin; err = null }
                        .padding(vertical = 6.dp)
                )
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val e = if (isLogin) store.login(phone.trim(), pwd.trim()) else store.register(phone.trim(), pwd.trim())
                if (e != null) err = e
                else onDone(if (isLogin) "登录成功" else "注册成功，已自动登录")
            }) { Text(if (isLogin) "登 录" else "注 册", color = th.accent, fontWeight = FontWeight.Bold) }
        },
        dismissButton = {
            TextButton(onClick = onClose) { Text("取消", color = th.muted) }
        }
    )
}

@Composable
fun TutorialScreen(th: ThemeSpec) {
    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        Box(
            Modifier
                .fillMaxWidth()
                .background(th.accentSoft, RoundedCornerShape(16.dp))
                .padding(14.dp)
        ) {
            Text(
                "🏠 欢迎使用本地工具箱！\n所有功能均在您的设备本地运行，不上传任何数据，极致保护隐私。",
                fontSize = 13.sp,
                color = th.ink,
                lineHeight = 21.sp
            )
        }
        Spacer(Modifier.height(14.dp))
        TutorialPanel("💰 赚取积分与开通权限", "点击右上角的金额按钮即可打开「任务中心」。完成每日签到、体验功能等任务可免费领取余额。\n攒够余额后，在侧边栏底部点击「升级」按钮进入购买中心，购买对应权限即可解锁高级工具。", th)
        TutorialPanel("🔧 主要功能说明", "· 基础哈希 / 格式转换：日常开发中常用的数据摘要与编码转换工具。\n· 加密网页：给网页或文本加一层密码锁，只有输入正确密码才能查看。\n· 高级打包-极速版：贴上网页一键出包，最快最简。\n· 深度重置 APK 工程：可加锁、转乱码、改包名、选图标、加权限的完整打包。\n· APK 分析器：把安装包选进来，直接查看清单、权限和包内文件。", th)
        TutorialPanel("关于", "该应用不适合用于做别的或做敏感信息，请勿转发，盗版必究。\n生效时间：2026年11月21日 · 结束时间：长期有效", th)
        Spacer(Modifier.height(30.dp))
    }
}

@Composable
fun TutorialPanel(title: String, body: String, th: ThemeSpec) {
    Box(
        Modifier
            .fillMaxWidth()
            .padding(bottom = 14.dp)
            .background(th.panel, RoundedCornerShape(16.dp))
            .border(1.dp, th.line, RoundedCornerShape(16.dp))
            .padding(16.dp)
    ) {
        Column {
            Text(title, fontSize = 16.sp, fontWeight = FontWeight.Bold, color = th.accent)
            Spacer(Modifier.height(6.dp))
            Text(body, fontSize = 13.sp, color = th.muted, lineHeight = 21.sp)
        }
    }
}
