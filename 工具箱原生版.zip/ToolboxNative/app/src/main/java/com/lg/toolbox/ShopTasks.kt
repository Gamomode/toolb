package com.lg.toolbox

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties

@Composable
fun ShopDialog(th: ThemeSpec, store: Store, onClose: () -> Unit, notify: (String) -> Unit) {
    var tab by remember { mutableStateOf(Level.NORMAL) }
    var confirm by remember { mutableStateOf<Plan?>(null) }

    Dialog(
        onDismissRequest = onClose,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            color = th.panel,
            shape = RoundedCornerShape(20.dp),
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight(0.88f)
                .padding(16.dp)
        ) {
            Column(Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("购买中心", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = th.ink)
                    Spacer(Modifier.weight(1f))
                    Text("余额 $" + "%.2f".format(store.balance()), fontSize = 13.sp, color = th.accent)
                    Spacer(Modifier.width(10.dp))
                    Text("✕", fontSize = 18.sp, color = th.muted, modifier = Modifier.clickable { onClose() })
                }
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.horizontalScroll(rememberScrollState())) {
                    listOf(Level.NORMAL, Level.MID, Level.VIP, Level.PAID, Level.SVIP, Level.SPECIAL, Level.ALL).forEach { lv ->
                        val sel = lv == tab
                        Box(
                            Modifier
                                .background(if (sel) th.accent else th.accentSoft, RoundedCornerShape(999.dp))
                                .clickable { tab = lv }
                                .padding(horizontal = 12.dp, vertical = 7.dp)
                        ) {
                            Text(lv.label, fontSize = 12.sp, color = if (sel) Color.White else th.accent)
                        }
                    }
                }
                Spacer(Modifier.height(12.dp))
                Column(Modifier.verticalScroll(rememberScrollState())) {
                    Plans.byLevel[tab]?.forEach { plan ->
                        Box(
                            Modifier
                                .fillMaxWidth()
                                .padding(bottom = 12.dp)
                                .background(th.bg, RoundedCornerShape(16.dp))
                                .border(1.dp, th.line, RoundedCornerShape(16.dp))
                                .padding(14.dp)
                        ) {
                            Column {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text("${plan.days} 天", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = th.ink)
                                    Spacer(Modifier.width(8.dp))
                                    Box(
                                        Modifier
                                            .background(Brush.horizontalGradient(listOf(Color(0xFFFBBF24), Color(0xFFD97706))), RoundedCornerShape(999.dp))
                                            .padding(horizontal = 8.dp, vertical = 2.dp)
                                    ) {
                                        Text(plan.tag, fontSize = 10.sp, color = Color(0xFF3A2A10))
                                    }
                                }
                                Spacer(Modifier.height(6.dp))
                                Row(verticalAlignment = Alignment.Bottom) {
                                    plan.originalPrice?.let {
                                        Text(
                                            "$$it",
                                            fontSize = 12.sp,
                                            color = th.muted,
                                            modifier = Modifier.padding(end = 8.dp)
                                        )
                                    }
                                    Text("$${plan.price}", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = th.accent)
                                }
                                Spacer(Modifier.height(6.dp))
                                Text(plan.feats.joinToString("\n") { "· $it" }, fontSize = 12.sp, color = th.muted, lineHeight = 19.sp)
                                Spacer(Modifier.height(10.dp))
                                Button(
                                    onClick = { confirm = plan },
                                    colors = ButtonDefaults.buttonColors(containerColor = th.accent),
                                    shape = RoundedCornerShape(10.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) { Text("立即购买", fontWeight = FontWeight.Bold) }
                            }
                        }
                    }
                    Spacer(Modifier.height(20.dp))
                }
            }
        }
    }

    confirm?.let { plan ->
        AlertDialog(
            onDismissRequest = { confirm = null },
            containerColor = th.panel,
            title = { Text("确认购买", color = th.ink, fontWeight = FontWeight.Bold) },
            text = {
                Column {
                    Text("${plan.level.label} · ${plan.days} 天", fontSize = 15.sp, color = th.ink)
                    Spacer(Modifier.height(4.dp))
                    Text("当前余额：$" + "%.2f".format(store.balance()), fontSize = 13.sp, color = th.muted)
                    Text("本次支付：$${plan.price}", fontSize = 13.sp, color = th.muted)
                    Text("支付后余额：$" + "%.2f".format(store.balance() - plan.price), fontSize = 13.sp, color = th.muted)
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    val e = store.buy(plan)
                    confirm = null
                    if (e != null) notify(e)
                    else notify("支付成功！${plan.level.label} ${plan.days} 天")
                    onClose()
                }) { Text("确认支付", color = th.accent, fontWeight = FontWeight.Bold) }
            },
            dismissButton = {
                TextButton(onClick = { confirm = null }) { Text("取消", color = th.muted) }
            }
        )
    }
}

@Composable
fun TasksDialog(th: ThemeSpec, store: Store, onClose: () -> Unit, notify: (String) -> Unit) {
    if (store.currentUser == null) {
        AlertDialog(
            onDismissRequest = onClose,
            containerColor = th.panel,
            title = { Text("请先登录", color = th.ink, fontWeight = FontWeight.Bold) },
            text = { Text("登录后即可领取任务奖励。", color = th.muted) },
            confirmButton = { TextButton(onClick = onClose) { Text("知道了", color = th.accent) } }
        )
        return
    }
    var tick by remember { mutableStateOf(0) }
    Dialog(
        onDismissRequest = onClose,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            color = th.panel,
            shape = RoundedCornerShape(20.dp),
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight(0.88f)
                .padding(16.dp)
        ) {
            Column(Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("任务中心", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = th.ink)
                    Spacer(Modifier.weight(1f))
                    Text("✕", fontSize = 18.sp, color = th.muted, modifier = Modifier.clickable { onClose() })
                }
                Spacer(Modifier.height(12.dp))
                Column(Modifier.verticalScroll(rememberScrollState())) {
                    Text("每日任务", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = th.ink)
                    Spacer(Modifier.height(8.dp))
                    val dailyClaimed = store.claimed(true)
                    Tasks.all.filter { it.daily }.forEach { t ->
                        TaskRow(th, t, dailyClaimed.contains(t.id)) {
                            val e = store.claim(t)
                            if (e != null) notify(e) else {
                                notify("领取成功！余额 +$${t.reward}")
                                tick++
                            }
                        }
                    }
                    Spacer(Modifier.height(14.dp))
                    Text("一次性任务", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = th.ink)
                    Spacer(Modifier.height(8.dp))
                    val onceClaimed = store.claimed(false)
                    Tasks.all.filter { !it.daily }.forEach { t ->
                        TaskRow(th, t, onceClaimed.contains(t.id)) {
                            val e = store.claim(t)
                            if (e != null) notify(e) else {
                                notify("领取成功！余额 +$${t.reward}")
                                tick++
                            }
                        }
                    }
                    Spacer(Modifier.height(20.dp))
                }
            }
        }
    }
}

@Composable
fun TaskRow(th: ThemeSpec, task: Task, done: Boolean, onClaim: () -> Unit) {
    Box(
        Modifier
            .fillMaxWidth()
            .padding(bottom = 8.dp)
            .background(th.bg, RoundedCornerShape(14.dp))
            .padding(12.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Row {
                    Text(task.title, fontSize = 14.sp, fontWeight = FontWeight.Medium, color = th.ink)
                    Spacer(Modifier.width(8.dp))
                    Text("+$${task.reward}", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color(0xFF2FBFA4))
                }
                Text(task.desc, fontSize = 11.sp, color = th.muted)
            }
            Spacer(Modifier.width(8.dp))
            if (done) {
                Text("已领取", fontSize = 12.sp, color = th.muted)
            } else {
                Button(
                    onClick = onClaim,
                    colors = ButtonDefaults.buttonColors(containerColor = th.accent),
                    shape = RoundedCornerShape(10.dp),
                    contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp)
                ) { Text("领取", fontSize = 12.sp, color = Color.White) }
            }
        }
    }
}

@Composable
fun PremiumDialog(th: ThemeSpec, store: Store, onClose: () -> Unit, notify: (String) -> Unit) {
    Dialog(onDismissRequest = onClose) {
        Surface(
            shape = RoundedCornerShape(22.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                Modifier
                    .background(Brush.verticalGradient(listOf(Color(0xFF2A2110), Color(0xFF1A1508))))
                    .padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text("👑", fontSize = 40.sp)
                Spacer(Modifier.height(8.dp))
                Text(
                    "高级版",
                    fontSize = 24.sp,
                    fontWeight = FontWeight.Bold,
                    style = androidx.compose.ui.text.TextStyle(
                        brush = Brush.horizontalGradient(listOf(Color(0xFFFDE68A), Color(0xFFD97706), Color(0xFFFDE68A)))
                    )
                )
                Spacer(Modifier.height(4.dp))
                Text("工具箱 · 新手教程", fontSize = 13.sp, color = Color(0xFFE0C878))
                Spacer(Modifier.height(14.dp))
                Text(
                    "原生版已内置全部本地工具，无需额外下载。\nAPK 下载位将在第二期开放加密导入。",
                    fontSize = 13.sp,
                    color = Color(0xFFD9C08A),
                    lineHeight = 20.sp
                )
                Spacer(Modifier.height(18.dp))
                Box(
                    Modifier
                        .fillMaxWidth()
                        .background(Brush.horizontalGradient(listOf(Color(0xFFFBBF24), Color(0xFFD97706))), RoundedCornerShape(14.dp))
                        .clickable { notify("原生版无需下载，敬请期待第二期"); onClose() }
                        .padding(vertical = 13.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text("下载 工具箱.apk", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = Color(0xFF3A2A10))
                }
                Spacer(Modifier.height(10.dp))
                Text("校验码：待第二期提供", fontSize = 11.sp, color = Color(0xFF9A8552))
                Spacer(Modifier.height(6.dp))
                Text("关闭", fontSize = 13.sp, color = Color(0xFFB09B66), modifier = Modifier.clickable { onClose() }.padding(6.dp))
            }
        }
    }
}
