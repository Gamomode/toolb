package com.lg.toolbox

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject

enum class Level(val weight: Int, val label: String) {
    NONE(-1, "未登录/无权限"),
    NORMAL(0, "普通版"),
    MID(1, "中级版"),
    VIP(2, "高级版"),
    PAID(3, "付费版"),
    SVIP(4, "SVIP"),
    SPECIAL(5, "特殊"),
    ALL(6, "整合账号会员");

    companion object {
        fun from(name: String): Level = entries.firstOrNull { it.name == name } ?: NONE
    }
}

data class Order(val id: Long, val level: Level, val expire: Long, val days: Int)

data class Plan(
    val level: Level,
    val days: Int,
    val price: Int,
    val originalPrice: Int?,
    val tag: String,
    val feats: List<String>
)

object Plans {
    val byLevel: Map<Level, List<Plan>> = mapOf(
        Level.NORMAL to listOf(
            Plan(Level.NORMAL, 7, 25, 35, "新手首选", listOf("格式转换全部可用", "新手教程随时翻", "专属普通标识")),
            Plan(Level.NORMAL, 30, 185, 200, "人气爆款", listOf("转换功能全开放", "每日签到拿奖励", "普通专属亮牌")),
            Plan(Level.NORMAL, 256, 989, 999, "超长待机", listOf("格式转换任你使", "长租专属答疑", "普通徽章标记"))
        ),
        Level.MID to listOf(
            Plan(Level.MID, 7, 30, 45, "最划算", listOf("普通版功能全含", "加盐慢哈希加持", "中级工具 7 天畅用")),
            Plan(Level.MID, 30, 170, 199, "明星套餐", listOf("继承普通版功能", "加盐慢哈希算法", "进阶教程全解锁")),
            Plan(Level.MID, 365, 1799, 1888, "全年特惠", listOf("普通版功能照单全收", "加盐慢哈希", "全年免费升级"))
        ),
        Level.VIP to listOf(
            Plan(Level.VIP, 7, 46, 67, "最好最划算", listOf("中级版功能全含", "基础哈希计算", "高级版工具 7 天全体验")),
            Plan(Level.VIP, 30, 131, 159, "热门推荐", listOf("含中级版全部能力", "基础哈希随用随算", "教程缓存放心存")),
            Plan(Level.VIP, 365, 622, 648, "年度钜惠", listOf("涵盖中级版功能", "基础哈希无限用", "全年不限次使用"))
        ),
        Level.PAID to listOf(
            Plan(Level.PAID, 7, 169, 187, "快速上车", listOf("高级版功能全含", "HTML转乱码", "新功能优先上手")),
            Plan(Level.PAID, 30, 357, 369, "热卖档位", listOf("含高级版全部能力", "HTML一秒变乱码", "乱码结构全解锁")),
            Plan(Level.PAID, 365, 1090, 1160, "年度之选", listOf("涵盖高级版所有功能", "乱码转换全程可用", "全年免费迭代升级"))
        ),
        Level.SVIP to listOf(
            Plan(Level.SVIP, 7, 460, 480, "至尊划算", listOf("付费版功能全含", "加密网页", "APK分析器")),
            Plan(Level.SVIP, 30, 1240, 1260, "全能之选", listOf("继承付费版功能", "加密网页通行", "APK就地打包")),
            Plan(Level.SVIP, 365, 4999, 5000, "殿堂级", listOf("囊括付费版功能", "网页加密全年用", "APK打包不限次"))
        ),
        Level.SPECIAL to listOf(
            Plan(Level.SPECIAL, 7, 8000, null, "特殊首试", listOf("SVIP 全部功能", "深度重置 APK 工程解锁", "特殊专属标识")),
            Plan(Level.SPECIAL, 30, 22000, null, "人气特档", listOf("SVIP 全部功能", "深度重置 APK 工程解锁", "特殊专属徽章")),
            Plan(Level.SPECIAL, 365, 180000, null, "全年至尊", listOf("SVIP 全部功能", "深度重置 APK 工程解锁", "特殊专属标牌"))
        ),
        Level.ALL to listOf(
            Plan(Level.ALL, 36500, 799999, 800000, "永久尊享", listOf("永久拥有全部等级", "含特殊档全部功能", "买一次终身免续费", "所有工具全部解锁", "新功能终身免费"))
        )
    )
}

data class Task(val id: String, val title: String, val desc: String, val reward: Double, val daily: Boolean, val feat: String? = null)

object Tasks {
    val all = listOf(
        Task("d1", "每日签到", "登录工具箱每日签到", 0.5, true),
        Task("d2", "计算一次哈希", "在基础哈希页面计算一次", 1.0, true, "hash"),
        Task("d3", "体验格式转换", "使用一次格式转换功能", 0.5, true, "convert"),
        Task("d4", "加密一次网页", "在加密网页页面生成一次", 1.0, true, "encrypt"),
        Task("d5", "算一次加盐哈希", "在加盐慢哈希页面计算一次", 1.0, true, "salt"),
        Task("d6", "转一次乱码", "在 HTML 转乱码页面转换一次", 0.5, true, "garbled"),
        Task("d7", "极速打包一次", "用极速打包生成一个 APK", 1.5, true, "fastpack"),
        Task("d8", "分析一个安装包", "用 APK 分析器解析一个安装包", 1.5, true, "analyzer"),
        Task("d9", "安装包加密一次", "用安装包加密保存一次", 1.5, true, "apkenc"),
        Task("d10", "修改一次安装包", "用 APK 修改导出一次", 1.5, true, "apkmod"),
        Task("d11", "用一次文件修改器", "在文件修改器保存一次文件", 1.0, true, "fileedit"),
        Task("d12", "深度重置打包一次", "用深度重置打包生成一个 APK", 2.0, true, "workshop"),
        Task("d13", "更换一次主题色", "在设置里换一个主题颜色", 0.5, true, "theme"),
        Task("o1", "首次注册绑定", "绑定手机号并登录", 5.0, false),
        Task("o2", "加入用户群", "联系客服加入官方交流群", 10.0, false),
        Task("o3", "首次购买", "在购买中心完成任意一次购买", 15.0, false),
        Task("o4", "新人奖励", "注册即可领取，每个用户限领一次", 100.0, false),
        Task("o5", "完成", "完成即领，人人有份", 5.0, false),
        Task("o6", "完成所有终身任务", "领取其他全部终身任务后可领，仅可领取一次", 500.0, false),
        Task("o7", "首次计算哈希", "在基础哈希页面计算一次", 5.0, false, "hash"),
        Task("o8", "首次格式转换", "使用一次格式转换功能", 5.0, false, "convert"),
        Task("o9", "首次加密网页", "在加密网页页面生成一次", 6.0, false, "encrypt"),
        Task("o10", "首次加盐哈希", "在加盐慢哈希页面计算一次", 6.0, false, "salt"),
        Task("o11", "首次转乱码", "在 HTML 转乱码页面转换一次", 5.0, false, "garbled"),
        Task("o12", "首次极速打包", "用极速打包生成一个 APK", 8.0, false, "fastpack"),
        Task("o13", "首次分析安装包", "用 APK 分析器解析一个安装包", 8.0, false, "analyzer"),
        Task("o14", "首次安装包加密", "用安装包加密保存一次", 8.0, false, "apkenc"),
        Task("o15", "首次修改安装包", "用 APK 修改导出一次", 8.0, false, "apkmod"),
        Task("o16", "首次用文件修改器", "在文件修改器保存一次文件", 6.0, false, "fileedit")
    )
}

class Store(context: Context) {

    private val sp: SharedPreferences = context.getSharedPreferences("toolbox_native", Context.MODE_PRIVATE)

    val officialPhone = "13556260740"
    val officialPwd = "1GHTF545CC4"

    var currentUser: String? = sp.getString("current_user", null)
        private set

    fun login(phone: String, pwd: String): String? {
        if (!Regex("^1\\d{10}$").matches(phone)) return "请输入正确的 11 位手机号"
        if (pwd.length < 6) return "密码不能少于 6 位"
        if (phone == officialPhone) {
            if (pwd != officialPwd) return "密码错误，请重试"
            currentUser = phone
            sp.edit().putString("current_user", phone).apply()
            if (!sp.getBoolean("official_bonus_$phone", false)) {
                sp.edit().putBoolean("official_bonus_$phone", true).apply()
                addBalance(500000.0)
            }
            return null
        }
        val saved = sp.getString("pwd_$phone", null)
        if (saved == null) return "该手机号未注册，请先注册"
        if (saved != pwd) return "密码错误，请重试"
        currentUser = phone
        sp.edit().putString("current_user", phone).apply()
        return null
    }

    fun register(phone: String, pwd: String): String? {
        if (!Regex("^1\\d{10}$").matches(phone)) return "请输入正确的 11 位手机号"
        if (pwd.length < 6) return "密码不能少于 6 位"
        if (phone == officialPhone) return "该手机号为官方号，请直接登录"
        if (sp.contains("pwd_$phone")) return "该手机号已注册，请直接登录"
        sp.edit().putString("pwd_$phone", pwd).apply()
        currentUser = phone
        sp.edit().putString("current_user", phone).apply()
        setOrders(emptyList())
        setBalance(0.0)
        return null
    }

    fun logout() {
        currentUser = null
        sp.edit().remove("current_user").apply()
    }

    fun deleteAccount() {
        val phone = currentUser ?: return
        val keys = sp.all.keys.filter { (it.endsWith("_$phone") && (it.startsWith("pwd_") || it.startsWith("orders_") || it.startsWith("balance_") || it.startsWith("tasks_") || it.startsWith("notified_"))) || it.startsWith("used_$phone") }
        val e = sp.edit()
        keys.forEach { e.remove(it) }
        e.remove("current_user").apply()
        currentUser = null
    }

    fun maskedUser(): String {
        val p = currentUser ?: return "未登录"
        return if (p.length >= 11) p.substring(0, 3) + "*****" + p.substring(9) else p
    }

    fun balance(): Double = sp.getString("balance_${currentUser()}", "0")?.toDoubleOrNull() ?: 0.0

    private fun currentUser(): String = currentUser ?: "anon"

    fun setBalance(v: Double) {
        sp.edit().putString("balance_${currentUser()}", v.toString()).apply()
    }

    fun addBalance(delta: Double) = setBalance(balance() + delta)

    fun orders(): List<Order> {
        val raw = sp.getString("orders_${currentUser()}", null) ?: return emptyList()
        return try {
            val arr = JSONArray(raw)
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                Order(o.getLong("id"), Level.from(o.getString("level")), o.getLong("expire"), o.getInt("days"))
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    private fun setOrders(list: List<Order>) {
        val arr = JSONArray()
        list.forEach { o ->
            arr.put(JSONObject().put("id", o.id).put("level", o.level.name).put("expire", o.expire).put("days", o.days))
        }
        sp.edit().putString("orders_${currentUser()}", arr.toString()).apply()
    }

    fun effectiveLevel(): Level {
        val now = System.currentTimeMillis()
        return orders().filter { it.expire > now }.maxByOrNull { it.level.weight }?.level ?: Level.NONE
    }

    fun buy(plan: Plan): String? {
        if (balance() < plan.price) return "余额不足，先去任务中心领奖励吧"
        setBalance(balance() - plan.price)
        val now = System.currentTimeMillis()
        val dur = plan.days * 86400000L
        val list = orders().toMutableList()
        val same = list.firstOrNull { it.level == plan.level }
        if (same != null) {
            val newExpire = maxOf(same.expire, now) + dur
            list[list.indexOf(same)] = same.copy(expire = newExpire, days = same.days + plan.days)
        } else {
            list.add(Order(now, plan.level, now + dur, plan.days))
        }
        setOrders(list)
        return null
    }

    fun ordersText(): String {
        val now = System.currentTimeMillis()
        val list = orders().sortedBy { it.expire }
        if (list.isEmpty()) return "暂无订单"
        return list.joinToString("\n") { o ->
            val expired = o.expire < now
            val remain = if (expired) o.expire - now else o.expire - now
            val d = remain / 86400000
            val h = remain % 86400000 / 3600000
            val m = remain % 3600000 / 60000
            val s = remain % 60000 / 1000
            val t = "%d天 %02d:%02d:%02d".format(d, h, m, s)
            "${o.level.label}  " + (if (expired) "过期 " else "剩 ") + t
        }
    }

    private fun claimedKey(daily: Boolean): String {
        val p = currentUser ?: return "tasks_none"
        return if (daily) "tasks_daily_${p}_${todayKey()}" else "tasks_once_$p"
    }

    private fun todayKey(): String {
        val c = java.util.Calendar.getInstance()
        return "${c.get(java.util.Calendar.YEAR)}-${c.get(java.util.Calendar.MONTH) + 1}-${c.get(java.util.Calendar.DAY_OF_MONTH)}"
    }

    fun claimed(daily: Boolean): List<String> {
        val raw = sp.getString(claimedKey(daily), null) ?: return emptyList()
        return try {
            val arr = JSONArray(raw)
            (0 until arr.length()).map { arr.getString(it) }
        } catch (e: Exception) {
            emptyList()
        }
    }

    private fun saveClaimed(daily: Boolean, list: List<String>) {
        val arr = JSONArray()
        list.forEach { arr.put(it) }
        sp.edit().putString(claimedKey(daily), arr.toString()).apply()
    }

    fun claim(task: Task): String? {
        if (currentUser == null) return "请先登录后再操作"
        if (!taskDone(task)) return "先完成任务再领取哦"
        val list = claimed(task.daily).toMutableList()
        if (list.contains(task.id)) return "已领取"
        if (task.id == "o6") {
            val others = Tasks.all.filter { !it.daily && it.id != "o6" }
            if (!others.all { list.contains(it.id) }) return "先领取其他所有终身任务哦"
        }
        list.add(task.id)
        saveClaimed(task.daily, list)
        addBalance(task.reward)
        return null
    }

    fun markUse(feat: String) {
        val p = currentUser ?: return
        sp.edit()
            .putBoolean("used_${p}_once_$feat", true)
            .putBoolean("used_${p}_daily_${todayKey()}_$feat", true)
            .apply()
    }

    fun usedToday(feat: String): Boolean {
        val p = currentUser ?: return false
        return sp.getBoolean("used_${p}_daily_${todayKey()}_$feat", false)
    }

    fun usedEver(feat: String): Boolean {
        val p = currentUser ?: return false
        return sp.getBoolean("used_${p}_once_$feat", false)
    }

    fun taskDone(task: Task): Boolean {
        return when {
            task.feat != null -> if (task.daily) usedToday(task.feat) else usedEver(task.feat)
            task.id == "d1" || task.id == "o1" || task.id == "o4" || task.id == "o5" -> currentUser != null
            task.id == "o3" -> orders().isNotEmpty()
            else -> true
        }
    }

    fun themeIndex(): Int = sp.getInt("theme", 0)

    fun setThemeIndex(i: Int) {
        sp.edit().putInt("theme", i).apply()
        markUse("theme")
    }
}

object Usage {
    var store: Store? = null
    fun mark(feat: String) {
        store?.markUse(feat)
    }
}
