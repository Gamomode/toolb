package com.hairplnmo.app

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.border
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.Brush
import androidx.compose.material.icons.filled.EditNote
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Tag
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CardGiftcard
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.Handyman
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon

import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.composed
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import kotlinx.coroutines.delay
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import java.security.MessageDigest
import kotlin.system.exitProcess
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState

val BgColor = Color(0xFFF3F5F9)
val CardColor = Color(0xFFFFFFFF)
val AccentColor = Color(0xFF1A6DFF)
val MainText = Color(0xFF1B2230)
val SubText = Color(0xFF7A8499)
val LineColor = Color(0xFFE3E8F0)

data class Plan(val price: String, val orig: String, val days: Int, val badge: String, val animate: Boolean)
val ExpectedSig = "241e92d50251dfce8965c4381888f231fb7a78d67b35ed7ee228a1533b1a1437"

fun Modifier.tap(onClick: () -> Unit): Modifier = composed {
    clickable(interactionSource = remember { MutableInteractionSource() }, indication = null, onClick = onClick)
}

@Composable
fun FloatField(
    value: String,
    onValueChange: (String) -> Unit,
    label: String,
    modifier: Modifier = Modifier,
    isPassword: Boolean = false
) {
    var focused by remember { mutableStateOf(false) }
    val up = focused || value.isNotEmpty()
    val labelSize by animateFloatAsState(if (up) 11f else 14f)
    val labelTop by animateDpAsState(if (up) 8.dp else 20.dp)
    val inputTop by animateDpAsState(if (up) 16.dp else 0.dp)
    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(56.dp)
            .border(1.dp, if (focused) AccentColor else LineColor, RoundedCornerShape(12.dp))
            .background(CardColor, RoundedCornerShape(12.dp))
    ) {
        Text(
            label,
            fontSize = labelSize.sp,
            color = if (focused) AccentColor else SubText,
            modifier = Modifier
                .align(Alignment.TopStart)
                .padding(start = 14.dp, top = labelTop)
        )
        BasicTextField(
            value = value,
            onValueChange = onValueChange,
            singleLine = true,
            textStyle = TextStyle(fontSize = 15.sp, color = MainText),
            visualTransformation = if (isPassword) PasswordVisualTransformation() else VisualTransformation.None,
            keyboardOptions = KeyboardOptions(keyboardType = if (isPassword) KeyboardType.Password else KeyboardType.Text),
            modifier = Modifier
                .align(Alignment.CenterStart)
                .padding(start = 14.dp, end = 14.dp, top = inputTop)
                .fillMaxWidth()
                .onFocusChanged { focused = it.isFocused }
        )
    }
}

class MainActivity : ComponentActivity() {
    fun isSignatureValid(): Boolean {
        return try {
            val info = packageManager.getPackageInfo(packageName, PackageManager.GET_SIGNATURES)
            val sig = info.signatures?.firstOrNull() ?: return false
            val digest = MessageDigest.getInstance("SHA-256").digest(sig.toByteArray())
            val hex = digest.joinToString("") { "%02x".format(it) }
            hex == ExpectedSig
        } catch (e: Exception) {
            false
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        val controller = WindowCompat.getInsetsController(window, window.decorView)
        controller.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        controller.hide(WindowInsetsCompat.Type.systemBars())
        val sigOk = isSignatureValid()
        val startUser = getLoggedInUser(this)
        setContent {
            var stage by remember {
                mutableStateOf(
                    when {
                        startUser.isEmpty() -> "login"
                        else -> "loading"
                    }
                )
            }
            var currentUser by remember { mutableStateOf(startUser) }
            var premiumPopup by remember { mutableStateOf(false) }
            Surface(color = BgColor, modifier = Modifier.fillMaxSize()) {
                if (!sigOk) {
                    TamperScreen(onExit = {
                        finishAffinity()
                        exitProcess(0)
                    })
                } else {
                    when (stage) {
                        "login" -> LoginScreen(onSuccess = { u ->
                            currentUser = u
                            stage = "loading"
                        })
                        "purchase" -> PurchaseScreen(onBack = { stage = "home" })
                        "loading" -> LoadingScreen(onDone = { stage = "home" })
                        "home" -> HomeScreen(
                            currentUser = currentUser,
                            showPremiumPopup = premiumPopup,
                            onDismissPremiumPopup = { premiumPopup = false },
                            onPremium = { premiumPopup = true },
                            onLogout = {
                                setLoggedInUser(applicationContext, "")
                                currentUser = ""
                                stage = "login"
                            },
                            onBuy = { stage = "purchase" }
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun TamperScreen(onExit: () -> Unit) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF1B2230)),
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(28.dp)
                .background(CardColor, RoundedCornerShape(22.dp))
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text("⚠", fontSize = 40.sp)
            Spacer(Modifier.height(12.dp))
            Text("检测到应用被修改", fontSize = 19.sp, fontWeight = FontWeight.Bold, color = MainText)
            Spacer(Modifier.height(8.dp))
            Text(
                "应用的文件或签名已被改动，为保护安全无法继续使用。",
                fontSize = 13.sp,
                color = SubText,
                textAlign = TextAlign.Center,
                lineHeight = 20.sp
            )
            Spacer(Modifier.height(20.dp))
            Button(
                onClick = onExit,
                modifier = Modifier.fillMaxWidth(),
                                colors = ButtonDefaults.buttonColors(containerColor = AccentColor)
            ) {
                Text("确定", fontSize = 15.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}


fun getLoggedInUser(context: Context): String {
    return context.getSharedPreferences("hairplnmo", Context.MODE_PRIVATE).getString("logged_user", "") ?: ""
}

fun setLoggedInUser(context: Context, user: String) {
    context.getSharedPreferences("hairplnmo", Context.MODE_PRIVATE).edit().putString("logged_user", user).apply()
}

fun setLoggedNick(context: Context, nick: String) {
    context.getSharedPreferences("hairplnmo", Context.MODE_PRIVATE).edit().putString("logged_nick", nick).apply()
}

fun getLoggedNick(context: Context): String {
    return context.getSharedPreferences("hairplnmo", Context.MODE_PRIVATE).getString("logged_nick", "") ?: ""
}

fun checkLogin(context: Context, user: String, pass: String): String {
    val users = context.getSharedPreferences("hairplnmo", Context.MODE_PRIVATE)
        .getStringSet("accounts", emptySet()) ?: emptySet()
    return if (users.contains("$user|$pass")) "ok" else "账号或密码错误"
}

fun registerAccount(context: Context, user: String, pass: String): String {
    val sp = context.getSharedPreferences("hairplnmo", Context.MODE_PRIVATE)
    val users = sp.getStringSet("accounts", emptySet()) ?: emptySet()
    return when {
        user.isBlank() || pass.isBlank() -> "账号和密码不能为空"
        users.any { it.substringBefore('|') == user } -> "该账号已存在"
        else -> {
            sp.edit().putStringSet("accounts", users + "$user|$pass").apply()
            "注册成功"
        }
    }
}

fun openPayApp(context: Context, pkg: String): Boolean = try {
    context.packageManager.getLaunchIntentForPackage(pkg)?.let {
        it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(it)
        true
    } ?: false
} catch (e: Exception) {
    false
}

fun openPayAppCheck(context: Context, pkg: String): Boolean = try {
    context.packageManager.getLaunchIntentForPackage(pkg) != null
} catch (e: Exception) {
    false
}

fun generatePremiumCode(): String {
    val letters = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz"
    val digits = "0123456789"
    val p1 = (1..5).map { letters.random() }.joinToString("")
    val p2 = (1..4).map { digits.random() }.joinToString("")
    return "PLAB-toen-$p1-$p2-2026"
}

fun completePurchase(context: Context, price: String, days: Int): String {
    val time = java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", java.util.Locale.CHINA).format(java.util.Date())
    val sp = context.getSharedPreferences("hairplnmo", Context.MODE_PRIVATE)
    val account = sp.getString("logged_user", "") ?: ""
    val nick = sp.getString("logged_nick", "") ?: ""
    val name = nick.ifBlank { account }
    val code = generatePremiumCode()
    val codes = (sp.getStringSet("premium_codes", emptySet()) ?: emptySet()) + "$code|$days"
    val records = sp.getStringSet("purchase_records", emptySet()) ?: emptySet()
    val record = "$time|$name|$price|高级账号 ${days}天|" + getDeviceId(context)
    sp.edit().putStringSet("premium_codes", codes).putStringSet("purchase_records", records + "$record|$code").apply()
    return code
}

fun redeemCode(context: Context, input: String): String {
    val sp = context.getSharedPreferences("hairplnmo", Context.MODE_PRIVATE)
    val c = input.trim()
    if (c.isEmpty()) return "请输入兑换码"
    val codes = sp.getStringSet("premium_codes", emptySet()) ?: emptySet()
    val days = codes.firstOrNull { it.substringBeforeLast('|').equals(c, ignoreCase = true) }
        ?.substringAfterLast('|')?.toIntOrNull() ?: return "兑换码无效"
    val now = System.currentTimeMillis()
    val expire = sp.getLong("premium_expire", 0L)
    val base = if (expire > now) expire else now
    sp.edit().putLong("premium_expire", base + days * 86400000L).apply()
    val time = java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", java.util.Locale.CHINA).format(java.util.Date())
    val redeemed = (sp.getStringSet("redeemed_codes", emptySet()) ?: emptySet()) + "$c|$time"
    sp.edit().putStringSet("redeemed_codes", redeemed).apply()
    return "ok"
}

fun getPremiumExpire(context: Context): Long =
    context.getSharedPreferences("hairplnmo", Context.MODE_PRIVATE).getLong("premium_expire", 0L)

fun isPremium(context: Context): Boolean = getPremiumExpire(context) > System.currentTimeMillis()

fun getDeviceId(context: Context): String {
    val sp = context.getSharedPreferences("hairplnmo", Context.MODE_PRIVATE)
    var id = sp.getString("device_id", "") ?: ""
    if (id.isBlank()) {
        id = java.util.UUID.randomUUID().toString().replace("-", "").substring(0, 12)
        sp.edit().putString("device_id", id).apply()
    }
    return id
}

@Composable
fun PurchaseScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val plans = listOf(
        Plan("0元", "", 1, "免费", false),
        Plan("0.01元", "1元", 1, "新用户试用", true),
        Plan("4.99元", "6元", 7, "最划算!", true),
        Plan("5.99元", "7元", 21, "超值装", true),
        Plan("7.99元", "9元", 40, "天数最多", true),
        Plan("9.9元", "12元", 80, "天数超多", true)
    )
    var selected by remember { mutableStateOf(0) }
    var showConfirm by remember { mutableStateOf(false) }
    var showPayMethod by remember { mutableStateOf(false) }
    var showPayDialog by remember { mutableStateOf(false) }
    var showPayResult by remember { mutableStateOf(false) }
    var showKeyDialog by remember { mutableStateOf(false) }
    var payAppName by remember { mutableStateOf("") }
    var pendingPay by remember { mutableStateOf(false) }
    var generatedKey by remember { mutableStateOf("") }
    var payTime by remember { mutableStateOf("") }
    var jumpMsg by remember { mutableStateOf("") }
    var claiming by remember { mutableStateOf(false) }
    var isClaim by remember { mutableStateOf(false) }
    var endTime by remember { mutableStateOf("") }
    var claimTrigger by remember { mutableStateOf(false) }
    val sp = context.getSharedPreferences("hairplnmo", Context.MODE_PRIVATE)
    val claimedAccounts = sp.getStringSet("free_claim_accounts", emptySet()) ?: emptySet()
    var freeClaimed by remember {
        mutableStateOf(sp.getBoolean("free_claimed", false) || (sp.getString("logged_user", "") ?: "") in claimedAccounts)
    }
    var showFreePrompt by remember { mutableStateOf(!sp.getBoolean("free_prompt_off", false) && !(sp.getBoolean("free_claimed", false) || (sp.getString("logged_user", "") ?: "") in claimedAccounts)) }
    var redeemed by remember {
        mutableStateOf(context.getSharedPreferences("hairplnmo", Context.MODE_PRIVATE)
            .getStringSet("redeemed_codes", emptySet()) ?: emptySet())
    }
    val clipboard = LocalClipboardManager.current
    val lifecycleOwner = LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME && pendingPay) {
                pendingPay = false
                showPayResult = true
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }
    LaunchedEffect(claimTrigger) {
        if (claimTrigger) {
            claimTrigger = false
            if (freeClaimed) {
                claiming = false
                jumpMsg = "已领取过,请勿重领"
                return@LaunchedEffect
            }
            claiming = true
            delay(2000)
            val nowMs = System.currentTimeMillis()
            val fmt = java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", java.util.Locale.CHINA)
            val timeStr = fmt.format(java.util.Date(nowMs))
            val codes = sp.getStringSet("premium_codes", emptySet()) ?: emptySet()
            val count = codes.count { it.startsWith("CSAQ-") } + 1
            val code = "CSAQ-$count-" + (1..6).map { "0123456789".random() }.joinToString("")
            val account = sp.getString("logged_user", "") ?: ""
            val nick = sp.getString("logged_nick", "") ?: ""
            val name = nick.ifBlank { account }
            val records = sp.getStringSet("purchase_records", emptySet()) ?: emptySet()
            val record = "$timeStr|$name|0元|高级账号 1天|" + getDeviceId(context) + "|$code"
            val redeemedSet = (sp.getStringSet("redeemed_codes", emptySet()) ?: emptySet()) + "$code|$timeStr"
            sp.edit()
                .putStringSet("premium_codes", codes + "$code|1")
                .putStringSet("purchase_records", records + record)
                .putStringSet("redeemed_codes", redeemedSet)
                .putStringSet("free_claim_accounts", claimedAccounts + account)
                .putBoolean("free_claimed", true)
                .apply()
            val expire = sp.getLong("premium_expire", 0L)
            val base = if (expire > nowMs) expire else nowMs
            sp.edit().putLong("premium_expire", base + 86400000L).apply()
            redeemed = redeemedSet
            freeClaimed = true
            generatedKey = code
            payTime = timeStr
            endTime = fmt.format(java.util.Date(nowMs + 86400000L))
            isClaim = true
            claiming = false
            showKeyDialog = true
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(BgColor)
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            TextButton(onClick = onBack, contentPadding = PaddingValues(0.dp)) {
                Text("← 返回", fontSize = 14.sp, color = SubText)
            }
        }
        Text("购买兑换码", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = MainText)
        Spacer(Modifier.height(6.dp))
        Text("选择套餐，支付成功后自动生成兑换码", fontSize = 13.sp, color = SubText)
        Spacer(Modifier.height(10.dp))
        Text(
            "支付说明：支付后钱作废删除，请想好再支付，支付后无法退回！",
            fontSize = 12.sp,
            color = Color(0xFFB07A1E),
            lineHeight = 18.sp,
            modifier = Modifier
                .fillMaxWidth()
                .background(Color(0xFFFDF4E3), RoundedCornerShape(10.dp))
                .padding(horizontal = 12.dp, vertical = 8.dp)
        )
        Spacer(Modifier.height(20.dp))
        plans.forEachIndexed { i, p ->
            PlanCard(p, selected == i, gray = i == 0 && freeClaimed) {
                if (i == 0 && freeClaimed) jumpMsg = "已领取过,请勿重领" else selected = i
            }
            Spacer(Modifier.height(14.dp))
        }
        Spacer(Modifier.height(10.dp))
        Button(
            onClick = { if (selected == 0) claimTrigger = true else showConfirm = true },
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(14.dp),
            enabled = !(selected == 0 && claiming),
            colors = ButtonDefaults.buttonColors(containerColor = AccentColor)
        ) {
            Text(
                if (selected == 0) (if (claiming) "加载中···请稍等片刻" else "领取") else "购买",
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold
            )
        }
        if (jumpMsg.isNotEmpty()) {
            Spacer(Modifier.height(12.dp))
            Text(jumpMsg, fontSize = 13.sp, color = Color(0xFFD0453E), modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
        }
        if (redeemed.isNotEmpty()) {
            Spacer(Modifier.height(20.dp))
            Text("已兑换", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = MainText)
            Spacer(Modifier.height(8.dp))
            redeemed.sortedDescending().forEach { r ->
                val parts = r.split("|")
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(CardColor, RoundedCornerShape(12.dp))
                        .padding(horizontal = 14.dp, vertical = 10.dp)
                ) {
                    Text(parts.getOrElse(0) { "" }, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = AccentColor)
                    Spacer(Modifier.height(2.dp))
                    Text("兑换时间：${parts.getOrElse(1) { "" }}", fontSize = 11.sp, color = SubText)
                }
                Spacer(Modifier.height(6.dp))
            }
        }
        Spacer(Modifier.height(24.dp))
    }

    if (showFreePrompt) {
        AlertDialog(
            onDismissRequest = { showFreePrompt = false },
            title = { Text("新用户免费领取", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = MainText) },
            text = { Text("新用户可免费领取高级账号 1天，点击领取立即生效。", fontSize = 14.sp, color = SubText, lineHeight = 20.sp) },
            confirmButton = {
                TextButton(onClick = {
                    showFreePrompt = false
                    selected = 0
                    claimTrigger = true
                }) { Text("领取", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = AccentColor) }
            },
            dismissButton = {
                TextButton(onClick = {
                    showFreePrompt = false
                    sp.edit().putBoolean("free_prompt_off", true).apply()
                }) { Text("不再提醒", fontSize = 15.sp, color = SubText) }
            }
        )
    }

    if (showConfirm) {
        AlertDialog(
            onDismissRequest = { showConfirm = false },
            title = { Text("确定支付？", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = MainText) },
            text = { Text("支付后钱款将作废删除，不会进入任何账户，也无法退钱。", fontSize = 14.sp, color = SubText, lineHeight = 20.sp) },
            confirmButton = {
                TextButton(onClick = {
                    showConfirm = false
                    showPayMethod = true
                }) { Text("确定", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = AccentColor) }
            },
            dismissButton = {
                TextButton(onClick = { showConfirm = false }) { Text("取消", fontSize = 15.sp, color = SubText) }
            }
        )
    }

    if (showPayMethod) {
        AlertDialog(
            onDismissRequest = { showPayMethod = false },
            title = { Text("选择支付方式", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = MainText) },
            text = {
                Column {
                    Button(
                        onClick = {
                            showPayMethod = false
                            payAppName = "支付宝"
                            if (openPayAppCheck(context, "com.eg.android.AlipayGphone")) showPayDialog = true else jumpMsg = "未安装支付宝"
                        },
                        modifier = Modifier.fillMaxWidth(),
                                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1677FF))
                    ) {
                        Text("支付宝", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = Color.White)
                    }
                    Spacer(Modifier.height(10.dp))
                    Button(
                        onClick = {
                            showPayMethod = false
                            payAppName = "微信"
                            if (openPayAppCheck(context, "com.tencent.mm")) showPayDialog = true else jumpMsg = "未安装微信"
                        },
                        modifier = Modifier.fillMaxWidth(),
                                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E9E6A))
                    ) {
                        Text("微信", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = Color.White)
                    }
                    Spacer(Modifier.height(10.dp))
                    Button(
                        onClick = {
                            showPayMethod = false
                            payAppName = "抖音"
                            if (openPayAppCheck(context, "com.ss.android.ugc.aweme")) showPayDialog = true else jumpMsg = "未安装抖音"
                        },
                        modifier = Modifier.fillMaxWidth(),
                                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFB07A1E))
                    ) {
                        Text("抖音支付", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = Color.White)
                    }
                }
            },
            confirmButton = {},
            dismissButton = {}
        )
    }

    if (showPayDialog) {
        AlertDialog(
            onDismissRequest = { showPayDialog = false },
            title = { Text("支付", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = MainText) },
            text = { Text("使用${payAppName}支付 ${plans[selected].price}（高级账号 ${plans[selected].days}天）。点击确定后将跳转到${payAppName}完成付款。", fontSize = 14.sp, color = SubText, lineHeight = 20.sp) },
            confirmButton = {
                TextButton(onClick = {
                    showPayDialog = false
                    val pkg = when (payAppName) {
                        "支付宝" -> "com.eg.android.AlipayGphone"
                        "微信" -> "com.tencent.mm"
                        else -> "com.ss.android.ugc.aweme"
                    }
                    jumpMsg = if (openPayApp(context, pkg)) "" else "未安装$payAppName"
                    pendingPay = jumpMsg.isEmpty()
                }) { Text("确定支付", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = AccentColor) }
            },
            dismissButton = {
                TextButton(onClick = { showPayDialog = false }) { Text("取消", fontSize = 15.sp, color = SubText) }
            }
        )
    }

    if (showPayResult) {
        AlertDialog(
            onDismissRequest = { },
            title = { Text("支付失败，请重试", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Color(0xFFD0453E)) },
            text = { Text("未检测到支付成功。如果你已在${payAppName}完成付款，请点击「已完成支付」自动生成兑换码；否则请重试。", fontSize = 14.sp, color = SubText, lineHeight = 20.sp) },
            confirmButton = {
                TextButton(onClick = {
                    showPayResult = false
                    generatedKey = completePurchase(context, plans[selected].price, plans[selected].days)
                    payTime = java.text.SimpleDateFormat("yyyy-MM-dd HH:mm", java.util.Locale.CHINA).format(java.util.Date())
                    showKeyDialog = true
                }) { Text("已完成支付", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = AccentColor) }
            },
            dismissButton = {
                TextButton(onClick = { showPayResult = false }) { Text("确定", fontSize = 15.sp, color = SubText) }
            }
        )
    }

    if (showKeyDialog) {
        AlertDialog(
            onDismissRequest = { showKeyDialog = false },
            title = { Text(if (isClaim) "免费领取成功" else "支付成功", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = MainText) },
            text = {
                Column {
                    Text("时间：$payTime", fontSize = 14.sp, color = SubText)
                    Spacer(Modifier.height(3.dp))
                    Text("付费：${plans[selected].price}", fontSize = 14.sp, color = SubText)
                    Spacer(Modifier.height(3.dp))
                    Text("内容：高级账号 ${plans[selected].days}天", fontSize = 14.sp, color = SubText)
                    if (isClaim) {
                        Spacer(Modifier.height(3.dp))
                        Text("结束时间：$endTime", fontSize = 14.sp, color = SubText)
                    }
                    Spacer(Modifier.height(12.dp))
                    Text(
                        generatedKey,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = AccentColor,
                        modifier = Modifier
                            .fillMaxWidth()
                            .drawBehind {
                                drawRoundRect(
                                    Color(0xFF1A6DFF),
                                    cornerRadius = CornerRadius(12.dp.toPx()),
                                    style = Stroke(width = 2.dp.toPx(), pathEffect = PathEffect.dashPathEffect(floatArrayOf(12f, 8f)))
                                )
                            }
                            .padding(horizontal = 12.dp, vertical = 10.dp)
                            .tap {
                                clipboard.setText(AnnotatedString(generatedKey))
                                jumpMsg = "兑换码已复制"
                            }
                    )
                    Spacer(Modifier.height(8.dp))
                    Text("点击兑换码可复制。回到高级账号输入兑换码即可激活。", fontSize = 12.sp, color = SubText)
                }
            },
            confirmButton = { },
            dismissButton = {
                TextButton(onClick = { showKeyDialog = false }) { Text("确定", fontSize = 15.sp, color = SubText) }
            }
        )
    }
}

@Composable
fun PlanCard(p: Plan, selected: Boolean, gray: Boolean = false, onClick: () -> Unit) {
    var animStarted by remember { mutableStateOf(false) }
    var cardShown by remember { mutableStateOf(false) }
    val target = p.price.removeSuffix("元").toFloatOrNull() ?: 0f
    val start = p.orig.removeSuffix("元").toFloatOrNull() ?: 0f
    LaunchedEffect(Unit) {
        delay(100)
        cardShown = true
        if (p.animate) {
            delay(400)
            animStarted = true
        }
    }
    val priceNum by animateFloatAsState(if (p.animate && animStarted) target else start)
    val cardAlpha by animateFloatAsState(if (cardShown) 1f else 0f)
    val cardOffset by animateDpAsState(if (cardShown) 0.dp else 40.dp)
    Box(
        Modifier
            .fillMaxWidth()
            .graphicsLayer {
                alpha = cardAlpha
                translationY = cardOffset.toPx()
            }
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(if (gray) Color(0xFFEEF1F6) else CardColor, RoundedCornerShape(18.dp))
                .then(if (selected) Modifier.border(2.dp, AccentColor, RoundedCornerShape(18.dp)) else Modifier)
                .tap(onClick)
                .padding(18.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                if (p.animate) {
                    Text(String.format("%.2f元", priceNum), fontSize = 24.sp, fontWeight = FontWeight.Bold, color = if (gray) SubText else if (selected) AccentColor else MainText)
                } else {
                    Text(p.price, fontSize = 24.sp, fontWeight = FontWeight.Bold, color = if (gray) SubText else if (selected) AccentColor else MainText)
                }
                if (p.orig.isNotEmpty()) {
                    Spacer(Modifier.height(4.dp))
                    Text(p.orig, fontSize = 13.sp, color = SubText, textDecoration = TextDecoration.LineThrough)
                }
                Spacer(Modifier.height(4.dp))
                Text("高级账号 ${p.days}天", fontSize = 13.sp, color = SubText)
            }
            Box(
                modifier = Modifier
                    .size(24.dp)
                    .then(
                        if (selected) Modifier.background(if (gray) Color(0xFFC6CCD8) else AccentColor, CircleShape)
                        else Modifier.border(2.dp, Color(0xFFC6CCD8), CircleShape)
                    ),
                contentAlignment = Alignment.Center
            ) {
                if (selected) {
                    Icon(Icons.Filled.Check, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
                }
            }
        }
        if (p.badge.isNotEmpty()) {
            Text(
                p.badge,
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White,
                modifier = Modifier
                    .background(if (gray) Color(0xFFC6CCD8) else Color(0xFFD0453E), RoundedCornerShape(topStart = 18.dp, topEnd = 4.dp, bottomEnd = 12.dp))
                    .padding(horizontal = 10.dp, vertical = 4.dp)
            )
        }
    }
}

@Composable
fun LoginScreen(onSuccess: (String) -> Unit) {
    val context = LocalContext.current
    var mode by remember { mutableStateOf("login") }
    var user by remember { mutableStateOf("") }
    var pass by remember { mutableStateOf("") }
    var nick by remember { mutableStateOf("") }
    var msg by remember { mutableStateOf("") }
    var msgColor by remember { mutableStateOf(AccentColor) }
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFFFFFFF))
            .padding(horizontal = 28.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Box(
            modifier = Modifier
                .size(64.dp)
                .background(Color(0xFF1C1C1E), RoundedCornerShape(18.dp)),
            contentAlignment = Alignment.Center
        ) {
            Icon(Icons.Filled.Handyman, contentDescription = null, tint = Color.White, modifier = Modifier.size(30.dp))
        }
        Spacer(Modifier.height(16.dp))
        Text("HAirPLNmo", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = MainText)
        Spacer(Modifier.height(6.dp))
        Text(if (mode == "login") "登录以继续" else "创建新账号", fontSize = 14.sp, color = SubText)
        Spacer(Modifier.height(30.dp))
        FloatField(
            value = user,
            onValueChange = { user = it; msg = "" },
            label = "账号",
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(14.dp))
        FloatField(
            value = pass,
            onValueChange = { pass = it; msg = "" },
            label = "密码",
            modifier = Modifier.fillMaxWidth(),
            isPassword = true
        )
        Spacer(Modifier.height(14.dp))
        if (mode == "register") {
            FloatField(
                value = nick,
                onValueChange = { nick = it; msg = "" },
                label = "请输入昵称",
                modifier = Modifier.fillMaxWidth()
            )
        }
        Spacer(Modifier.height(20.dp))
        Button(
            onClick = {
                if (mode == "login") {
                    val r = checkLogin(context, user.trim(), pass)
                    if (r == "ok") {
                        setLoggedInUser(context, user.trim())
                        onSuccess(user.trim())
                    } else {
                        msg = r
                        msgColor = Color(0xFFD0453E)
                    }
                } else {
                    if (nick.isBlank()) {
                        msg = "请输入昵称"
                        msgColor = Color(0xFFD0453E)
                        return@Button
                    }
                    val r = registerAccount(context, user.trim(), pass)
                    if (r == "注册成功") {
                        setLoggedNick(context, nick.trim())
                        mode = "login"
                        pass = ""
                        nick = ""
                        msg = "注册成功，请登录"
                        msgColor = Color(0xFF1E9E6A)
                    } else {
                        msg = r
                        msgColor = Color(0xFFD0453E)
                    }
                }
            },
            modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(containerColor = AccentColor)
        ) {
            Text(if (mode == "login") "登录" else "注册", fontSize = 15.sp, fontWeight = FontWeight.Bold)
        }
        if (msg.isNotEmpty()) {
            Spacer(Modifier.height(12.dp))
            Text(msg, fontSize = 14.sp, color = msgColor, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
        }
        Spacer(Modifier.height(10.dp))
        TextButton(onClick = {
            mode = if (mode == "login") "register" else "login"
            msg = ""
        }, contentPadding = PaddingValues(6.dp)) {
            Text(
                if (mode == "login") "没有账号？去注册" else "已有账号？去登录",
                fontSize = 13.sp,
                color = SubText
            )
        }
    }
}

private data class OrderInfo(val time: String, val content: String, val amount: String, val code: String?, val redeemed: Boolean, val startMillis: Long, val expireMillis: Long)

@Composable
fun OrdersDialog(currentUser: String, onDismiss: () -> Unit) {
    val context = LocalContext.current
    val sp = context.getSharedPreferences("hairplnmo", Context.MODE_PRIVATE)
    val clipboard = LocalClipboardManager.current
    var copiedKey by remember { mutableStateOf("") }
    var now by remember { mutableStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) {
        while (true) {
            delay(1000)
            now = System.currentTimeMillis()
        }
    }
    val records = sp.getStringSet("purchase_records", emptySet()) ?: emptySet()
    val nick = getLoggedNick(context)
    val displayName = nick.ifBlank { currentUser }
    val fmt = java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", java.util.Locale.CHINA)
    val fmtMin = java.text.SimpleDateFormat("yyyy-MM-dd HH:mm", java.util.Locale.CHINA)
    val redeemedMap = (sp.getStringSet("redeemed_codes", emptySet()) ?: emptySet())
        .mapNotNull { e ->
            val p = e.split("|")
            if (p.size == 2) p[0] to p[1] else null
        }.toMap()
    val myRecords = records.filter {
        val f = it.split("|")
        if (f.size >= 5) f[4] == getDeviceId(context) else f.getOrElse(1) { "" } == displayName
    }
    val myOrders = myRecords.map { r ->
        val f = r.split("|")
        val time = f.getOrElse(0) { "" }
        val content = f.getOrElse(3) { "高级账号" }
        val amount = f.getOrElse(2) { "" }
        val code = f.getOrNull(5)?.takeIf { it.isNotBlank() }
        val days = content.removePrefix("高级账号 ").removeSuffix("天").toIntOrNull() ?: 0
        val redTime = code?.let { redeemedMap[it] }
        val startMillis = redTime?.let { t ->
            try {
                fmt.parse(t)?.time ?: fmtMin.parse(t)?.time
            } catch (e: Exception) {
                null
            }
        }
        val endMillis = startMillis?.plus(days * 86400000L)
        OrderInfo(time, content, amount, code, redTime != null, startMillis ?: 0L, endMillis ?: 0L)
    }.sortedByDescending { it.startMillis }
    val active = myOrders.filter { !it.redeemed || it.expireMillis > now }
    val expired = myOrders.filter { it.redeemed && it.expireMillis <= now }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("我的订单", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = MainText) },
        text = {
            Column(
                modifier = Modifier
                    .heightIn(max = 360.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                if (myOrders.isEmpty()) {
                    Text("暂无订单", fontSize = 14.sp, color = SubText)
                }
                if (active.isNotEmpty()) {
                    Text("生效中（${active.size}）", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = Color(0xFF1E9E6A))
                    Spacer(Modifier.height(8.dp))
                    active.forEach { o -> OrderCard(o, false, clipboard, copiedKey) { copiedKey = it } }
                    Spacer(Modifier.height(14.dp))
                }
                if (expired.isNotEmpty()) {
                    Text("已失效（${expired.size}）", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = SubText)
                    Spacer(Modifier.height(8.dp))
                    expired.forEach { o -> OrderCard(o, true, clipboard, copiedKey) { copiedKey = it } }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) { Text("关闭", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = AccentColor) }
        }
    )
}

@Composable
fun OrderCard(o: OrderInfo, expired: Boolean, clipboard: androidx.compose.ui.text.ClipboardManager, copiedKey: String, onCopied: (String) -> Unit) {
    val fmt = java.text.SimpleDateFormat("yyyy-MM-dd HH:mm", java.util.Locale.CHINA)
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(CardColor, RoundedCornerShape(14.dp))
            .padding(horizontal = 16.dp, vertical = 14.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("内容：${o.content}", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = if (expired) SubText else MainText, modifier = Modifier.weight(1f))
            Text(
                if (expired) "已失效" else "生效中",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = if (expired) SubText else Color(0xFF1E9E6A),
                modifier = Modifier
                    .background(if (expired) Color(0xFFEEF1F6) else Color(0xFFE3F4EC), RoundedCornerShape(999.dp))
                    .padding(horizontal = 8.dp, vertical = 2.dp)
            )
        }
        Spacer(Modifier.height(3.dp))
        Text("支付：${o.amount}", fontSize = 12.sp, color = SubText)
        if (o.code != null) {
            Spacer(Modifier.height(3.dp))
            Text(
                "兑换码：${o.code}（点击复制）",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = if (expired) SubText else Color(0xFF3B5BDB),
                modifier = Modifier.tap {
                    clipboard.setText(AnnotatedString(o.code))
                    onCopied(o.code)
                }
            )
        }
        Spacer(Modifier.height(3.dp))
        Text("生效时间：${if (o.redeemed) fmt.format(java.util.Date(o.startMillis)) else "00-00-00-00"}", fontSize = 12.sp, color = SubText)
        Spacer(Modifier.height(3.dp))
        Text("过期时间：${if (o.redeemed) fmt.format(java.util.Date(o.expireMillis)) else "00-00-00-00"}", fontSize = 12.sp, color = SubText)
        if (o.code != null && copiedKey == o.code) {
            Spacer(Modifier.height(3.dp))
            Text("已复制到剪贴板", fontSize = 12.sp, color = Color(0xFF1E9E6A))
        }
    }
}

@Composable
fun LoadingScreen(onDone: () -> Unit) {
    LaunchedEffect(Unit) {
        delay(1800)
        onDone()
    }
    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            CircularProgressIndicator(color = AccentColor)
            Spacer(Modifier.height(16.dp))
            Text("加载中…", fontSize = 14.sp, color = SubText)
        }
    }
}

@Composable
fun HomeScreen(
    currentUser: String,
    showPremiumPopup: Boolean,
    onDismissPremiumPopup: () -> Unit,
    onPremium: () -> Unit,
    onLogout: () -> Unit,
    onBuy: () -> Unit
) {
    var menuOpen by remember { mutableStateOf(false) }
    var showAccountInfo by remember { mutableStateOf(false) }
    var showOrdersDialog by remember { mutableStateOf(false) }
    var showLogoutConfirm by remember { mutableStateOf(false) }
    var showHashTool by remember { mutableStateOf(false) }
    val homeContext = LocalContext.current
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFF2F0EB))
            .verticalScroll(rememberScrollState())
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(44.dp)
                    .background(Color(0xFF1C1C1E), RoundedCornerShape(12.dp)),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Filled.Build, contentDescription = null, tint = Color.White, modifier = Modifier.size(22.dp))
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text("HAirPLNmo", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = MainText)
                Spacer(Modifier.height(2.dp))
                Text("本地工具箱", fontSize = 12.sp, color = SubText)
            }
            Box(
                modifier = Modifier
                    .background(if (isPremium(homeContext)) Color(0xFFFFF3CD) else Color(0xFFC9EEDC), RoundedCornerShape(999.dp))
                    .padding(horizontal = 12.dp, vertical = 5.dp)
            ) {
                Text(
                    if (isPremium(homeContext)) "高级" else "免费版",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (isPremium(homeContext)) Color(0xFFD4A017) else Color(0xFF1E9E6A)
                )
            }
            Spacer(Modifier.width(10.dp))
            Box {
                Icon(
                    Icons.Filled.MoreVert,
                    contentDescription = null,
                    tint = MainText,
                    modifier = Modifier.clickable { menuOpen = true }
                )
                DropdownMenu(
                    expanded = menuOpen,
                    onDismissRequest = { menuOpen = false },
                    shape = RoundedCornerShape(16.dp)
                ) {
                    DropdownMenuItem(
                        text = { Text("1. 账号信息", fontSize = 15.sp, color = MainText) },
                        onClick = {
                            menuOpen = false
                            showAccountInfo = true
                        }
                    )
                    DropdownMenuItem(
                        text = { Text("2. 高级账号", fontSize = 15.sp, color = MainText) },
                        onClick = {
                            menuOpen = false
                            onPremium()
                        }
                    )
                    DropdownMenuItem(
                        text = { Text("3. 订单", fontSize = 15.sp, color = MainText) },
                        onClick = {
                            menuOpen = false
                            showOrdersDialog = true
                        }
                    )
                    DropdownMenuItem(
                        text = { Text("4. 退出登录", fontSize = 15.sp, color = Color(0xFFD0453E)) },
                        onClick = {
                            menuOpen = false
                            showLogoutConfirm = true
                        }
                    )
                }
            }
        }
        Column(Modifier.padding(horizontal = 20.dp)) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color.White, RoundedCornerShape(20.dp))
                    .padding(20.dp)
            ) {
                Text("欢迎使用", fontSize = 13.sp, color = SubText)
                Spacer(Modifier.height(6.dp))
                Text("HAirPLNmo 免费版", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = MainText)
                Spacer(Modifier.height(8.dp))
                Text(
                    "常用工具正在陆续恢复中，敬请期待更多功能。",
                    fontSize = 14.sp,
                    color = Color(0xFF5A5F6B),
                    lineHeight = 22.sp
                )
            }
            Spacer(Modifier.height(24.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("工具", fontSize = 17.sp, fontWeight = FontWeight.Bold, color = MainText, modifier = Modifier.weight(1f))
                Text("开发中", fontSize = 13.sp, color = SubText)
            }
            Spacer(Modifier.height(14.dp))
            Row(Modifier.fillMaxWidth()) {
                ToolCard("哈希工具", "计算各类哈希值", Icons.Filled.Tag, Modifier.weight(1f), onClick = { showHashTool = true }, badge = "已开发")
                Spacer(Modifier.width(14.dp))
                ToolCard("文件修改器", "查找、替换、定位", Icons.Filled.EditNote, Modifier.weight(1f))
            }
            Spacer(Modifier.height(14.dp))
            Row(Modifier.fillMaxWidth()) {
                ToolCard("打包工具", "极速打包安装包", Icons.Filled.Inventory2, Modifier.weight(1f))
                Spacer(Modifier.width(14.dp))
                ToolCard("APK 分析", "安装包信息解析", Icons.Filled.Brush, Modifier.weight(1f))
            }
            Spacer(Modifier.height(14.dp))
            Row(Modifier.fillMaxWidth()) {
                ToolCard("加密工具", "加盐哈希与乱码", Icons.Filled.VerifiedUser, Modifier.weight(1f))
                Spacer(Modifier.width(14.dp))
                ToolCard("更多工具", "陆续上架中", Icons.Filled.Apps, Modifier.weight(1f))
            }
            Spacer(Modifier.height(28.dp))
            Text(
                "HAirPLNmo · 免费版",
                fontSize = 12.sp,
                color = Color(0xFFB9B4AA),
                modifier = Modifier.fillMaxWidth(),
                textAlign = TextAlign.Center
            )
            Spacer(Modifier.height(20.dp))
        }
    }
    if (showPremiumPopup) {
        PremiumPopup(onDismiss = onDismissPremiumPopup, onBuy = onBuy, currentUser = currentUser)
    }
    if (showAccountInfo) {
        val context = LocalContext.current
        AlertDialog(
            onDismissRequest = { showAccountInfo = false },
            title = { Text("账号信息", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = MainText) },
            text = {
                Column {
                    val premium = isPremium(context)
                    Text(
                        "账号：$currentUser" + if (premium) "-高级" else "",
                        fontSize = 15.sp,
                        fontWeight = if (premium) FontWeight.Bold else FontWeight.Normal,
                        color = if (premium) Color(0xFFD4A017) else MainText
                    )
                    Spacer(Modifier.height(6.dp))
                    val nick = getLoggedNick(context)
                    Text("昵称：${nick.ifBlank { "未设置" }}", fontSize = 15.sp, color = MainText)
                    if (premium) {
                        Spacer(Modifier.height(6.dp))
                        var now by remember { mutableStateOf(System.currentTimeMillis()) }
                        LaunchedEffect(Unit) {
                            while (true) {
                                delay(1000)
                                now = System.currentTimeMillis()
                            }
                        }
                        val remain = getPremiumExpire(context) - now
                        if (remain > 0) {
                            val d = remain / 86400000
                            val h = remain % 86400000 / 3600000
                            val m = remain % 3600000 / 60000
                            val s = remain % 60000 / 1000
                            Text("高级账号时间：${d}天${h}小时${m}分${s}秒", fontSize = 14.sp, color = Color(0xFFD4A017))
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showAccountInfo = false }) { Text("确定", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = AccentColor) }
            }
        )
    }
    if (showLogoutConfirm) {
        AlertDialog(
            onDismissRequest = { showLogoutConfirm = false },
            title = { Text("退出登录", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = MainText) },
            text = { Text("确定退出登录吗？", fontSize = 14.sp, color = SubText) },
            confirmButton = {
                TextButton(onClick = {
                    showLogoutConfirm = false
                    onLogout()
                }) { Text("确定", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = Color(0xFFD0453E)) }
            },
            dismissButton = {
                TextButton(onClick = { showLogoutConfirm = false }) { Text("取消", fontSize = 15.sp, color = SubText) }
            }
        )
    }
    if (showOrdersDialog) {
        OrdersDialog(currentUser = currentUser, onDismiss = { showOrdersDialog = false })
    }
    if (showHashTool) {
        HashToolDialog(onClose = { showHashTool = false })
    }
}

@Composable
fun PremiumPopup(onDismiss: () -> Unit, onBuy: () -> Unit, currentUser: String) {
    val context = LocalContext.current
    var key by remember { mutableStateOf("") }
    var msg by remember { mutableStateOf("") }
    var msgColor by remember { mutableStateOf(AccentColor) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("高级账号", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = MainText) },
        text = {
            Column {
                Text("请输入高级账号兑换码", fontSize = 14.sp, color = SubText)
                Spacer(Modifier.height(10.dp))
                FloatField(
                    value = key,
                    onValueChange = {
                        key = it
                        msg = ""
                    },
                    label = "输入兑换码",
                    modifier = Modifier.fillMaxWidth()
                )
                if (msg.isNotEmpty()) {
                    Spacer(Modifier.height(10.dp))
                    Text(msg, fontSize = 13.sp, color = msgColor, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
                }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                when {
                    key.isBlank() -> {
                        msg = "请输入兑换码"
                        msgColor = AccentColor
                    }
                    else -> {
                        val result = redeemCode(context, key)
                        if (result == "ok") {
                            msg = "兑换成功，高级账号已激活"
                            msgColor = Color(0xFF1E9E6A)
                        } else {
                            msg = result
                            msgColor = Color(0xFFD0453E)
                        }
                    }
                }
            }) { Text("确定", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = AccentColor) }
        },
        dismissButton = {
            TextButton(onClick = onBuy) { Text("购买兑换码", fontSize = 14.sp, color = SubText) }
        }
    )
}

@Composable
fun ToolCard(title: String, sub: String, icon: ImageVector, modifier: Modifier = Modifier, onClick: () -> Unit = {}, badge: String = "敬请期待") {
    Column(
        modifier = modifier
            .background(Color.White, RoundedCornerShape(18.dp))
            .tap(onClick)
            .padding(16.dp)
    ) {
        Box(
            modifier = Modifier
                .size(48.dp)
                .background(Color(0xFFF0EEE8), RoundedCornerShape(14.dp)),
            contentAlignment = Alignment.Center
        ) {
            Icon(icon, contentDescription = null, tint = Color(0xFF3A3F4A), modifier = Modifier.size(24.dp))
        }
        Spacer(Modifier.height(12.dp))
        Text(title, fontSize = 16.sp, fontWeight = FontWeight.Bold, color = MainText)
        Spacer(Modifier.height(3.dp))
        Text(sub, fontSize = 12.sp, color = SubText)
        Spacer(Modifier.height(10.dp))
        Box(
            modifier = Modifier
                .background(Color(0xFFEFEDE8), RoundedCornerShape(999.dp))
                .padding(horizontal = 10.dp, vertical = 4.dp)
        ) {
            Text(badge, fontSize = 11.sp, color = Color(0xFF8A8A85))
        }
    }
}

fun hashHex(input: String, algo: String): String =
    MessageDigest.getInstance(algo).digest(input.toByteArray()).joinToString("") { "%02x".format(it) }

@Composable
fun ToolDialog(title: String, onClose: () -> Unit, content: @Composable ColumnScope.() -> Unit) {
    Dialog(onDismissRequest = onClose) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(BgColor, RoundedCornerShape(20.dp))
                .padding(16.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    Icons.Filled.Close,
                    contentDescription = "关闭",
                    tint = MainText,
                    modifier = Modifier
                        .size(26.dp)
                        .tap(onClose)
                )
                Spacer(Modifier.width(10.dp))
                Text(title, fontSize = 18.sp, fontWeight = FontWeight.Bold, color = MainText)
            }
            Spacer(Modifier.height(14.dp))
            content()
        }
    }
}

@Composable
fun ToolMenuItem(index: String, title: String, sub: String, onClick: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(CardColor, RoundedCornerShape(14.dp))
            .tap(onClick)
            .padding(horizontal = 16.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text("$index. $title", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = MainText)
            Spacer(Modifier.height(2.dp))
            Text(sub, fontSize = 12.sp, color = SubText)
        }
        Icon(Icons.Filled.ChevronRight, contentDescription = null, tint = SubText)
    }
    Spacer(Modifier.height(8.dp))
}

@Composable
fun HashToolDialog(onClose: () -> Unit) {
    var page by remember { mutableStateOf(0) }
    ToolDialog(title = "哈希工具", onClose = onClose) {
        ToolMenuItem("1", "哈希值计算", "计算文本的 MD5、SHA 系列哈希值") { page = 1 }
        ToolMenuItem("2", "哈希函数", "了解各哈希算法的特点与用途") { page = 2 }
        ToolMenuItem("3", "哈希校验", "对比哈希值，验证内容是否一致") { page = 3 }
    }
    if (page == 1) {
        HashCalcPage(onClose = { page = 0 })
    }
    if (page == 2) {
        HashFuncPage(onClose = { page = 0 })
    }
    if (page == 3) {
        HashVerifyPage(onClose = { page = 0 })
    }
}

@Composable
fun HashCalcPage(onClose: () -> Unit) {
    val clipboard = LocalClipboardManager.current
    var input by remember { mutableStateOf("") }
    var copied by remember { mutableStateOf("") }
    ToolDialog(title = "哈希值计算", onClose = onClose) {
        FloatField(
            value = input,
            onValueChange = {
                input = it
                copied = ""
            },
            label = "输入文本",
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(12.dp))
        if (copied.isNotEmpty()) {
            Text(copied, fontSize = 12.sp, color = Color(0xFF1E9E6A))
            Spacer(Modifier.height(8.dp))
        }
        Text("点击结果可复制", fontSize = 12.sp, color = SubText)
        Spacer(Modifier.height(8.dp))
        listOf("MD5", "SHA-1", "SHA-256", "SHA-512").forEach { algo ->
            val hex = hashHex(input, algo)
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(CardColor, RoundedCornerShape(12.dp))
                    .tap {
                        clipboard.setText(AnnotatedString(hex))
                        copied = "已复制$algo 结果"
                    }
                    .padding(horizontal = 14.dp, vertical = 10.dp)
            ) {
                Text(algo, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = MainText)
                Spacer(Modifier.height(3.dp))
                Text(hex, fontSize = 12.sp, color = SubText)
            }
            Spacer(Modifier.height(8.dp))
        }
    }
}

@Composable
fun HashFuncPage(onClose: () -> Unit) {
    ToolDialog(title = "哈希函数", onClose = onClose) {
        Text("哈希函数能把任意内容变成固定长度的「指纹」，内容哪怕只差一个字，结果也完全不同，且无法反推原文。", fontSize = 13.sp, color = SubText)
        Spacer(Modifier.height(12.dp))
        listOf(
            Triple("MD5", "128 位 · 32 位十六进制", "速度最快，但已被破解，只适合普通文件校验，不能用于安全场景。"),
            Triple("SHA-1", "160 位 · 40 位十六进制", "曾被广泛使用，现已被攻破，不建议在新场景使用。"),
            Triple("SHA-256", "256 位 · 64 位十六进制", "目前最常用的安全算法，兼顾速度与安全性。"),
            Triple("SHA-512", "512 位 · 128 位十六进制", "安全性最高，结果最长，适合对安全要求极高的场景。")
        ).forEach { (name, len, desc) ->
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(CardColor, RoundedCornerShape(12.dp))
                    .padding(horizontal = 14.dp, vertical = 10.dp)
            ) {
                Text(name, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = MainText)
                Spacer(Modifier.height(3.dp))
                Text(len, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color(0xFF3B5BDB))
                Spacer(Modifier.height(3.dp))
                Text(desc, fontSize = 12.sp, color = SubText)
            }
            Spacer(Modifier.height(8.dp))
        }
    }
}

@Composable
fun HashVerifyPage(onClose: () -> Unit) {
    var text by remember { mutableStateOf("") }
    var target by remember { mutableStateOf("") }
    val t = target.trim().lowercase()
    val algos = listOf("MD5", "SHA-1", "SHA-256", "SHA-512")
    val matches = if (t.isEmpty()) emptyList() else algos.filter { hashHex(text, it) == t }
    ToolDialog(title = "哈希校验", onClose = onClose) {
        FloatField(
            value = text,
            onValueChange = { text = it },
            label = "原文内容",
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(10.dp))
        FloatField(
            value = target,
            onValueChange = { target = it },
            label = "待校验的哈希值",
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(12.dp))
        if (t.isNotEmpty()) {
            if (matches.isNotEmpty()) {
                Text("校验通过：${matches.joinToString("、")}", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Color(0xFF1E9E6A))
            } else {
                Text("校验不通过：内容与该哈希值不一致", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Color(0xFFD0453E))
            }
            Spacer(Modifier.height(10.dp))
        }
        Text("原文的各算法哈希值（点击复制）", fontSize = 12.sp, color = SubText)
        Spacer(Modifier.height(8.dp))
        val clipboard = LocalClipboardManager.current
        var copied by remember { mutableStateOf("") }
        if (copied.isNotEmpty()) {
            Text(copied, fontSize = 12.sp, color = Color(0xFF1E9E6A))
            Spacer(Modifier.height(8.dp))
        }
        algos.forEach { algo ->
            val hex = hashHex(text, algo)
            val ok = t.isNotEmpty() && hex == t
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(CardColor, RoundedCornerShape(12.dp))
                    .tap {
                        clipboard.setText(AnnotatedString(hex))
                        copied = "已复制$algo 结果"
                    }
                    .padding(horizontal = 14.dp, vertical = 10.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(algo, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = MainText, modifier = Modifier.weight(1f))
                    if (ok) {
                        Text("✓ 匹配", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color(0xFF1E9E6A))
                    }
                }
                Spacer(Modifier.height(3.dp))
                Text(hex, fontSize = 12.sp, color = SubText)
            }
            Spacer(Modifier.height(8.dp))
        }
    }
}
