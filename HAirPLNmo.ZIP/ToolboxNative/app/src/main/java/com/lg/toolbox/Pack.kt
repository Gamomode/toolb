package com.lg.toolbox

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Factory
import androidx.compose.material.icons.filled.Image
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec

object Pack {
    private val PK_RE = Regex("^[a-z][a-z0-9_]*(\\.[a-z][a-z0-9_]*)+$")
    private val VER_RE = Regex("^[0-9][0-9A-Za-z.\\-]*$")

    fun pkgOk(p: String) = PK_RE.matches(p)
    fun verOk(v: String) = VER_RE.matches(v)

    fun escT(s: String): String =
        s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")

    fun titleOf(src: String): String {
        val m = Regex("<title[^>]*>([^<]*)</title>", RegexOption.IGNORE_CASE).find(src)
        val t = m?.groupValues?.get(1)?.trim() ?: ""
        return if (t.length > 24) t.substring(0, 24) else t
    }

    fun genPw(): String {
        val cs = "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghjkmnpqrstuvwxyz23456789"
        val a = ByteArray(12)
        SecureRandom().nextBytes(a)
        val sb = StringBuilder()
        for (b in a) sb.append(cs[(b.toInt() and 0xFF) % cs.length])
        return sb.toString()
    }

    fun ensureFullHtml(src: String, label: String): String {
        val s = src
        if (Regex("<html[\\s>]", RegexOption.IGNORE_CASE).containsMatchIn(s)) return s
        return "<!DOCTYPE html><html><head><meta charset=\"utf-8\"><meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">" +
            "<title>" + escT(label.ifBlank { "极速应用" }) + "</title></head><body>" + s + "</body></html>"
    }

    private fun injectIntoHead(html: String, snip: String): String {
        val headRe = Regex("<head[^>]*>", RegexOption.IGNORE_CASE)
        val m = headRe.find(html)
        if (m != null) return html.replaceFirst(m.value, m.value + snip)
        val htmlRe = Regex("<html[^>]*>", RegexOption.IGNORE_CASE)
        val m2 = htmlRe.find(html)
        if (m2 != null) return html.replaceFirst(m2.value, m2.value + "<head>" + snip + "</head>")
        return "<!DOCTYPE html><html><head><meta charset=\"utf-8\">" + snip + "</head><body>" + html + "</body></html>"
    }

    fun injectClearStorage(html: String): String =
        injectIntoHead(html, "<script>try{localStorage.clear();sessionStorage.clear();}catch(e){}</script>")

    fun injectNoCopy(html: String): String {
        val snip = "<style id=\"nocopy-style\">*{-webkit-touch-callout:none!important;-webkit-user-select:none!important;user-select:none!important;-webkit-user-drag:none!important}input,textarea{-webkit-user-select:text!important;user-select:text!important}</style>" +
            "<script>[\"contextmenu\",\"copy\",\"cut\",\"selectstart\",\"dragstart\"].forEach(function(e){document.addEventListener(e,function(ev){ev.preventDefault();},true);});</script>"
        return injectIntoHead(html, snip)
    }

    fun injectScreenFit(html: String, mode: Int): String {
        val js = """(function(){var m=${mode};function isDesk(){var q=document.querySelector('meta[name=viewport]');var c=q?(q.getAttribute('content')||''):'';return !/device-width/i.test(c)}function start(){if(!document.body){setTimeout(start,30);return}if(isDesk()!==!!m)return;var wrap=document.createElement('div');while(document.body.firstChild)wrap.appendChild(document.body.firstChild);document.body.appendChild(wrap);document.documentElement.style.cssText='margin:0;overflow:hidden;height:100%';document.body.style.cssText='margin:0;overflow:hidden;position:relative';wrap.style.cssText='position:absolute;left:0;top:0;transform-origin:0 0;overflow-y:auto;overflow-x:hidden;-webkit-overflow-scrolling:touch';function apply(){var W=innerWidth,H=innerHeight;if(m===0){wrap.style.width=H+'px';wrap.style.height=W+'px';wrap.style.transform='translateX('+W+'px) rotate(90deg)'}else{wrap.style.width=W+'px';wrap.style.height=H+'px';wrap.style.transform='translateY('+H+'px) rotate(-90deg)'}}apply();addEventListener('resize',apply)}if(document.readyState==='loading'){document.addEventListener('DOMContentLoaded',start)}else{start()}})();"""
        val tag = "<script>" + js + "</script>"
        val bodyRe = Regex("</body>", RegexOption.IGNORE_CASE)
        val m = bodyRe.find(html)
        return if (m != null) html.replaceFirst(m.value, tag + "</body>") else html + tag
    }

    fun shellScramble(html: String, title: String): String {
        val payload = android.util.Base64.encodeToString(html.toByteArray(Charsets.UTF_8), android.util.Base64.NO_WRAP)
        return "<!DOCTYPE html><html><head><meta charset=\"utf-8\"><meta name=\"viewport\" content=\"width=device-width, initial-scale=1\"><title>" +
            escT(title) + "</title></head><body><script>document.open();document.write(decodeURIComponent(escape(atob(\"" +
            payload + "\"))));document.close();</script></body></html>"
    }

    fun encryptPayload(html: String, pw: String): String {
        val salt = ByteArray(16)
        val iv = ByteArray(12)
        SecureRandom().nextBytes(salt)
        SecureRandom().nextBytes(iv)
        val kf = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
        val key = kf.generateSecret(PBEKeySpec(pw.toCharArray(), salt, 150000, 256)).encoded
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.ENCRYPT_MODE, SecretKeySpec(key, "AES"), GCMParameterSpec(128, iv))
        val ct = c.doFinal(html.toByteArray(Charsets.UTF_8))
        val all = ByteArray(28 + ct.size)
        System.arraycopy(salt, 0, all, 0, 16)
        System.arraycopy(iv, 0, all, 16, 12)
        System.arraycopy(ct, 0, all, 28, ct.size)
        return android.util.Base64.encodeToString(all, android.util.Base64.NO_WRAP)
    }

    fun shellLock(html: String, pw: String, title: String): String {
        val payload = encryptPayload(html, pw)
        val js = "var D=\"$payload\";" +
            "function A(s){return Uint8Array.from(atob(s),function(c){return c.charCodeAt(0)})}" +
            "async function U(){var m=document.getElementById(\"m\");" +
            "try{var raw=A(D),salt=raw.slice(0,16),iv=raw.slice(16,28);" +
            "var km=await crypto.subtle.importKey(\"raw\",new TextEncoder().encode(document.getElementById(\"pw\").value),{name:\"PBKDF2\"},false,[\"deriveKey\"]);" +
            "var k=await crypto.subtle.deriveKey({name:\"PBKDF2\",salt:salt,iterations:150000,hash:\"SHA-256\"},km,{name:\"AES-GCM\",length:256},false,[\"decrypt\"]);" +
            "var pt=await crypto.subtle.decrypt({name:\"AES-GCM\",iv:iv},k,raw.slice(28));" +
            "document.open();document.write(new TextDecoder().decode(pt));document.close();}" +
            "catch(e){m.textContent=\"密码不对，再试试\"}}" +
            "document.getElementById(\"ok\").onclick=U;" +
            "document.getElementById(\"pw\").addEventListener(\"keydown\",function(e){if(e.key===\"Enter\")U()});"
        return "<!DOCTYPE html><html><head><meta charset=\"utf-8\"><meta name=\"viewport\" content=\"width=device-width, initial-scale=1\"><title>" +
            escT(title) + "</title>" +
            "<style>body{margin:0;min-height:100vh;display:flex;align-items:center;justify-content:center;background:#0f172a;color:#fff;font-family:sans-serif}" +
            ".card{text-align:center}input{font-size:17px;padding:12px;border-radius:8px;border:0}" +
            "button{font-size:17px;padding:12px 24px;border:0;border-radius:8px;background:#22d3ee;color:#06283d;font-weight:bold;margin-top:10px}" +
            "p{color:#94a3b8}h1{margin:0}</style></head>" +
            "<body><div class=\"card\" id=\"L\"><h1>&#128274;</h1><p>输入密码打开</p>" +
            "<input id=\"pw\" type=\"password\"><br><button id=\"ok\">打开</button><p id=\"m\"></p></div>" +
            "<script>" + js + "</script></body></html>"
    }

    fun saveApk(ctx: Context, name: String, bytes: ByteArray): Pair<String, Uri?> {
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val values = ContentValues().apply {
                    put(MediaStore.Downloads.DISPLAY_NAME, name)
                    put(MediaStore.Downloads.MIME_TYPE, "application/vnd.android.package-archive")
                }
                val uri = ctx.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                    ?: return "保存失败，请重试" to null
                ctx.contentResolver.openOutputStream(uri)?.use { it.write(bytes) }
                "已保存到「下载」：$name" to uri
            } else {
                val dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
                dir.mkdirs()
                val f = java.io.File(dir, name)
                f.writeBytes(bytes)
                "已保存到「下载」：$name" to Uri.fromFile(f)
            }
        } catch (e: Exception) {
            "保存失败：${e.message}" to null
        }
    }

    fun openInstall(ctx: Context, uri: Uri): String {
        return try {
            val i = Intent(Intent.ACTION_VIEW)
            i.setDataAndType(uri, "application/vnd.android.package-archive")
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
            ctx.startActivity(i)
            "请在弹出的安装器中确认安装"
        } catch (e: Exception) {
            "打不开安装器，请到「下载」文件夹手动安装"
        }
    }
}

@Composable
fun PackCheckRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit, th: ThemeSpec) {
    Row(
        Modifier
            .fillMaxWidth()
            .tap { onChange(!checked) }
            .padding(vertical = 2.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, fontSize = 13.sp, color = th.ink)
        Spacer(Modifier.weight(1f))
        Switch(checked = checked, onCheckedChange = { onChange(it) })
    }
}

@Composable
fun PackChips(options: List<Pair<String, String>>, sel: String, onSel: (String) -> Unit, th: ThemeSpec) {
    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        options.forEach { (v, label) ->
            val isSel = v == sel
            Box(
                Modifier
                    .background(if (isSel) th.accent else th.accentSoft, RoundedCornerShape(999.dp))
                    .tap { onSel(v) }
                    .padding(horizontal = 12.dp, vertical = 6.dp)
            ) {
                Text(label, fontSize = 12.sp, color = if (isSel) Color.White else th.accent)
            }
        }
    }
}

@Composable
fun PackResultPanel(th: ThemeSpec, msg: String, uri: Uri?, notify: (String) -> Unit) {
    Spacer(Modifier.height(14.dp))
    Box(
        Modifier
            .fillMaxWidth()
            .background(th.panel, RoundedCornerShape(20.dp))
            .border(1.dp, th.line, RoundedCornerShape(20.dp))
            .padding(14.dp)
    ) {
        Column {
            Text("生成结果", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = th.ink)
            Spacer(Modifier.height(8.dp))
            Text(msg, fontSize = 13.sp, color = th.ink, lineHeight = 20.sp)
            if (uri != null) {
                Spacer(Modifier.height(10.dp))
                val ctx = LocalContext.current
                Button(
                    onClick = { notify(Pack.openInstall(ctx, uri)) },
                    colors = ButtonDefaults.buttonColors(containerColor = th.accent),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("打开安装", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
fun FastpackScreen(th: ThemeSpec, notify: (String) -> Unit) {
    var html by remember { mutableStateOf("") }
    var name by remember { mutableStateOf("") }
    var fullscreen by remember { mutableStateOf(true) }
    var saveData by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }
    var resultMsg by remember { mutableStateOf("") }
    var savedUri by remember { mutableStateOf<Uri?>(null) }
    val ctx = LocalContext.current

    fun generate() {
        val src = html
        if (src.isBlank()) {
            notify("先贴上网页代码")
            return
        }
        busy = true
        try {
            ApkBuilder.init(ctx)
            val label = name.trim().ifBlank { Pack.titleOf(src).ifBlank { "极速应用" } }
            var out = Pack.ensureFullHtml(src, label)
            if (!saveData) out = Pack.injectClearStorage(out)
            val bytes = ApkBuilder.generateApk(
                out.toByteArray(Charsets.UTF_8),
                ApkOptions(label = label, pkg = "com.armorlab.fast", fullscreen = fullscreen)
            )
            val (msg, uri) = Pack.saveApk(ctx, label + ".apk", bytes)
            savedUri = uri
            resultMsg = msg + "（" + "%.1f".format(bytes.size / 1024f) + " KB）V1 签名，全机型可装。极速版不加锁、不加防护。"
            Usage.mark("fastpack")
            notify(msg)
        } catch (e: Exception) {
            notify("生成失败：${e.message}")
        }
        busy = false
    }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        Box(
            Modifier
                .fillMaxWidth()
                .background(th.accentSoft, RoundedCornerShape(20.dp))
                .padding(14.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.Bolt, null, tint = th.accent, modifier = Modifier.size(20.dp))
                Spacer(Modifier.width(8.dp))
                Text(
                    "不折腾，贴上网页点一下就出包。默认全屏显示，不加锁、不加防护，追求最快最简。",
                    fontSize = 13.sp,
                    color = th.ink,
                    lineHeight = 21.sp
                )
            }
        }
        Spacer(Modifier.height(14.dp))
        Box(
            Modifier
                .fillMaxWidth()
                .background(th.panel, RoundedCornerShape(20.dp))
                .border(1.dp, th.line, RoundedCornerShape(20.dp))
                .padding(14.dp)
        ) {
            Column {
                Text("网页内容", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = th.ink)
                Spacer(Modifier.height(10.dp))
                OutlinedTextField(shape = FieldShape, colors = fieldColors(th), 
                    value = html,
                    onValueChange = { html = it },
                    label = { Text("粘贴完整 HTML，或只贴 body 内容") },
                    modifier = Modifier.fillMaxWidth(),
                    minLines = 5,
                    maxLines = 10
                )
                Spacer(Modifier.height(10.dp))
                OutlinedTextField(shape = FieldShape, colors = fieldColors(th), 
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("应用名称（留空取网页标题）") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(6.dp))
                PackCheckRow("全屏显示", fullscreen, { fullscreen = it }, th)
                PackCheckRow("保存数据（关闭则每次清空存储）", saveData, { saveData = it }, th)
                Spacer(Modifier.height(14.dp))
                Button(
                    onClick = { generate() },
                    enabled = !busy,
                    colors = ButtonDefaults.buttonColors(containerColor = th.accent),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.Bolt, null, tint = Color.White, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text(if (busy) "极速生成中…" else "一键极速生成", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
        if (resultMsg.isNotEmpty()) {
            PackResultPanel(th, resultMsg, savedUri, notify)
        }
        Spacer(Modifier.height(30.dp))
    }
}

@Composable
fun WorkshopScreen(th: ThemeSpec, notify: (String) -> Unit) {
    var html by remember { mutableStateOf("") }
    var label by remember { mutableStateOf("") }
    var pkg by remember { mutableStateOf("") }
    var verName by remember { mutableStateOf("") }
    var verCode by remember { mutableStateOf("") }
    var iconBytes by remember { mutableStateOf<ByteArray?>(null) }
    var iconName by remember { mutableStateOf("") }
    var protect by remember { mutableStateOf("0") }
    var lockPw by remember { mutableStateOf("") }
    var screenMode by remember { mutableStateOf("-1") }
    var fullscreen by remember { mutableStateOf(false) }
    var noCopy by remember { mutableStateOf(false) }
    var saveData by remember { mutableStateOf(false) }
    var permRead by remember { mutableStateOf(false) }
    var permWrite by remember { mutableStateOf(false) }
    var permManage by remember { mutableStateOf(false) }
    var deep by remember { mutableStateOf("normal") }
    var busy by remember { mutableStateOf(false) }
    var resultMsg by remember { mutableStateOf("") }
    var savedUri by remember { mutableStateOf<Uri?>(null) }
    val ctx = LocalContext.current

    val iconPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            try {
                val b = ctx.contentResolver.openInputStream(uri)?.use { it.readBytes() }
                if (b != null) {
                    iconBytes = b
                    iconName = "已选图标（" + "%.1f".format(b.size / 1024f) + " KB）"
                }
            } catch (e: Exception) {
                notify("读取图标失败：${e.message}")
            }
        }
    }

    fun generate() {
        val src = html
        if (src.isBlank()) {
            notify("先贴上网页代码")
            return
        }
        val thePkg = pkg.trim().ifBlank { ApkBuilder.DEFAULT_PKG }
        if (!Pack.pkgOk(thePkg)) {
            notify("包名格式不对：需要至少两段，只含小写字母、数字、下划线，例如 com.me.note")
            return
        }
        val theVer = verName.trim()
        if (theVer.isNotEmpty() && !Pack.verOk(theVer)) {
            notify("版本号格式不对，例如 1.0 或 2.3.1")
            return
        }
        val vc = verCode.trim()
        val verCodeInt = if (vc.isEmpty()) 1 else vc.toIntOrNull() ?: run {
            notify("内部版本号要填数字")
            return
        }
        busy = true
        try {
            ApkBuilder.init(ctx)
            val theLabel = label.trim().ifBlank { Pack.titleOf(src).ifBlank { ApkBuilder.DEFAULT_LABEL } }
            var pw = lockPw
            if (protect == "2" && pw.isBlank()) {
                pw = Pack.genPw()
                lockPw = pw
            }
            var out = Pack.ensureFullHtml(src, theLabel)
            val sm = screenMode.toIntOrNull() ?: -1
            if (sm >= 0) out = Pack.injectScreenFit(out, sm)
            if (noCopy) out = Pack.injectNoCopy(out)
            if (!saveData) out = Pack.injectClearStorage(out)
            if (protect == "1") {
                out = Pack.shellScramble(out, theLabel)
            } else if (protect == "2") {
                out = Pack.shellLock(out, pw, theLabel)
            }
            val perms = mutableListOf<String>()
            if (permRead) perms.add("android.permission.READ_EXTERNAL_STORAGE")
            if (permWrite) perms.add("android.permission.WRITE_EXTERNAL_STORAGE")
            if (permManage) perms.add("android.permission.MANAGE_EXTERNAL_STORAGE")
            val bytes = ApkBuilder.generateApk(
                out.toByteArray(Charsets.UTF_8),
                ApkOptions(
                    label = theLabel,
                    pkg = thePkg,
                    versionName = theVer.ifBlank { "1.0" },
                    versionCode = verCodeInt,
                    fullscreen = fullscreen,
                    orientation = sm,
                    icon = iconBytes,
                    permissions = perms,
                    deep = if (deep == "normal") null else deep
                )
            )
            val (msg, uri) = Pack.saveApk(ctx, theLabel + ".apk", bytes)
            savedUri = uri
            resultMsg = msg + "（" + "%.1f".format(bytes.size / 1024f) + " KB）" +
                if (protect == "2") "已上锁，打开应用要输密码：" + pw + "。忘了密码谁也打不开，务必保存好！" +
                    if (saveData) "" else " 未开启保存数据：每次打开都要重新输密码。"
                else "生成完成，V1 签名有效。"
            Usage.mark("workshop")
            notify(msg)
        } catch (e: Exception) {
            notify("生成失败：${e.message}")
        }
        busy = false
    }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        Box(
            Modifier
                .fillMaxWidth()
                .background(th.accentSoft, RoundedCornerShape(20.dp))
                .padding(14.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.Factory, null, tint = th.accent, modifier = Modifier.size(20.dp))
                Spacer(Modifier.width(8.dp))
                Text(
                    "写网页 → 就地打包并签名 → 保存安装。可加锁、转乱码、改包名、选图标。",
                    fontSize = 13.sp,
                    color = th.ink,
                    lineHeight = 21.sp
                )
            }
        }
        Spacer(Modifier.height(14.dp))
        Box(
            Modifier
                .fillMaxWidth()
                .background(th.panel, RoundedCornerShape(20.dp))
                .border(1.dp, th.line, RoundedCornerShape(20.dp))
                .padding(14.dp)
        ) {
            Column {
                Text("网页内容", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = th.ink)
                Spacer(Modifier.height(10.dp))
                OutlinedTextField(shape = FieldShape, colors = fieldColors(th), 
                    value = html,
                    onValueChange = { html = it },
                    label = { Text("粘贴完整 HTML，或只贴 body 内容") },
                    modifier = Modifier.fillMaxWidth(),
                    minLines = 5,
                    maxLines = 10
                )
                Spacer(Modifier.height(12.dp))
                Text("应用信息", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = th.ink)
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(shape = FieldShape, colors = fieldColors(th), 
                    value = label,
                    onValueChange = { label = it },
                    label = { Text("应用名称（留空取网页标题）") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(shape = FieldShape, colors = fieldColors(th), 
                    value = pkg,
                    onValueChange = { pkg = it },
                    label = { Text("包名（留空 com.armorlab.app）") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(8.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(shape = FieldShape, colors = fieldColors(th), 
                        value = verName,
                        onValueChange = { verName = it },
                        label = { Text("版本号") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(shape = FieldShape, colors = fieldColors(th), 
                        value = verCode,
                        onValueChange = { verCode = it },
                        label = { Text("内部版本") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                }
                Spacer(Modifier.height(10.dp))
                Box(
                    Modifier
                        .fillMaxWidth()
                        .background(th.accentSoft, RoundedCornerShape(14.dp))
                        .tap { iconPicker.launch("image/*") }
                        .padding(12.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.Image, null, tint = th.accent, modifier = Modifier.size(20.dp))
                        Spacer(Modifier.width(8.dp))
                        Text(
                            if (iconBytes == null) "选择应用图标（可选，默认内置图标）" else iconName,
                            fontSize = 13.sp,
                            color = th.accent
                        )
                    }
                }
                Spacer(Modifier.height(12.dp))
                Text("源码保护", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = th.ink)
                Spacer(Modifier.height(6.dp))
                PackChips(
                    listOf("0" to "原样", "1" to "转乱码", "2" to "上锁"),
                    protect, { protect = it }, th
                )
                if (protect == "2") {
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(shape = FieldShape, colors = fieldColors(th), 
                        value = lockPw,
                        onValueChange = { lockPw = it },
                        label = { Text("访问密码（留空自动生成）") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
                Spacer(Modifier.height(12.dp))
                Text("屏幕模拟", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = th.ink)
                Spacer(Modifier.height(6.dp))
                PackChips(
                    listOf("-1" to "不限", "0" to "横屏", "1" to "竖屏"),
                    screenMode, { screenMode = it }, th
                )
                Spacer(Modifier.height(12.dp))
                Text("深度代码", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = th.ink)
                Spacer(Modifier.height(6.dp))
                PackChips(
                    listOf("normal" to "原壳", "plain" to "纯净壳", "adv" to "高级壳"),
                    deep, { deep = it }, th
                )
                Spacer(Modifier.height(12.dp))
                Text("权限管理", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = th.ink)
                Spacer(Modifier.height(4.dp))
                PackCheckRow("存储读取", permRead, { permRead = it }, th)
                PackCheckRow("存储写入", permWrite, { permWrite = it }, th)
                PackCheckRow("所有文件", permManage, { permManage = it }, th)
                Spacer(Modifier.height(12.dp))
                PackCheckRow("全屏显示", fullscreen, { fullscreen = it }, th)
                PackCheckRow("禁止复制", noCopy, { noCopy = it }, th)
                PackCheckRow("保存数据（关闭则每次清空存储）", saveData, { saveData = it }, th)
                Spacer(Modifier.height(14.dp))
                Button(
                    onClick = { generate() },
                    enabled = !busy,
                    colors = ButtonDefaults.buttonColors(containerColor = th.accent),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(if (busy) "生成中…" else "生成 APK", fontWeight = FontWeight.Bold)
                }
            }
        }
        if (resultMsg.isNotEmpty()) {
            PackResultPanel(th, resultMsg, savedUri, notify)
        }
        Spacer(Modifier.height(30.dp))
    }
}
