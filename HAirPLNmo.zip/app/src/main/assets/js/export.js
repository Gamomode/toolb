(function () {
  'use strict';

  var AI = window.AI;

  function dirOf(p) {
    var s = String(p || '');
    var i = s.lastIndexOf('/');
    return i <= 0 ? '' : s.slice(0, i);
  }

  function safeName(p) {
    return String(p || 'file').replace(/^\/+/, '').replace(/\.\./g, '').replace(/\\/g, '/');
  }

  function buildOffline(files) {
    var list = Array.isArray(files) ? files : [];
    var report = AI.analyze(list);
    var entries = report.externals.map(function (e) {
      return { from: e.url, to: e.offline };
    });

    var out = list.map(function (f) {
      var content = f.content || '';
      entries.forEach(function (e) {
        content = content.split(e.from).join(e.to);
      });
      return { path: f.path, content: content };
    });

    var root = dirOf(list.length ? list[0].path : '') || '/srv/app';
    var extras = [];

    if (entries.length) {
      var lines = ['离线化资源清单', '生成时间：' + new Date().toLocaleString(), ''];
      entries.forEach(function (e) {
        lines.push(e.from);
        lines.push('  -> ' + e.to);
        lines.push('');
      });
      extras.push({ path: root + '/vendor/下载清单.txt', content: lines.join('\n') });

      var sh = ['#!/usr/bin/env bash', 'set -e', 'cd "$(dirname "$0")"', ''];
      entries.forEach(function (e) {
        sh.push('mkdir -p "' + dirOf(e.to) + '"');
        sh.push('curl -L "' + e.from + '" -o "' + e.to + '"');
        sh.push('');
      });
      sh.push('echo "外链资源已下载完成"');
      extras.push({ path: root + '/vendor/fetch-vendor.sh', content: sh.join('\n') });
    }

    return { files: out, entries: entries, extras: extras, report: report };
  }

  function zipOf(list) {
    var JSZip = window.JSZip;
    if (!JSZip) return Promise.reject(new Error('JSZip 未加载，无法打包'));
    var zip = new JSZip();
    (list || []).forEach(function (f) {
      zip.file(safeName(f.path), f.content == null ? '' : f.content);
    });
    return zip.generateAsync({ type: 'blob', compression: 'DEFLATE', compressionOptions: { level: 6 } });
  }

  function saveBlob(blob, name) {
    var file;
    try {
      file = new File([blob], name, { type: blob.type || 'application/octet-stream' });
    } catch (e) {
      file = null;
    }

    if (file && navigator.canShare && navigator.canShare({ files: [file] }) && navigator.share) {
      return navigator.share({ files: [file], title: name }).then(function () {
        return 'share';
      }).catch(function (err) {
        if (err && err.name === 'AbortError') return 'cancel';
        return download(blob, name);
      });
    }
    return Promise.resolve(download(blob, name));
  }

  function download(blob, name) {
    var url = URL.createObjectURL(blob);
    var a = document.createElement('a');
    a.href = url;
    a.download = name;
    a.rel = 'noopener';
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(function () {
      URL.revokeObjectURL(url);
    }, 5000);
    return 'download';
  }

  window.Exporter = {
    buildOffline: buildOffline,
    zipOf: zipOf,
    saveBlob: saveBlob,
    download: download,
    dirOf: dirOf
  };
})();