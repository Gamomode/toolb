(function () {
  'use strict';

  var KEY = 'ai-reverse-chat.v1';
  var CFG_KEY = 'ai-reverse-model.v1';

  var messages = [];
  var config = { url: '', key: '', model: 'gpt-4o-mini' };
  var listeners = [];
  var busy = false;

  var SYSTEM_PROMPT = [
    '你是前端逆向与离线化改造专家。',
    '回答要具体到代码行，给出可执行的修改方案，不要泛泛而谈。',
    '给代码时用 ``` 包裹，尽量最小改动。'
  ].join('');

  var QUICK = [
    '分析全部文件',
    '找接口地址',
    '找密钥签名',
    '生成离线版',
    '移除动态执行',
    '给请求加离线缓存'
  ];

  function load() {
    try {
      var m = JSON.parse(localStorage.getItem(KEY) || '[]');
      messages = Array.isArray(m) ? m : [];
    } catch (e) {
      messages = [];
    }
    try {
      Object.assign(config, JSON.parse(localStorage.getItem(CFG_KEY) || '{}'));
    } catch (e) {
      /* 忽略损坏的配置 */
    }
  }

  function save() {
    try {
      localStorage.setItem(KEY, JSON.stringify(messages.slice(-40)));
    } catch (e) {
      /* 存储不可用时仅保留内存数据 */
    }
    try {
      localStorage.setItem(CFG_KEY, JSON.stringify(config));
    } catch (e) {
      /* 同上 */
    }
  }

  function emit() {
    listeners.forEach(function (fn) {
      try {
        fn();
      } catch (e) {
        /* 单个订阅者异常不影响其它 */
      }
    });
  }

  function now() {
    var d = new Date();
    var p = function (n) {
      return n < 10 ? '0' + n : '' + n;
    };
    return p(d.getHours()) + ':' + p(d.getMinutes());
  }

  function push(role, text, actions) {
    messages.push({ role: role, text: text, time: now(), actions: actions || [] });
    if (messages.length > 40) messages = messages.slice(-40);
  }

  function findFile(files, path) {
    for (var i = 0; i < files.length; i++) {
      if (files[i].path === path) return files[i];
    }
    return null;
  }

  /* ---------- 本地回答生成 ---------- */

  function overview(files) {
    if (!files.length) return '工作区还没有文件，先在「文件」页新建或导入。';
    var rows = files.map(function (f) {
      return '· ' + f.path + '（' + (f.content || '').length + ' 字节 / ' + (f.content || '').split('\n').length + ' 行）';
    });
    return '工作区共 ' + files.length + ' 个文件：\n' + rows.join('\n');
  }

  function apis(files) {
    var seen = {};
    var out = [];
    var re = /\bhttps?:\/\/[^\s'"`)<>\]]+/g;
    files.forEach(function (f) {
      var m;
      re.lastIndex = 0;
      while ((m = re.exec(f.content || ''))) {
        var u = m[0].replace(/[.,;]+$/, '');
        if (seen[u]) continue;
        seen[u] = 1;
        out.push(u + '  ←  ' + f.path);
      }
    });
    if (!out.length) return '没有发现写死的接口地址。建议在 Network 里跑一遍真实请求，或在 request 封装处下断点看拼接后的完整 URL。';
    return '发现 ' + out.length + ' 个地址：\n```\n' + out.join('\n') + '\n```\n建议把域名提取成常量，离线化时统一改写。';
  }

  function secrets(files) {
    var re = /\b(?:key|secret|token|password|passwd|apiKey|accessKey)\b\s*[:=]\s*["']([^"']{3,})["']/gi;
    var out = [];
    files.forEach(function (f) {
      var m;
      re.lastIndex = 0;
      while ((m = re.exec(f.content || ''))) {
        out.push(f.path + ' → ' + m[0].trim());
        if (out.length > 30) return;
      }
    });
    if (!out.length) return '没有发现明文字段形式的密钥。可能藏在 base64、混淆字符串或运行时下发，重点看 atob / eval 附近。';
    return '发现 ' + out.length + ' 处疑似密钥：\n```\n' + out.join('\n') + '\n```\n逆向签名时按「参数排序 → 拼接 → 加盐 → 摘要」的顺序复现即可。';
  }

  function risks(files) {
    if (!window.AI) return '分析模块未加载。';
    var report = window.AI.analyze(files);
    if (!report.risks.length) return '没有命中常见风险特征，可以先从 sourcemap 和网络请求入手。';
    var rows = report.risks.map(function (r) {
      return '· [' + r.level + '] ' + r.title + ' — ' + r.file + '（' + r.count + ' 处）';
    });
    return '共 ' + report.risks.length + ' 类关键点：\n' + rows.join('\n') + '\n\n要高危优先：eval / new Function 通常就是校验或解密入口。';
  }

  function offline(files) {
    if (!window.Exporter) return '导出模块未加载。';
    var built = window.Exporter.buildOffline(files);
    if (!built.entries.length) return '当前文件没有外链依赖，可直接打包离线运行。需要的话我可以帮你把接口改成读本地缓存。';
    var rows = built.entries.map(function (e) {
      return '· ' + e.from + '\n  → ' + e.to;
    });
    return '已生成 ' + built.entries.length + ' 条外链映射：\n' + rows.join('\n') +
      '\n\n点下面的按钮直接应用到工作区，引用会被改写成相对路径，vendor 目录会自动附带下载脚本。';
  }

  function mockSnippet() {
    return [
      '',
      '// [AI] 离线请求拦截：命中内置数据或本地缓存，不再依赖网络',
      '(function () {',
      '  var rawFetch = window.fetch ? window.fetch.bind(window) : null;',
      '  window.__offlineMock = window.__offlineMock || {',
      '    // "https://api.example.com/v1/report": { ok: true, list: [] }',
      '  };',
      '  window.fetch = function (input, init) {',
      '    var url = typeof input === "string" ? input : (input && input.url) || "";',
      '    var hit = window.__offlineMock[url];',
      '    if (hit) {',
      '      return Promise.resolve(new Response(JSON.stringify(hit), {',
      '        status: 200,',
      '        headers: { "Content-Type": "application/json" }',
      '      }));',
      '    }',
      '    if (!rawFetch) return Promise.reject(new Error("offline"));',
      '    return rawFetch(input, init).catch(function (err) {',
      '      var cached = localStorage.getItem("cache:" + url);',
      '      if (cached) {',
      '        return new Response(cached, {',
      '          status: 200,',
      '          headers: { "Content-Type": "application/json" }',
      '        });',
      '      }',
      '      throw err;',
      '    });',
      '  };',
      '})();',
      ''
    ].join('\n');
  }

  function edit(question, files, activePath) {
    var q = String(question);
    var target = findFile(files, activePath) || files[0];

    if (!target) {
      return {
        text: '工作区还没有文件。先在「文件」页新建一个，或把要逆向的代码贴进来，我再帮你改。',
        actions: []
      };
    }

    var content = target.content || '';
    var next = null;
    var note = '';

    if (/eval|动态执行|function\s*\(/i.test(q)) {
      var hit = 0;
      next = content.replace(/^.*\beval\s*\(.*$/gm, function (line) {
        hit++;
        return '// [AI] 已移除动态执行：' + line.trim();
      });
      if (hit) note = '已注释掉 ' + hit + ' 行 eval 调用，先跑通流程再逐个还原入参。';
    }

    if (next === null && /统计|埋点|analytics|gtag|track/i.test(q)) {
      var hit2 = 0;
      next = content.replace(/^.*(analytics|track\.min\.js|gtag|baidu|cnzz).*$/gmi, function (line) {
        hit2++;
        return '// [AI] 已移除埋点：' + line.trim();
      });
      if (hit2) note = '已移除 ' + hit2 + ' 行埋点/统计引用。';
    }

    if (next === null && /离线|本地化|vendor|外链|cdn|断网/i.test(q) && window.Exporter) {
      var built = window.Exporter.buildOffline(files);
      for (var i = 0; i < built.files.length; i++) {
        if (built.files[i].path === target.path) {
          next = built.files[i].content;
          note = '已把外链改写为本地 vendor 路径，共 ' + built.entries.length + ' 条。';
          break;
        }
      }
    }

    if (next === null && /mock|假数据|本地数据|缓存|拦截/i.test(q)) {
      next = content + '\n' + mockSnippet();
      note = '已在文件末尾插入 fetch 拦截器：先查内置数据，再查 localStorage 缓存。';
    }

    if (next === null || next === content) {
      var lines = content.split('\n');
      var head = lines.slice(0, 12).join('\n');
      return {
        text: '我看了 `' + target.path + '`（' + content.length + ' 字节 / ' + lines.length + ' 行）。\n```\n' + head + (lines.length > 12 ? '\n…' : '') + '\n```\n' +
          '可以这样改，你直接说其中一句我就动手：\n' +
          '· 「把外链改成离线路径」\n' +
          '· 「删掉动态执行」\n' +
          '· 「给请求加离线缓存」\n' +
          '· 「帮我找签名逻辑」',
        actions: []
      };
    }

    return {
      text: note + '\n文件：`' + target.path + '`\n```\n' + next.slice(0, 900) + (next.length > 900 ? '\n…' : '') + '\n```',
      actions: [
        { type: 'apply-file', label: '应用到 ' + target.path, path: target.path, content: next }
      ]
    };
  }

  function localAnswer(question, ctx) {
    var files = (ctx && ctx.files) || [];
    var activePath = (ctx && ctx.activePath) || null;
    var q = String(question || '');

    if (!q.trim()) return { text: '想让我做什么？可以直接说「把 main.js 改成离线版」。', actions: [] };

    if (/修改|改成|改一下|替换|删掉|移除|去掉|加个|插入|生成/.test(q)) {
      return edit(q, files, activePath);
    }
    if (/离线|本地化|断网|vendor/i.test(q) && !/修改|改成/.test(q)) {
      return {
        text: offline(files),
        actions: window.Exporter
          ? [{ type: 'apply-many', label: '应用到工作区', files: window.Exporter.buildOffline(files).files }]
          : []
      };
    }
    if (/接口|api|请求|域名|url/i.test(q)) return { text: apis(files), actions: [] };
    if (/密钥|key|token|签名|secret|加密/i.test(q)) return { text: secrets(files), actions: [] };
    if (/风险|漏洞|可疑|eval/i.test(q)) return { text: risks(files), actions: [] };
    if (/结构|概览|有哪些|列出|列表|文件/i.test(q)) return { text: overview(files), actions: [] };

    return {
      text: '我理解的意图不太明确。我能直接做这些事：\n' +
        '· 「分析全部文件」— 列出结构与体量\n' +
        '· 「找接口地址」— 抽取所有写死的 URL\n' +
        '· 「找密钥签名」— 定位 key / token / 签名函数\n' +
        '· 「把外链改成离线路径」— 改写引用并生成 vendor 清单\n' +
        '· 「给请求加离线缓存」— 插入 fetch 拦截器\n' +
        '· 「删掉动态执行」— 注释 eval / new Function',
      actions: []
    };
  }

  /* ---------- 在线模型（可选） ---------- */

  function contextText(ctx) {
    var files = (ctx && ctx.files) || [];
    var parts = [];
    var budget = 6000;
    files.forEach(function (f) {
      if (budget <= 0) return;
      var body = (f.content || '').slice(0, 2000);
      budget -= body.length;
      parts.push('### ' + f.path + '\n' + body);
    });
    return parts.join('\n\n');
  }

  function remoteAnswer(question, ctx) {
    var url = String(config.url || '').replace(/\/+$/, '');
    if (!url || !config.key) return Promise.reject(new Error('未配置在线模型'));
    var endpoint = /\/chat\/completions$/.test(url) ? url : url + '/chat/completions';
    var body = {
      model: config.model || 'gpt-4o-mini',
      messages: [
        { role: 'system', content: SYSTEM_PROMPT },
        { role: 'user', content: '下面是工作区文件：\n\n' + contextText(ctx) + '\n\n我的问题：' + question }
      ]
    };
    return fetch(endpoint, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: 'Bearer ' + config.key
      },
      body: JSON.stringify(body)
    }).then(function (res) {
      if (!res.ok) throw new Error('HTTP ' + res.status);
      return res.json();
    }).then(function (data) {
      var c = data && data.choices && data.choices[0] && data.choices[0].message;
      if (!c || !c.content) throw new Error('返回为空');
      return { text: c.content, actions: [] };
    });
  }

  /* ---------- 对外接口 ---------- */

  load();

  window.Assistant = {
    quick: QUICK,

    getMessages: function () {
      return messages;
    },

    getConfig: function () {
      return config;
    },

    isBusy: function () {
      return busy;
    },

    setConfig: function (patch) {
      config = Object.assign({}, config, patch || {});
      save();
      emit();
    },

    subscribe: function (fn) {
      listeners.push(fn);
      return function () {
        listeners = listeners.filter(function (x) {
          return x !== fn;
        });
      };
    },

    clear: function () {
      messages = [];
      save();
      emit();
    },

    send: function (text, ctx) {
      var q = String(text || '').trim();
      if (!q || busy) return Promise.resolve();
      busy = true;
      push('user', q, []);
      save();
      emit();

      var finish = function (res) {
        push('ai', res.text, res.actions);
        busy = false;
        save();
        emit();
      };

      var fallback = function (err) {
        var local = localAnswer(q, ctx);
        if (err) local.text = '（在线模型不可用：' + err.message + '，已切换到本地引擎）\n\n' + local.text;
        finish(local);
      };

      if (config.url && config.key) {
        return remoteAnswer(q, ctx).then(finish).catch(fallback);
      }
      return new Promise(function (resolve) {
        setTimeout(function () {
          fallback(null);
          resolve();
        }, 260);
      });
    }
  };
})();