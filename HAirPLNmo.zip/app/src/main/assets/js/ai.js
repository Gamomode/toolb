(function () {
  'use strict';

  var SCRIPT_RE = /<script[^>]*\ssrc\s*=\s*["']([^"']+)["']/gi;
  var LINK_RE = /<link[^>]*\shref\s*=\s*["']([^"']+)["']/gi;
  var IMPORT_RE = /(?:import\s+[^'"]*?from\s*|require\(\s*)["']([^"']+)["']/g;
  var URL_RE = /\bhttps?:\/\/[^\s'"`)<>\]]+/gi;

  var RULES = [
    { id: 'eval', re: /\beval\s*\(/g, level: 'high', title: '动态执行 eval', detail: '字符串被当作代码执行，通常是授权校验或解密入口，建议在 eval 前下断点查看入参。' },
    { id: 'func', re: /new\s+Function\s*\(/g, level: 'high', title: 'Function 构造执行', detail: '与 eval 等价，定位调用方可还原被隐藏的逻辑。' },
    { id: 'b64', re: /\batob\s*\(|\bbtoa\s*\(/g, level: 'mid', title: 'Base64 编解码', detail: '常见于内嵌资源或请求头，可直接解码还原明文。' },
    { id: 'crypto', re: /CryptoJS|createHash|\bmd5\b|\bsha256\b|encrypt\s*\(|decrypt\s*\(/gi, level: 'mid', title: '加密 / 签名逻辑', detail: '关注密钥来源与参数拼接顺序，可在控制台复现签名。' },
    { id: 'net', re: /\bfetch\s*\(|\$\.ajax|\baxios\b|XMLHttpRequest/gi, level: 'info', title: '网络请求点', detail: '离线化时需要接管这些请求，改为读取本地缓存或 mock 数据。' },
    { id: 'store', re: /localStorage|sessionStorage|indexedDB/gi, level: 'info', title: '本地存储使用', detail: '离线数据可直接复用这些键，注意版本与清理策略。' },
    { id: 'map', re: /sourceMappingURL=\s*([^\s*]+)/g, level: 'low', title: 'sourcemap 残留', detail: '可直接还原原始源码，优先检查。' },
    { id: 'webpack', re: /__webpack_require__|webpackJsonp/g, level: 'low', title: 'webpack 打包产物', detail: '模块化产物，可依据模块 id 定位依赖关系。' }
  ];

  function hash(str) {
    var h = 0;
    for (var i = 0; i < str.length; i++) {
      h = (h * 31 + str.charCodeAt(i)) | 0;
    }
    return Math.abs(h).toString(36);
  }

  function isExternal(u) {
    return /^(https?:)?\/\//i.test(String(u || ''));
  }

  function vendorPath(url) {
    var u;
    try {
      u = new URL(String(url).charAt(0) === '/' && String(url).charAt(1) === '/' ? 'https:' + url : url);
    } catch (e) {
      return 'vendor/remote-' + hash(String(url)) + '.txt';
    }
    var parts = u.pathname.split('/').filter(Boolean);
    var file = (parts[parts.length - 1] || 'index').split('?')[0];
    var safeFile = file.replace(/[^a-zA-Z0-9._-]/g, '_') || 'asset.txt';
    var scoped = parts.filter(function (p) {
      return p.indexOf('@') > 0;
    });
    var src = scoped.length ? scoped[scoped.length - 1] : u.hostname;
    var dir = src.replace(/[^a-zA-Z0-9._@-]/g, '_');
    return 'vendor/' + dir + '/' + safeFile;
  }

  function extOf(path) {
    var m = /\.([a-zA-Z0-9]+)$/.exec(String(path || ''));
    return m ? m[1].toLowerCase() : 'txt';
  }

  function collectOnce(re, content, push) {
    var m;
    re.lastIndex = 0;
    while ((m = re.exec(content))) push(m[1]);
  }

  function analyze(files) {
    var list = Array.isArray(files) ? files : [];
    var externals = {};
    var risks = [];
    var structure = [];

    list.forEach(function (f) {
      var content = f.content || '';
      var rows = content.split('\n');
      var deps = [];

      collectOnce(SCRIPT_RE, content, function (u) {
        deps.push(u);
      });
      collectOnce(LINK_RE, content, function (u) {
        deps.push(u);
      });
      collectOnce(IMPORT_RE, content, function (u) {
        deps.push(u);
      });

      deps.filter(isExternal).forEach(function (u) {
        if (!externals[u]) externals[u] = { url: u, offline: vendorPath(u), files: [] };
        if (externals[u].files.indexOf(f.path) < 0) externals[u].files.push(f.path);
      });

      if (!/\.html?$/i.test(f.path)) {
        var m;
        URL_RE.lastIndex = 0;
        while ((m = URL_RE.exec(content))) {
          var u = m[0].replace(/[.,;]+$/, '');
          if (u.length > 160) continue;
          if (!externals[u]) externals[u] = { url: u, offline: vendorPath(u), files: [] };
          if (externals[u].files.indexOf(f.path) < 0) externals[u].files.push(f.path);
        }
      }

      RULES.forEach(function (r) {
        var count = 0;
        var hit;
        r.re.lastIndex = 0;
        while ((hit = r.re.exec(content))) {
          count++;
          if (count > 40) break;
        }
        if (count > 0) {
          risks.push({
            id: r.id,
            level: r.level,
            title: r.title,
            detail: r.detail,
            file: f.path,
            count: count
          });
        }
      });

      var maxLine = rows.reduce(function (a, l) {
        return l.length > a ? l.length : a;
      }, 0);

      structure.push({
        path: f.path,
        type: extOf(f.path),
        size: content.length,
        lines: rows.length,
        deps: deps.filter(isExternal),
        minified: maxLine > 600
      });
    });

    var extCount = {};
    structure.forEach(function (s) {
      extCount[s.type] = (extCount[s.type] || 0) + 1;
    });

    var total = structure.reduce(function (a, s) {
      return a + s.size;
    }, 0);

    var report = {
      createdAt: Date.now(),
      summary: {
        files: structure.length,
        size: total,
        types: Object.keys(extCount).map(function (k) {
          return { type: k, count: extCount[k] };
        }),
        minified: structure.filter(function (s) {
          return s.minified;
        }).length
      },
      externals: Object.keys(externals).map(function (k) {
        return externals[k];
      }),
      risks: risks,
      structure: structure
    };

    report.plan = buildPlan(report);
    return report;
  }

  function buildPlan(report) {
    var risks = report.risks;
    var plan = [];
    var has = function (id) {
      return risks.some(function (r) {
        return r.id === id;
      });
    };

    if (report.externals.length) {
      plan.push({
        title: '外链本地化',
        detail: '把 ' + report.externals.length + ' 个外部资源下载到 vendor/ 目录，并把引用改写为相对路径，断网也能加载。'
      });
    }
    if (has('net')) {
      plan.push({
        title: '接管网络请求',
        detail: '在 api 层拦截 fetch / XHR / axios，优先读本地缓存，无网络时返回内置 mock 数据。'
      });
    }
    if (has('eval') || has('func')) {
      plan.push({
        title: '定位动态执行入口',
        detail: '对 eval / new Function 下断点，打印入参，还原被隐藏的加密或校验算法。'
      });
    }
    if (has('b64') || has('crypto')) {
      plan.push({
        title: '还原编码与签名',
        detail: '记录 atob 与加密函数入参出参，在控制台或 Node 中复现同一份签名。'
      });
    }
    if (report.summary.minified) {
      plan.push({
        title: '反压缩',
        detail: '存在压缩文件，先找 sourcemap，再用格式化工具还原结构后再分析。'
      });
    }
    plan.push({
      title: '打包离线版',
      detail: '导出离线 ZIP，或生成 Android WebView 工程包，编译后得到可安装的 APK。'
    });
    return plan;
  }

  function markdown(report, files) {
    var L = [];
    L.push('# AI 逆向报告');
    L.push('');
    L.push('- 生成时间：' + new Date(report.createdAt).toLocaleString());
    L.push('- 文件数：' + report.summary.files);
    L.push('- 体积：' + report.summary.size + ' 字节');
    L.push('- 外部依赖：' + report.externals.length);
    L.push('- 风险点：' + report.risks.length);
    L.push('');
    L.push('## 外部依赖 / 离线映射');
    if (!report.externals.length) L.push('- 无');
    report.externals.forEach(function (e) {
      L.push('- `' + e.url + '` → `' + e.offline + '`');
    });
    L.push('');
    L.push('## 风险与关键点');
    if (!report.risks.length) L.push('- 无');
    report.risks.forEach(function (r) {
      L.push('- [' + r.level + '] ' + r.title + '（' + r.file + '，' + r.count + ' 处）：' + r.detail);
    });
    L.push('');
    L.push('## 离线化方案');
    report.plan.forEach(function (p) {
      L.push('- **' + p.title + '**：' + p.detail);
    });
    L.push('');
    L.push('## 文件结构');
    report.structure.forEach(function (s) {
      L.push('- `' + s.path + '`  ' + s.size + ' B / ' + s.lines + ' 行' + (s.minified ? '  [压缩]' : ''));
    });
    L.push('');
    L.push('## 文件清单');
    (files || []).forEach(function (f) {
      L.push('- `' + f.path + '`  ' + (f.content || '').length + ' 字节');
    });
    return L.join('\n');
  }

  window.AI = {
    analyze: analyze,
    vendorPath: vendorPath,
    markdown: markdown
  };
})();