package com.hairplnmo.app

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.BroadcastReceiver
import android.content.SharedPreferences
import android.content.pm.PackageManager
import androidx.core.content.ContextCompat
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.border
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.Brush
import androidx.compose.material.icons.filled.EditNote
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Tag
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CardGiftcard
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.Handyman
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Photo
import androidx.compose.material.icons.filled.InsertDriveFile
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.Android
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Info
import androidx.compose.foundation.Image
import androidx.compose.ui.graphics.asImageBitmap
import android.graphics.BitmapFactory
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon

import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.composed
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.ClipboardManager
import androidx.compose.ui.text.AnnotatedString
import kotlinx.coroutines.delay
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.launch
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import java.security.MessageDigest
import kotlin.system.exitProcess
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.ui.text.style.TextOverflow
import android.provider.OpenableColumns
import java.io.ByteArrayOutputStream
import java.io.File
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

val BgColor = Color(0xFFF3F5F9)
val CardColor = Color(0xFFFFFFFF)
val AccentColor = Color(0xFF1A6DFF)
val MainText = Color(0xFF1B2230)
val SubText = Color(0xFF7A8499)
val LineColor = Color(0xFFE3E8F0)

data class Plan(val price: String, val orig: String, val days: Int, val badge: String, val animate: Boolean)
val ExpectedSig = "241e92d50251dfce8965c4381888f231fb7a78d67b35ed7ee228a1533b1a1437"

fun Modifier.tap(onClick: () -> Unit): Modifier = composed {
    clickable(interactionSource = remember { MutableInteractionSource() }, indication = null, onClick = onClick)
}

@Composable
fun FloatField(
    value: String,
    onValueChange: (String) -> Unit,
    label: String,
    modifier: Modifier = Modifier,
    isPassword: Boolean = false
) {
    var focused by remember { mutableStateOf(false) }
    val up = focused || value.isNotEmpty()
    val labelSize by animateFloatAsState(if (up) 11f else 14f)
    val labelTop by animateDpAsState(if (up) 8.dp else 20.dp)
    val inputTop by animateDpAsState(if (up) 16.dp else 0.dp)
    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(56.dp)
            .border(1.dp, if (focused) AccentColor else LineColor, RoundedCornerShape(12.dp))
            .background(CardColor, RoundedCornerShape(12.dp))
    ) {
        Text(
            label,
            fontSize = labelSize.sp,
            color = if (focused) AccentColor else SubText,
            modifier = Modifier
                .align(Alignment.TopStart)
                .padding(start = 14.dp, top = labelTop)
        )
        BasicTextField(
            value = value,
            onValueChange = onValueChange,
            singleLine = true,
            textStyle = TextStyle(fontSize = 15.sp, color = MainText),
            visualTransformation = if (isPassword) PasswordVisualTransformation() else VisualTransformation.None,
            keyboardOptions = KeyboardOptions(keyboardType = if (isPassword) KeyboardType.Password else KeyboardType.Text),
            modifier = Modifier
                .align(Alignment.CenterStart)
                .padding(start = 14.dp, end = 14.dp, top = inputTop)
                .fillMaxWidth()
                .onFocusChanged { focused = it.isFocused }
        )
    }
}

class MainActivity : ComponentActivity() {
    fun isSignatureValid(): Boolean {
        return try {
            val info = packageManager.getPackageInfo(packageName, PackageManager.GET_SIGNATURES)
            val sig = info.signatures?.firstOrNull() ?: return false
            val digest = MessageDigest.getInstance("SHA-256").digest(sig.toByteArray())
            val hex = digest.joinToString("") { "%02x".format(it) }
            hex == ExpectedSig
        } catch (e: Exception) {
            false
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        cleanTempFiles(this)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        val controller = WindowCompat.getInsetsController(window, window.decorView)
        controller.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        controller.hide(WindowInsetsCompat.Type.systemBars())
        val sigOk = isSignatureValid()
        val startUser = getLoggedInUser(this)
        setContent {
            var stage by remember {
                mutableStateOf(
                    when {
                        startUser.isEmpty() -> "login"
                        else -> "loading"
                    }
                )
            }
            var currentUser by remember { mutableStateOf(startUser) }
            Surface(color = BgColor, modifier = Modifier.fillMaxSize()) {
                if (!sigOk) {
                    TamperScreen(onExit = {
                        finishAffinity()
                        exitProcess(0)
                    })
                } else {
                    when (stage) {
                        "login" -> LoginScreen(onSuccess = { u ->
                            currentUser = u
                            stage = "loading"
                        })
                        "purchase" -> PurchaseScreen(onBack = { stage = "home" })
                        "loading" -> LoadingScreen(onDone = { stage = "home" })
                        "home" -> HomeScreen(
                            currentUser = currentUser,
                            onLogout = {
                                setLoggedInUser(applicationContext, "")
                                currentUser = ""
                                stage = "login"
                            },
                            onBuy = { stage = "purchase" }
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun TamperScreen(onExit: () -> Unit) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF1B2230)),
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(28.dp)
                .background(CardColor, RoundedCornerShape(22.dp))
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text("⚠", fontSize = 40.sp)
            Spacer(Modifier.height(12.dp))
            Text("检测到应用被修改", fontSize = 19.sp, fontWeight = FontWeight.Bold, color = MainText)
            Spacer(Modifier.height(8.dp))
            Text(
                "应用的文件或签名已被改动，为保护安全无法继续使用。",
                fontSize = 13.sp,
                color = SubText,
                textAlign = TextAlign.Center,
                lineHeight = 20.sp
            )
            Spacer(Modifier.height(20.dp))
            Button(
                onClick = onExit,
                modifier = Modifier.fillMaxWidth(),
                                colors = ButtonDefaults.buttonColors(containerColor = AccentColor)
            ) {
                Text("确定", fontSize = 15.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}


fun getLoggedInUser(context: Context): String {
    return context.getSharedPreferences("hairplnmo", Context.MODE_PRIVATE).getString("logged_user", "") ?: ""
}

fun setLoggedInUser(context: Context, user: String) {
    context.getSharedPreferences("hairplnmo", Context.MODE_PRIVATE).edit().putString("logged_user", user).apply()
}

fun setLoggedNick(context: Context, nick: String) {
    context.getSharedPreferences("hairplnmo", Context.MODE_PRIVATE).edit().putString("logged_nick", nick).apply()
}

fun getLoggedNick(context: Context): String {
    return context.getSharedPreferences("hairplnmo", Context.MODE_PRIVATE).getString("logged_nick", "") ?: ""
}

fun accountPrefs(context: Context, account: String): SharedPreferences =
    context.getSharedPreferences("user_" + if (account.isBlank()) "guest" else account, Context.MODE_PRIVATE)

fun currentAccountPrefs(context: Context): SharedPreferences =
    accountPrefs(context, context.getSharedPreferences("hairplnmo", Context.MODE_PRIVATE).getString("logged_user", "") ?: "")

fun checkLogin(context: Context, user: String, pass: String): String {
    val users = context.getSharedPreferences("hairplnmo", Context.MODE_PRIVATE)
        .getStringSet("accounts", emptySet()) ?: emptySet()
    return if (users.contains("$user|$pass")) "ok" else "账号或密码错误"
}

fun registerAccount(context: Context, user: String, pass: String): String {
    val sp = context.getSharedPreferences("hairplnmo", Context.MODE_PRIVATE)
    val users = sp.getStringSet("accounts", emptySet()) ?: emptySet()
    return when {
        user.isBlank() || pass.isBlank() -> "账号和密码不能为空"
        users.any { it.substringBefore('|') == user } -> "该账号已存在"
        else -> {
            sp.edit().putStringSet("accounts", users + "$user|$pass").apply()
            "注册成功"
        }
    }
}

fun openPayApp(context: Context, pkg: String): Boolean = try {
    context.packageManager.getLaunchIntentForPackage(pkg)?.let {
        it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(it)
        true
    } ?: false
} catch (e: Exception) {
    false
}

fun openPayAppCheck(context: Context, pkg: String): Boolean = try {
    context.packageManager.getLaunchIntentForPackage(pkg) != null
} catch (e: Exception) {
    false
}

fun completePurchase(context: Context, price: String, days: Int) {
    val time = java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", java.util.Locale.CHINA).format(java.util.Date())
    val sp = context.getSharedPreferences("hairplnmo", Context.MODE_PRIVATE)
    val ups = currentAccountPrefs(context)
    val account = sp.getString("logged_user", "") ?: ""
    val nick = sp.getString("logged_nick", "") ?: ""
    val name = nick.ifBlank { account }
    val nowMs = System.currentTimeMillis()
    val expire = ups.getLong("premium_expire", 0L)
    val base = if (expire > nowMs) expire else nowMs
    val records = ups.getStringSet("purchase_records", emptySet()) ?: emptySet()
    val record = "$time|$name|$price|高级账号 ${days}天|" + getDeviceId(context)
    ups.edit()
        .putStringSet("purchase_records", records + record)
        .putLong("premium_expire", base + days * 86400000L)
        .apply()
}

fun getPremiumExpire(context: Context): Long =
    currentAccountPrefs(context).getLong("premium_expire", 0L)

fun isPremium(context: Context): Boolean = getPremiumExpire(context) > System.currentTimeMillis()

fun getDeviceId(context: Context): String {
    val sp = context.getSharedPreferences("hairplnmo", Context.MODE_PRIVATE)
    var id = sp.getString("device_id", "") ?: ""
    if (id.isBlank()) {
        id = java.util.UUID.randomUUID().toString().replace("-", "").substring(0, 12)
        sp.edit().putString("device_id", id).apply()
    }
    return id
}

@Composable
fun PurchaseScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val sp = context.getSharedPreferences("hairplnmo", Context.MODE_PRIVATE)
    val ups = currentAccountPrefs(context)
    val claimedAccounts = sp.getStringSet("free_claim_accounts", emptySet()) ?: emptySet()
    var freeClaimed by remember {
        mutableStateOf(ups.getBoolean("free_claimed", false) || (sp.getString("logged_user", "") ?: "") in claimedAccounts)
    }
    val basePlans = listOf(
        Plan("0元", "", 1, "免费", false),
        Plan("0.01元", "1元", 1, "新用户试用", true),
        Plan("4.99元", "6元", 7, "最划算!", true),
        Plan("5.99元", "7元", 21, "超值装", true),
        Plan("7.99元", "9元", 40, "天数最多", true),
        Plan("9.9元", "12元", 80, "天数超多", true)
    )
    val plans = if (freeClaimed) basePlans.drop(1) + basePlans.take(1) else basePlans
    var showFreePrompt by remember { mutableStateOf(!ups.getBoolean("free_prompt_off", false) && !freeClaimed) }
    var selected by remember { mutableStateOf(0) }
    var showConfirm by remember { mutableStateOf(false) }
    var showPayMethod by remember { mutableStateOf(false) }
    var showPayDialog by remember { mutableStateOf(false) }
    var showPayResult by remember { mutableStateOf(false) }
    var showKeyDialog by remember { mutableStateOf(false) }
    var payAppName by remember { mutableStateOf("") }
    var pendingPay by remember { mutableStateOf(false) }
    var payTime by remember { mutableStateOf("") }
    var jumpMsg by remember { mutableStateOf("") }
    var claiming by remember { mutableStateOf(false) }
    var isClaim by remember { mutableStateOf(false) }
    var endTime by remember { mutableStateOf("") }
    var claimTrigger by remember { mutableStateOf(false) }
    val lifecycleOwner = LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME && pendingPay) {
                pendingPay = false
                showPayResult = true
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }
    LaunchedEffect(claimTrigger) {
        if (claimTrigger) {
            if (freeClaimed) {
                claiming = false
                jumpMsg = "已领取过,请勿重领"
                claimTrigger = false
                return@LaunchedEffect
            }
            claiming = true
            delay(2000)
            val nowMs = System.currentTimeMillis()
            val fmt = java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", java.util.Locale.CHINA)
            val timeStr = fmt.format(java.util.Date(nowMs))
            val account = sp.getString("logged_user", "") ?: ""
            val nick = sp.getString("logged_nick", "") ?: ""
            val name = nick.ifBlank { account }
            val records = ups.getStringSet("purchase_records", emptySet()) ?: emptySet()
            val record = "$timeStr|$name|0元|高级账号 1天|" + getDeviceId(context)
            sp.edit().putStringSet("free_claim_accounts", claimedAccounts + account).apply()
            ups.edit()
                .putStringSet("purchase_records", records + record)
                .putBoolean("free_claimed", true)
                .putLong("premium_expire", (if (ups.getLong("premium_expire", 0L) > nowMs) ups.getLong("premium_expire", 0L) else nowMs) + 86400000L)
                .apply()
            freeClaimed = true
            payTime = timeStr
            endTime = fmt.format(java.util.Date(ups.getLong("premium_expire", 0L)))
            isClaim = true
            claiming = false
            showKeyDialog = true
            claimTrigger = false
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(BgColor)
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            TextButton(onClick = onBack, contentPadding = PaddingValues(0.dp)) {
                Text("← 返回", fontSize = 14.sp, color = SubText)
            }
        }
        Text("购买高级账号", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = MainText)
        Spacer(Modifier.height(6.dp))
        Text("选择套餐，支付成功后自动激活生效", fontSize = 13.sp, color = SubText)
        Spacer(Modifier.height(10.dp))
        Text(
            "支付说明：支付后钱作废删除，请想好再支付，支付后无法退回！",
            fontSize = 12.sp,
            color = Color(0xFFB07A1E),
            lineHeight = 18.sp,
            modifier = Modifier
                .fillMaxWidth()
                .background(Color(0xFFFDF4E3), RoundedCornerShape(10.dp))
                .padding(horizontal = 12.dp, vertical = 8.dp)
        )
        Spacer(Modifier.height(20.dp))
        plans.forEachIndexed { i, p ->
            PlanCard(p, selected == i, gray = p.badge == "免费" && freeClaimed) {
                if (p.badge == "免费" && freeClaimed) jumpMsg = "已领取过,请勿重领" else selected = i
            }
            Spacer(Modifier.height(14.dp))
        }
        Spacer(Modifier.height(10.dp))
        Button(
            onClick = { if (plans[selected].badge == "免费") claimTrigger = true else showConfirm = true },
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(14.dp),
            enabled = !(plans[selected].badge == "免费" && claiming),
            colors = ButtonDefaults.buttonColors(containerColor = AccentColor)
        ) {
            Text(
                if (plans[selected].badge == "免费") (if (claiming) "加载中···请稍等片刻" else "领取") else "购买",
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold
            )
        }
        if (jumpMsg.isNotEmpty()) {
            Spacer(Modifier.height(12.dp))
            Text(jumpMsg, fontSize = 13.sp, color = Color(0xFFD0453E), modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
        }
        Spacer(Modifier.height(24.dp))
    }

    if (showFreePrompt) {
        AlertDialog(
            onDismissRequest = { showFreePrompt = false },
            title = { Text("新用户免费领取", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = MainText) },
            text = { Text("新用户可免费领取高级账号 1天，点击领取立即生效。", fontSize = 14.sp, color = SubText, lineHeight = 20.sp) },
            confirmButton = {
                TextButton(onClick = {
                    showFreePrompt = false
                    selected = 0
                    claimTrigger = true
                }) { Text("领取", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = AccentColor) }
            },
            dismissButton = {
                TextButton(onClick = {
                    showFreePrompt = false
                    ups.edit().putBoolean("free_prompt_off", true).apply()
                }) { Text("不再提醒", fontSize = 15.sp, color = SubText) }
            }
        )
    }

    if (showConfirm) {
        AlertDialog(
            onDismissRequest = { showConfirm = false },
            title = { Text("确定支付？", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = MainText) },
            text = { Text("支付后钱款将作废删除，不会进入任何账户，也无法退钱。", fontSize = 14.sp, color = SubText, lineHeight = 20.sp) },
            confirmButton = {
                TextButton(onClick = {
                    showConfirm = false
                    showPayMethod = true
                }) { Text("确定", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = AccentColor) }
            },
            dismissButton = {
                TextButton(onClick = { showConfirm = false }) { Text("取消", fontSize = 15.sp, color = SubText) }
            }
        )
    }

    if (showPayMethod) {
        AlertDialog(
            onDismissRequest = { showPayMethod = false },
            title = { Text("选择支付方式", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = MainText) },
            text = {
                Column {
                    Button(
                        onClick = {
                            showPayMethod = false
                            payAppName = "支付宝"
                            if (openPayAppCheck(context, "com.eg.android.AlipayGphone")) showPayDialog = true else jumpMsg = "未安装支付宝"
                        },
                        modifier = Modifier.fillMaxWidth(),
                                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1677FF))
                    ) {
                        Text("支付宝", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = Color.White)
                    }
                    Spacer(Modifier.height(10.dp))
                    Button(
                        onClick = {
                            showPayMethod = false
                            payAppName = "微信"
                            if (openPayAppCheck(context, "com.tencent.mm")) showPayDialog = true else jumpMsg = "未安装微信"
                        },
                        modifier = Modifier.fillMaxWidth(),
                                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E9E6A))
                    ) {
                        Text("微信", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = Color.White)
                    }
                    Spacer(Modifier.height(10.dp))
                    Button(
                        onClick = {
                            showPayMethod = false
                            payAppName = "抖音"
                            if (openPayAppCheck(context, "com.ss.android.ugc.aweme")) showPayDialog = true else jumpMsg = "未安装抖音"
                        },
                        modifier = Modifier.fillMaxWidth(),
                                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFB07A1E))
                    ) {
                        Text("抖音支付", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = Color.White)
                    }
                }
            },
            confirmButton = {},
            dismissButton = {}
        )
    }

    if (showPayDialog) {
        AlertDialog(
            onDismissRequest = { showPayDialog = false },
            title = { Text("支付", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = MainText) },
            text = { Text("使用${payAppName}支付 ${plans[selected].price}（高级账号 ${plans[selected].days}天）。点击确定后将跳转到${payAppName}完成付款。", fontSize = 14.sp, color = SubText, lineHeight = 20.sp) },
            confirmButton = {
                TextButton(onClick = {
                    showPayDialog = false
                    val pkg = when (payAppName) {
                        "支付宝" -> "com.eg.android.AlipayGphone"
                        "微信" -> "com.tencent.mm"
                        else -> "com.ss.android.ugc.aweme"
                    }
                    jumpMsg = if (openPayApp(context, pkg)) "" else "未安装$payAppName"
                    pendingPay = jumpMsg.isEmpty()
                }) { Text("确定支付", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = AccentColor) }
            },
            dismissButton = {
                TextButton(onClick = { showPayDialog = false }) { Text("取消", fontSize = 15.sp, color = SubText) }
            }
        )
    }

    if (showPayResult) {
        AlertDialog(
            onDismissRequest = { },
            title = { Text("支付失败，请重试", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Color(0xFFD0453E)) },
            text = { Text("未检测到支付成功。如果你已在${payAppName}完成付款，请点击「已完成支付」自动激活；否则请重试。", fontSize = 14.sp, color = SubText, lineHeight = 20.sp) },
            confirmButton = {
                TextButton(onClick = {
                    showPayResult = false
                    completePurchase(context, plans[selected].price, plans[selected].days)
                    val fmt = java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", java.util.Locale.CHINA)
                    payTime = fmt.format(java.util.Date())
                    endTime = fmt.format(java.util.Date(ups.getLong("premium_expire", 0L)))
                    isClaim = false
                    showKeyDialog = true
                }) { Text("已完成支付", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = AccentColor) }
            },
            dismissButton = {
                TextButton(onClick = { showPayResult = false }) { Text("确定", fontSize = 15.sp, color = SubText) }
            }
        )
    }

    if (showKeyDialog) {
        AlertDialog(
            onDismissRequest = { showKeyDialog = false },
            title = { Text(if (isClaim) "免费领取成功" else "支付成功", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = MainText) },
            text = {
                Column {
                    Text("时间：$payTime", fontSize = 14.sp, color = SubText)
                    Spacer(Modifier.height(3.dp))
                    Text("付费：${plans[selected].price}", fontSize = 14.sp, color = SubText)
                    Spacer(Modifier.height(3.dp))
                    Text("内容：高级账号 ${plans[selected].days}天", fontSize = 14.sp, color = SubText)
                    Spacer(Modifier.height(3.dp))
                    Text("结束时间：$endTime", fontSize = 14.sp, color = SubText)
                    Spacer(Modifier.height(12.dp))
                    Text("高级账号已自动激活生效。", fontSize = 12.sp, color = SubText)
                }
            },
            confirmButton = { },
            dismissButton = {
                TextButton(onClick = { showKeyDialog = false }) { Text("确定", fontSize = 15.sp, color = SubText) }
            }
        )
    }
}

@Composable
fun PlanCard(p: Plan, selected: Boolean, gray: Boolean = false, onClick: () -> Unit) {
    var animStarted by remember { mutableStateOf(false) }
    var cardShown by remember { mutableStateOf(false) }
    val target = p.price.removeSuffix("元").toFloatOrNull() ?: 0f
    val start = p.orig.removeSuffix("元").toFloatOrNull() ?: 0f
    LaunchedEffect(Unit) {
        delay(100)
        cardShown = true
        if (p.animate) {
            delay(400)
            animStarted = true
        }
    }
    val priceNum by animateFloatAsState(if (p.animate && animStarted) target else start)
    val cardAlpha by animateFloatAsState(if (cardShown) 1f else 0f)
    val cardOffset by animateDpAsState(if (cardShown) 0.dp else 40.dp)
    Box(
        Modifier
            .fillMaxWidth()
            .graphicsLayer {
                alpha = cardAlpha
                translationY = cardOffset.toPx()
            }
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(if (gray) Color(0xFFEEF1F6) else CardColor, RoundedCornerShape(18.dp))
                .then(if (selected) Modifier.border(2.dp, AccentColor, RoundedCornerShape(18.dp)) else Modifier)
                .tap(onClick)
                .padding(18.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                if (p.animate) {
                    Text(String.format("%.2f元", priceNum), fontSize = 24.sp, fontWeight = FontWeight.Bold, color = if (gray) SubText else if (selected) AccentColor else MainText, textDecoration = if (gray) TextDecoration.LineThrough else null)
                } else {
                    Text(p.price, fontSize = 24.sp, fontWeight = FontWeight.Bold, color = if (gray) SubText else if (selected) AccentColor else MainText, textDecoration = if (gray) TextDecoration.LineThrough else null)
                }
                if (p.orig.isNotEmpty()) {
                    Spacer(Modifier.height(4.dp))
                    Text(p.orig, fontSize = 13.sp, color = SubText, textDecoration = TextDecoration.LineThrough)
                }
                Spacer(Modifier.height(4.dp))
                Text("高级账号 ${p.days}天", fontSize = 13.sp, color = SubText, textDecoration = if (gray) TextDecoration.LineThrough else null)
            }
            Box(
                modifier = Modifier
                    .size(24.dp)
                    .then(
                        if (selected) Modifier.background(if (gray) Color(0xFFC6CCD8) else AccentColor, CircleShape)
                        else Modifier.border(2.dp, Color(0xFFC6CCD8), CircleShape)
                    ),
                contentAlignment = Alignment.Center
            ) {
                if (selected) {
                    Icon(Icons.Filled.Check, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
                }
            }
        }
        if (p.badge.isNotEmpty()) {
            Text(
                p.badge,
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White,
                modifier = Modifier
                    .background(if (gray) Color(0xFFC6CCD8) else Color(0xFFD0453E), RoundedCornerShape(topStart = 18.dp, topEnd = 4.dp, bottomEnd = 12.dp))
                    .padding(horizontal = 10.dp, vertical = 4.dp)
            )
        }
    }
}

@Composable
fun LoginScreen(onSuccess: (String) -> Unit) {
    val context = LocalContext.current
    var mode by remember { mutableStateOf("login") }
    var user by remember { mutableStateOf("") }
    var pass by remember { mutableStateOf("") }
    var nick by remember { mutableStateOf("") }
    var msg by remember { mutableStateOf("") }
    var msgColor by remember { mutableStateOf(AccentColor) }
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFFFFFFF))
            .padding(horizontal = 28.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Box(
            modifier = Modifier
                .size(64.dp)
                .background(Color(0xFF1C1C1E), RoundedCornerShape(18.dp)),
            contentAlignment = Alignment.Center
        ) {
            Icon(Icons.Filled.Handyman, contentDescription = null, tint = Color.White, modifier = Modifier.size(30.dp))
        }
        Spacer(Modifier.height(16.dp))
        Text("HAirPLNmo", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = MainText)
        Spacer(Modifier.height(6.dp))
        Text(if (mode == "login") "登录以继续" else "创建新账号", fontSize = 14.sp, color = SubText)
        Spacer(Modifier.height(30.dp))
        FloatField(
            value = user,
            onValueChange = { user = it; msg = "" },
            label = "账号",
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(14.dp))
        FloatField(
            value = pass,
            onValueChange = { pass = it; msg = "" },
            label = "密码",
            modifier = Modifier.fillMaxWidth(),
            isPassword = true
        )
        Spacer(Modifier.height(14.dp))
        if (mode == "register") {
            FloatField(
                value = nick,
                onValueChange = { nick = it; msg = "" },
                label = "请输入昵称",
                modifier = Modifier.fillMaxWidth()
            )
        }
        Spacer(Modifier.height(20.dp))
        Button(
            onClick = {
                if (mode == "login") {
                    val r = checkLogin(context, user.trim(), pass)
                    if (r == "ok") {
                        setLoggedInUser(context, user.trim())
                        onSuccess(user.trim())
                    } else {
                        msg = r
                        msgColor = Color(0xFFD0453E)
                    }
                } else {
                    if (nick.isBlank()) {
                        msg = "请输入昵称"
                        msgColor = Color(0xFFD0453E)
                        return@Button
                    }
                    val r = registerAccount(context, user.trim(), pass)
                    if (r == "注册成功") {
                        setLoggedNick(context, nick.trim())
                        mode = "login"
                        pass = ""
                        nick = ""
                        msg = "注册成功，请登录"
                        msgColor = Color(0xFF1E9E6A)
                    } else {
                        msg = r
                        msgColor = Color(0xFFD0453E)
                    }
                }
            },
            modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(containerColor = AccentColor)
        ) {
            Text(if (mode == "login") "登录" else "注册", fontSize = 15.sp, fontWeight = FontWeight.Bold)
        }
        if (msg.isNotEmpty()) {
            Spacer(Modifier.height(12.dp))
            Text(msg, fontSize = 14.sp, color = msgColor, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
        }
        Spacer(Modifier.height(10.dp))
        TextButton(onClick = {
            mode = if (mode == "login") "register" else "login"
            msg = ""
        }, contentPadding = PaddingValues(6.dp)) {
            Text(
                if (mode == "login") "没有账号？去注册" else "已有账号？去登录",
                fontSize = 13.sp,
                color = SubText
            )
        }
    }
}

data class OrderInfo(val time: String, val content: String, val amount: String, val startMillis: Long, val expireMillis: Long)

@Composable
fun OrdersDialog(currentUser: String, onDismiss: () -> Unit) {
    val context = LocalContext.current
    val sp = currentAccountPrefs(context)
    var now by remember { mutableStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) {
        while (true) {
            delay(1000)
            now = System.currentTimeMillis()
        }
    }
    val records = sp.getStringSet("purchase_records", emptySet()) ?: emptySet()
    val nick = getLoggedNick(context)
    val displayName = nick.ifBlank { currentUser }
    val fmt = java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", java.util.Locale.CHINA)
    val fmtMin = java.text.SimpleDateFormat("yyyy-MM-dd HH:mm", java.util.Locale.CHINA)
    val myRecords = records.filter {
        val f = it.split("|")
        if (f.size >= 5) f[4] == getDeviceId(context) else f.getOrElse(1) { "" } == displayName
    }
    val myOrders = myRecords.map { r ->
        val f = r.split("|")
        val time = f.getOrElse(0) { "" }
        val content = f.getOrElse(3) { "高级账号" }
        val amount = f.getOrElse(2) { "" }
        val days = content.removePrefix("高级账号 ").removeSuffix("天").toIntOrNull() ?: 0
        val startMillis = try {
            fmt.parse(time)?.time ?: fmtMin.parse(time)?.time
        } catch (e: Exception) {
            null
        }
        val endMillis = startMillis?.plus(days * 86400000L)
        OrderInfo(time, content, amount, startMillis ?: 0L, endMillis ?: 0L)
    }.sortedByDescending { it.startMillis }
    val active = myOrders.filter { it.expireMillis > now }
    val expired = myOrders.filter { it.expireMillis <= now }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("我的订单", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = MainText) },
        text = {
            Column(
                modifier = Modifier
                    .heightIn(max = 360.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                if (myOrders.isEmpty()) {
                    Text("暂无订单", fontSize = 14.sp, color = SubText)
                }
                if (active.isNotEmpty()) {
                    Text("生效中（${active.size}）", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = Color(0xFF1E9E6A))
                    Spacer(Modifier.height(8.dp))
                    active.forEach { o ->
                        OrderCard(o, false)
                    }
                    Spacer(Modifier.height(14.dp))
                }
                if (expired.isNotEmpty()) {
                    Text("已失效（${expired.size}）", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = SubText)
                    Spacer(Modifier.height(8.dp))
                    expired.forEach { o ->
                        OrderCard(o, true)
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) { Text("关闭", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = AccentColor) }
        }
    )
}

@Composable
fun OrderCard(o: OrderInfo, expired: Boolean) {
    val fmt = java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", java.util.Locale.CHINA)
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(CardColor, RoundedCornerShape(14.dp))
            .padding(horizontal = 16.dp, vertical = 14.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("内容：${o.content}", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = if (expired) SubText else MainText, modifier = Modifier.weight(1f))
            Text(
                if (expired) "已失效" else "生效中",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = if (expired) SubText else Color(0xFF1E9E6A),
                modifier = Modifier
                    .background(if (expired) Color(0xFFEEF1F6) else Color(0xFFE3F4EC), RoundedCornerShape(999.dp))
                    .padding(horizontal = 8.dp, vertical = 2.dp)
            )
        }
        Spacer(Modifier.height(3.dp))
        Text("支付：${o.amount}", fontSize = 12.sp, color = SubText)
        Spacer(Modifier.height(3.dp))
        Text("生效时间：${fmt.format(java.util.Date(o.startMillis))}", fontSize = 12.sp, color = SubText)
        Spacer(Modifier.height(3.dp))
        Text("过期时间：${fmt.format(java.util.Date(o.expireMillis))}", fontSize = 12.sp, color = SubText)
    }
}

@Composable
fun HistoryDialog(onClose: () -> Unit) {
    val context = LocalContext.current
    var entries by remember { mutableStateOf(loadHistory(context)) }
    var expandedId by remember { mutableStateOf(0L) }
    var deleteTarget by remember { mutableStateOf<HistoryEntry?>(null) }
    var secExpanded by remember { mutableStateOf(true) }
    ToolDialog(title = "历史记录", onClose = onClose) {
        CollapsibleSection(title = "历史记录", expanded = secExpanded, onToggle = { secExpanded = !secExpanded }) {
            if (entries.isEmpty()) {
                Text("暂无历史记录，用过的功能完成后会显示在这里", fontSize = 13.sp, color = SubText)
            } else {
                entries.asReversed().forEach { e ->
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(BgColor, RoundedCornerShape(10.dp))
                            .padding(horizontal = 12.dp, vertical = 8.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(e.func, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = MainText, modifier = Modifier.weight(1f))
                            Text(
                                if (e.premium) "高级版" else "免费版",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (e.premium) Color(0xFFD4A017) else Color(0xFF1E9E6A)
                            )
                        }
                        Spacer(Modifier.height(2.dp))
                        Text(e.time, fontSize = 12.sp, color = SubText)
                        Spacer(Modifier.height(6.dp))
                        Row {
                            Text(
                                "查看",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF1E9E6A),
                                modifier = Modifier.tap { expandedId = if (expandedId == e.id) 0L else e.id }
                            )
                            Spacer(Modifier.width(24.dp))
                            Text(
                                "删除",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFFD0453E),
                                modifier = Modifier.tap { deleteTarget = e }
                            )
                        }
                        if (expandedId == e.id) {
                            Spacer(Modifier.height(6.dp))
                            Text(e.detail, fontSize = 12.sp, color = Color(0xFF1E9E6A), lineHeight = 18.sp)
                        }
                    }
                    Spacer(Modifier.height(6.dp))
                }
                Text(
                    if (isPremium(context)) "高级版最多保留 10000 条记录" else "免费版最多保留 4 条记录，超出自动删除最早的",
                    fontSize = 12.sp,
                    color = SubText
                )
            }
        }
    }
    if (deleteTarget != null) {
        AlertDialog(
            onDismissRequest = { deleteTarget = null },
            title = { Text("删除记录", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = MainText) },
            text = { Text("确定删除该条历史记录吗？删除后无法恢复。", fontSize = 14.sp, color = SubText) },
            confirmButton = {
                TextButton(onClick = {
                    val t = deleteTarget
                    if (t != null) deleteHistory(context, t.id)
                    entries = loadHistory(context)
                    expandedId = 0
                    deleteTarget = null
                }) { Text("确定", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = Color(0xFFD0453E)) }
            },
            dismissButton = {
                TextButton(onClick = { deleteTarget = null }) { Text("取消", fontSize = 15.sp, color = SubText) }
            }
        )
    }
}

@Composable
fun LoadingScreen(onDone: () -> Unit) {
    LaunchedEffect(Unit) {
        delay(1800)
        onDone()
    }
    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            CircularProgressIndicator(color = AccentColor)
            Spacer(Modifier.height(16.dp))
            Text("加载中…", fontSize = 14.sp, color = SubText)
        }
    }
}

@Composable
fun HomeScreen(
    currentUser: String,
    onLogout: () -> Unit,
    onBuy: () -> Unit
) {
    var menuOpen by remember { mutableStateOf(false) }
    var showAccountInfo by remember { mutableStateOf(false) }
    var showOrdersDialog by remember { mutableStateOf(false) }
    var showHistoryDialog by remember { mutableStateOf(false) }
    var showLogoutConfirm by remember { mutableStateOf(false) }
    var showHashTool by remember { mutableStateOf(false) }
    var showFileModifier by remember { mutableStateOf(false) }
    val homeContext = LocalContext.current
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFF2F0EB))
            .verticalScroll(rememberScrollState())
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(44.dp)
                    .background(Color(0xFF1C1C1E), RoundedCornerShape(12.dp)),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Filled.Build, contentDescription = null, tint = Color.White, modifier = Modifier.size(22.dp))
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text("HAirPLNmo", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = MainText)
                Spacer(Modifier.height(2.dp))
                Text("本地工具箱", fontSize = 12.sp, color = SubText)
            }
            Box(
                modifier = Modifier
                    .background(if (isPremium(homeContext)) Color(0xFFFFF3CD) else Color(0xFFC9EEDC), RoundedCornerShape(999.dp))
                    .padding(horizontal = 12.dp, vertical = 5.dp)
            ) {
                Text(
                    if (isPremium(homeContext)) "高级" else "免费版",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (isPremium(homeContext)) Color(0xFFD4A017) else Color(0xFF1E9E6A)
                )
            }
            Spacer(Modifier.width(10.dp))
            Box {
                Icon(
                    Icons.Filled.Menu,
                    contentDescription = null,
                    tint = MainText,
                    modifier = Modifier.tap { menuOpen = true }
                )
                DropdownMenu(
                    expanded = menuOpen,
                    onDismissRequest = { menuOpen = false },
                    shape = RoundedCornerShape(16.dp)
                ) {
                    DropdownMenuItem(
                        text = { Text("1. 账号信息", fontSize = 15.sp, color = MainText) },
                        onClick = {
                            menuOpen = false
                            showAccountInfo = true
                        }
                    )
                    DropdownMenuItem(
                        text = { Text("2. 高级账号", fontSize = 15.sp, color = MainText) },
                        onClick = {
                            menuOpen = false
                            onBuy()
                        }
                    )
                    DropdownMenuItem(
                        text = { Text("3. 订单", fontSize = 15.sp, color = MainText) },
                        onClick = {
                            menuOpen = false
                            showOrdersDialog = true
                        }
                    )
                    DropdownMenuItem(
                        text = { Text("4. 历史记录", fontSize = 15.sp, color = MainText) },
                        onClick = {
                            menuOpen = false
                            showHistoryDialog = true
                        }
                    )
                    DropdownMenuItem(
                        text = { Text("5. 退出登录", fontSize = 15.sp, color = Color(0xFFD0453E)) },
                        onClick = {
                            menuOpen = false
                            showLogoutConfirm = true
                        }
                    )
                }
            }
        }
        Column(Modifier.padding(horizontal = 20.dp)) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color.White, RoundedCornerShape(20.dp))
                    .padding(20.dp)
            ) {
                Text("欢迎使用", fontSize = 13.sp, color = SubText)
                Spacer(Modifier.height(6.dp))
                Text("HAirPLNmo 免费版", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = MainText)
                Spacer(Modifier.height(8.dp))
                Text(
                    "常用工具正在陆续恢复中，敬请期待更多功能。",
                    fontSize = 14.sp,
                    color = Color(0xFF5A5F6B),
                    lineHeight = 22.sp
                )
            }
            Spacer(Modifier.height(24.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("工具", fontSize = 17.sp, fontWeight = FontWeight.Bold, color = MainText, modifier = Modifier.weight(1f))
                Text("开发中", fontSize = 13.sp, color = SubText)
            }
            Spacer(Modifier.height(14.dp))
            Row(Modifier.fillMaxWidth()) {
                ToolCard("哈希工具", "计算各类哈希值", Icons.Filled.Tag, Modifier.weight(1f), onClick = { showHashTool = true }, badge = "已开发")
                Spacer(Modifier.width(14.dp))
                ToolCard("文件修改器", "查找、替换、定位", Icons.Filled.EditNote, Modifier.weight(1f), onClick = { showFileModifier = true }, badge = "已开发")
            }
            Spacer(Modifier.height(14.dp))
            Row(Modifier.fillMaxWidth()) {
                ToolCard("打包工具", "极速打包安装包", Icons.Filled.Inventory2, Modifier.weight(1f))
                Spacer(Modifier.width(14.dp))
                ToolCard("APK 分析", "安装包信息解析", Icons.Filled.Brush, Modifier.weight(1f))
            }
            Spacer(Modifier.height(14.dp))
            Row(Modifier.fillMaxWidth()) {
                ToolCard("加密工具", "加盐哈希与乱码", Icons.Filled.VerifiedUser, Modifier.weight(1f))
                Spacer(Modifier.width(14.dp))
                ToolCard("更多工具", "陆续上架中", Icons.Filled.Apps, Modifier.weight(1f))
            }
            Spacer(Modifier.height(28.dp))
            Text(
                "HAirPLNmo · 免费版",
                fontSize = 12.sp,
                color = Color(0xFFB9B4AA),
                modifier = Modifier.fillMaxWidth(),
                textAlign = TextAlign.Center
            )
            Spacer(Modifier.height(20.dp))
        }
    }
    if (showAccountInfo) {
        val context = LocalContext.current
        AlertDialog(
            onDismissRequest = { showAccountInfo = false },
            title = { Text("账号信息", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = MainText) },
            text = {
                Column {
                    val premium = isPremium(context)
                    Text(
                        "账号：$currentUser" + if (premium) "-高级" else "",
                        fontSize = 15.sp,
                        fontWeight = if (premium) FontWeight.Bold else FontWeight.Normal,
                        color = if (premium) Color(0xFFD4A017) else MainText
                    )
                    Spacer(Modifier.height(6.dp))
                    val nick = getLoggedNick(context)
                    Text("昵称：${nick.ifBlank { "未设置" }}", fontSize = 15.sp, color = MainText)
                    if (premium) {
                        Spacer(Modifier.height(6.dp))
                        var now by remember { mutableStateOf(System.currentTimeMillis()) }
                        LaunchedEffect(Unit) {
                            while (true) {
                                delay(1000)
                                now = System.currentTimeMillis()
                            }
                        }
                        val remain = getPremiumExpire(context) - now
                        if (remain > 0) {
                            val d = remain / 86400000
                            val h = remain % 86400000 / 3600000
                            val m = remain % 3600000 / 60000
                            val s = remain % 60000 / 1000
                            Text("高级账号时间：${d}天${h}小时${m}分${s}秒", fontSize = 14.sp, color = Color(0xFFD4A017))
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showAccountInfo = false }) { Text("确定", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = AccentColor) }
            }
        )
    }
    if (showLogoutConfirm) {
        AlertDialog(
            onDismissRequest = { showLogoutConfirm = false },
            title = { Text("退出登录", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = MainText) },
            text = { Text("确定退出登录吗？", fontSize = 14.sp, color = SubText) },
            confirmButton = {
                TextButton(onClick = {
                    showLogoutConfirm = false
                    onLogout()
                }) { Text("确定", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = Color(0xFFD0453E)) }
            },
            dismissButton = {
                TextButton(onClick = { showLogoutConfirm = false }) { Text("取消", fontSize = 15.sp, color = SubText) }
            }
        )
    }
    if (showOrdersDialog) {
        OrdersDialog(currentUser = currentUser, onDismiss = { showOrdersDialog = false })
    }
    if (showHistoryDialog) {
        HistoryDialog(onClose = { showHistoryDialog = false })
    }
    if (showHashTool) {
        HashToolDialog(onClose = { showHashTool = false })
    }
    if (showFileModifier) {
        FileModifierDialog(onClose = { showFileModifier = false }, onBuy = onBuy)
    }
}

@Composable
fun ToolCard(title: String, sub: String, icon: ImageVector, modifier: Modifier = Modifier, onClick: () -> Unit = {}, badge: String = "敬请期待") {
    Column(
        modifier = modifier
            .background(Color.White, RoundedCornerShape(18.dp))
            .tap(onClick)
            .padding(16.dp)
    ) {
        Box(
            modifier = Modifier
                .size(48.dp)
                .background(Color(0xFFF0EEE8), RoundedCornerShape(14.dp)),
            contentAlignment = Alignment.Center
        ) {
            Icon(icon, contentDescription = null, tint = Color(0xFF3A3F4A), modifier = Modifier.size(24.dp))
        }
        Spacer(Modifier.height(12.dp))
        Text(title, fontSize = 16.sp, fontWeight = FontWeight.Bold, color = MainText)
        Spacer(Modifier.height(3.dp))
        Text(sub, fontSize = 12.sp, color = SubText)
        Spacer(Modifier.height(10.dp))
        Box(
            modifier = Modifier
                .background(Color(0xFFEFEDE8), RoundedCornerShape(999.dp))
                .padding(horizontal = 10.dp, vertical = 4.dp)
        ) {
            Text(badge, fontSize = 11.sp, color = Color(0xFF8A8A85))
        }
    }
}

fun hashHex(input: String, algo: String): String =
    MessageDigest.getInstance(algo).digest(input.toByteArray()).joinToString("") { "%02x".format(it) }

@Composable
fun ToolDialog(
    title: String,
    onClose: () -> Unit,
    content: @Composable ColumnScope.() -> Unit
) {
    Dialog(
        onDismissRequest = onClose,
        properties = DialogProperties(dismissOnClickOutside = false)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(BgColor, RoundedCornerShape(20.dp))
                .padding(16.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    Icons.Filled.Close,
                    contentDescription = "关闭",
                    tint = MainText,
                    modifier = Modifier
                        .size(26.dp)
                        .tap(onClose)
                )
                Spacer(Modifier.width(10.dp))
                Text(title, fontSize = 18.sp, fontWeight = FontWeight.Bold, color = MainText, modifier = Modifier.weight(1f))
            }
            Spacer(Modifier.height(14.dp))
            content()
        }
    }
}

@Composable
fun ToolMenuItem(index: String, title: String, sub: String, onClick: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(CardColor, RoundedCornerShape(14.dp))
            .tap(onClick)
            .padding(horizontal = 16.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text("$index. $title", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = MainText)
            Spacer(Modifier.height(2.dp))
            Text(sub, fontSize = 12.sp, color = SubText)
        }
        Icon(Icons.Filled.ChevronRight, contentDescription = null, tint = SubText)
    }
    Spacer(Modifier.height(8.dp))
}

@Composable
fun HashToolDialog(onClose: () -> Unit) {
    var page by remember { mutableStateOf(0) }
    ToolDialog(title = "哈希工具", onClose = onClose) {
        ToolMenuItem("1", "哈希值计算", "计算文本的 MD5、SHA 系列哈希值") { page = 1 }
        ToolMenuItem("2", "哈希函数", "了解各哈希算法的特点与用途") { page = 2 }
        ToolMenuItem("3", "哈希校验", "对比哈希值，验证内容是否一致") { page = 3 }
    }
    if (page == 1) {
        HashCalcPage(onClose = { page = 0 })
    }
    if (page == 2) {
        HashFuncPage(onClose = { page = 0 })
    }
    if (page == 3) {
        HashVerifyPage(onClose = { page = 0 })
    }
}

@Composable
fun HashCalcPage(onClose: () -> Unit) {
    val clipboard = LocalClipboardManager.current
    var input by remember { mutableStateOf("") }
    var copied by remember { mutableStateOf("") }
    ToolDialog(title = "哈希值计算", onClose = onClose) {
        FloatField(
            value = input,
            onValueChange = {
                input = it
                copied = ""
            },
            label = "输入文本",
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(12.dp))
        if (copied.isNotEmpty()) {
            Text(copied, fontSize = 12.sp, color = Color(0xFF1E9E6A))
            Spacer(Modifier.height(8.dp))
        }
        Text("点击结果可复制", fontSize = 12.sp, color = SubText)
        Spacer(Modifier.height(8.dp))
        listOf("MD5", "SHA-1", "SHA-256", "SHA-512").forEach { algo ->
            val hex = hashHex(input, algo)
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(CardColor, RoundedCornerShape(12.dp))
                    .tap {
                        clipboard.setText(AnnotatedString(hex))
                        copied = "已复制$algo 结果"
                    }
                    .padding(horizontal = 14.dp, vertical = 10.dp)
            ) {
                Text(algo, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = MainText)
                Spacer(Modifier.height(3.dp))
                Text(hex, fontSize = 12.sp, color = SubText)
            }
            Spacer(Modifier.height(8.dp))
        }
    }
}

@Composable
fun HashFuncPage(onClose: () -> Unit) {
    ToolDialog(title = "哈希函数", onClose = onClose) {
        Text("哈希函数能把任意内容变成固定长度的「指纹」，内容哪怕只差一个字，结果也完全不同，且无法反推原文。", fontSize = 13.sp, color = SubText)
        Spacer(Modifier.height(12.dp))
        listOf(
            Triple("MD5", "128 位 · 32 位十六进制", "速度最快，但已被破解，只适合普通文件校验，不能用于安全场景。"),
            Triple("SHA-1", "160 位 · 40 位十六进制", "曾被广泛使用，现已被攻破，不建议在新场景使用。"),
            Triple("SHA-256", "256 位 · 64 位十六进制", "目前最常用的安全算法，兼顾速度与安全性。"),
            Triple("SHA-512", "512 位 · 128 位十六进制", "安全性最高，结果最长，适合对安全要求极高的场景。")
        ).forEach { (name, len, desc) ->
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(CardColor, RoundedCornerShape(12.dp))
                    .padding(horizontal = 14.dp, vertical = 10.dp)
            ) {
                Text(name, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = MainText)
                Spacer(Modifier.height(3.dp))
                Text(len, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color(0xFF3B5BDB))
                Spacer(Modifier.height(3.dp))
                Text(desc, fontSize = 12.sp, color = SubText)
            }
            Spacer(Modifier.height(8.dp))
        }
    }
}

@Composable
fun HashVerifyPage(onClose: () -> Unit) {
    var text by remember { mutableStateOf("") }
    var target by remember { mutableStateOf("") }
    val t = target.trim().lowercase()
    val algos = listOf("MD5", "SHA-1", "SHA-256", "SHA-512")
    val matches = if (t.isEmpty()) emptyList() else algos.filter { hashHex(text, it) == t }
    ToolDialog(title = "哈希校验", onClose = onClose) {
        FloatField(
            value = text,
            onValueChange = { text = it },
            label = "原文内容",
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(10.dp))
        FloatField(
            value = target,
            onValueChange = { target = it },
            label = "待校验的哈希值",
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(12.dp))
        if (t.isNotEmpty()) {
            if (matches.isNotEmpty()) {
                Text("校验通过：${matches.joinToString("、")}", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Color(0xFF1E9E6A))
            } else {
                Text("校验不通过：内容与该哈希值不一致", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Color(0xFFD0453E))
            }
            Spacer(Modifier.height(10.dp))
        }
        Text("原文的各算法哈希值（点击复制）", fontSize = 12.sp, color = SubText)
        Spacer(Modifier.height(8.dp))
        val clipboard = LocalClipboardManager.current
        var copied by remember { mutableStateOf("") }
        if (copied.isNotEmpty()) {
            Text(copied, fontSize = 12.sp, color = Color(0xFF1E9E6A))
            Spacer(Modifier.height(8.dp))
        }
        algos.forEach { algo ->
            val hex = hashHex(text, algo)
            val ok = t.isNotEmpty() && hex == t
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(CardColor, RoundedCornerShape(12.dp))
                    .tap {
                        clipboard.setText(AnnotatedString(hex))
                        copied = "已复制$algo 结果"
                    }
                    .padding(horizontal = 14.dp, vertical = 10.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(algo, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = MainText, modifier = Modifier.weight(1f))
                    if (ok) {
                        Text("✓ 匹配", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color(0xFF1E9E6A))
                    }
                }
                Spacer(Modifier.height(3.dp))
                Text(hex, fontSize = 12.sp, color = SubText)
            }
            Spacer(Modifier.height(8.dp))
        }
    }
}

fun isTextFile(name: String): Boolean {
    val e = name.substringAfterLast('.', "").lowercase()
    return e in setOf("html", "htm", "txt", "xml", "json", "js", "css", "md", "csv", "log", "ini", "cfg", "conf", "properties", "yml", "yaml", "kt", "java", "py", "sh", "bat", "smali", "mf", "sf", "gradle", "pro", "svg")
}

fun fmtSize(n: Long): String = when {
    n >= 1048576 -> String.format("%.1fMB", n / 1048576.0)
    n >= 1024 -> String.format("%.1fKB", n / 1024.0)
    else -> "${n}B"
}

data class FmEntry(val name: String, val size: Long, val isText: Boolean, val content: ByteArray?)

fun loadZipEntries(file: File): List<FmEntry> {
    val out = mutableListOf<FmEntry>()
    try {
        ZipInputStream(file.inputStream()).use { z ->
            var e = z.nextEntry
            while (e != null) {
                val buf = ByteArrayOutputStream()
                val b = ByteArray(8192)
                while (true) {
                    val n = z.read(b)
                    if (n < 0) break
                    buf.write(b, 0, n)
                }
                val bytes = buf.toByteArray()
                val text = isTextFile(e.name) && bytes.size <= 1048576
                out.add(FmEntry(e.name, bytes.size.toLong(), text, if (text) bytes else null))
                e = z.nextEntry
            }
        }
    } catch (e: Exception) {
    }
    return out
}

fun fmtRemaining(ms: Long): String {
    val s = if (ms < 0) 0 else ms / 1000
    val h = s / 3600
    val m = (s % 3600) / 60
    val sec = s % 60
    return if (h > 0) "%d:%02d:%02d".format(h, m, sec) else "%d:%02d".format(m, sec)
}

fun fmtElapsed(ms: Long): String {
    val s = if (ms < 0) 0 else ms / 1000
    val h = s / 3600
    val m = (s % 3600) / 60
    val sec = s % 60
    return when {
        h > 0 -> "${h}小时${m}分${sec}秒"
        m > 0 -> "${m}分${sec}秒"
        else -> "${sec}秒"
    }
}

fun readCentralNames(file: File): List<String>? {
    return try {
        val raf = java.io.RandomAccessFile(file, "r")
        try {
            val len = file.length()
            if (len < 22) return null
            val tailLen = minOf(len, 65557L)
            raf.seek(len - tailLen)
            val tail = ByteArray(tailLen.toInt())
            raf.readFully(tail)
            var eocd = -1
            var i = tail.size - 22
            while (i >= 0) {
                if (tail[i] == 0x50.toByte() && tail[i + 1] == 0x4B.toByte() && tail[i + 2] == 0x05.toByte() && tail[i + 3] == 0x06.toByte()) {
                    eocd = i
                    break
                }
                i--
            }
            if (eocd < 0) return null
            val count = (tail[eocd + 10].toInt() and 0xFF) or ((tail[eocd + 11].toInt() and 0xFF) shl 8)
            var cdOff = leInt(tail, eocd + 16).toLong() and 0xFFFFFFFFL
            val cdSize = leInt(tail, eocd + 12).toLong() and 0xFFFFFFFFL
            if (cdOff + cdSize > len) return null
            raf.seek(cdOff)
            val cd = ByteArray(cdSize.toInt())
            raf.readFully(cd)
            val out = mutableListOf<String>()
            var p = 0
            var n = 0
            while (p + 46 <= cd.size && n < count) {
                if (cd[p] != 0x50.toByte() || cd[p + 1] != 0x4B.toByte() || cd[p + 2] != 0x01.toByte() || cd[p + 3] != 0x02.toByte()) return null
                val nameLen = leShort(cd, p + 28)
                val extraLen = leShort(cd, p + 30)
                val cmtLen = leShort(cd, p + 32)
                out.add(String(cd, p + 46, nameLen, Charsets.UTF_8))
                p += 46 + nameLen + extraLen + cmtLen
                n++
            }
            if (n != count) return null
            out
        } finally {
            raf.close()
        }
    } catch (e: Exception) {
        null
    }
}

fun listZipNames(file: File, onProgress: ((Long, Long) -> Unit)? = null): List<String> {
    val central = readCentralNames(file)
    if (central != null) {
        onProgress?.invoke(file.length(), file.length())
        return central
    }
    val out = mutableListOf<String>()
    val total = file.length()
    var done = 0L
    val buf = ByteArray(65536)
    try {
        ZipInputStream(file.inputStream().buffered()).use { z ->
            while (true) {
                val e = z.nextEntry ?: break
                out.add(e.name)
                while (true) {
                    val n = z.read(buf)
                    if (n < 0) break
                    done += n
                    onProgress?.invoke(done, total)
                }
            }
        }
    } catch (e: Exception) {
    }
    return out
}

fun rewriteZip(src: File, edits: Map<String, ByteArray?>, out: java.io.OutputStream) {
    ZipOutputStream(out).use { zout ->
        ZipInputStream(src.inputStream()).use { zin ->
            var e = zin.nextEntry
            while (e != null) {
                val rep = edits[e.name]
                if (!edits.containsKey(e.name)) {
                    zout.putNextEntry(ZipEntry(e.name))
                    zin.copyTo(zout)
                    zout.closeEntry()
                } else if (rep != null) {
                    zout.putNextEntry(ZipEntry(e.name))
                    zout.write(rep)
                    zout.closeEntry()
                }
                e = zin.nextEntry
            }
        }
    }
}

fun rewriteZipAdd(src: File, edits: Map<String, ByteArray?>, added: List<Pair<String, ByteArray>>, out: java.io.OutputStream) {
    ZipOutputStream(out).use { zout ->
        ZipInputStream(src.inputStream()).use { zin ->
            var e = zin.nextEntry
            while (e != null) {
                val rep = edits[e.name]
                if (!edits.containsKey(e.name)) {
                    zout.putNextEntry(ZipEntry(e.name))
                    zin.copyTo(zout)
                    zout.closeEntry()
                } else if (rep != null) {
                    zout.putNextEntry(ZipEntry(e.name))
                    zout.write(rep)
                    zout.closeEntry()
                }
                e = zin.nextEntry
            }
        }
        added.forEach { (n, b) ->
            zout.putNextEntry(ZipEntry(n))
            zout.write(b)
            zout.closeEntry()
        }
    }
}

fun fileIcon(name: String): ImageVector {
    if (name.endsWith("/")) return Icons.Filled.Folder
    val n = name.substringAfterLast('/', "").lowercase()
    return when (n.substringAfterLast('.', "")) {
        "dex" -> Icons.Filled.Memory
        "so" -> Icons.Filled.Memory
        "xml", "html", "htm", "json", "js", "css", "txt", "md", "csv", "log", "ini", "cfg", "yml", "yaml", "kt", "java", "py", "sh", "smali" -> Icons.Filled.Description
        "png", "jpg", "jpeg", "webp", "gif" -> Icons.Filled.Photo
        "apk" -> Icons.Filled.Android
        else -> Icons.Filled.InsertDriveFile
    }
}

fun leShort(b: ByteArray, off: Int): Int = (b[off].toInt() and 0xFF) or ((b[off + 1].toInt() and 0xFF) shl 8)

fun leInt(b: ByteArray, off: Int): Int =
    (b[off].toInt() and 0xFF) or ((b[off + 1].toInt() and 0xFF) shl 8) or ((b[off + 2].toInt() and 0xFF) shl 16) or ((b[off + 3].toInt() and 0xFF) shl 24)

fun axmlStringPool(b: ByteArray): List<String> {
    var off = 8
    while (off + 8 <= b.size) {
        val type = leShort(b, off)
        val size = leInt(b, off + 4)
        if (type == 0x0001) {
            val strCount = leInt(b, off + 8)
            val flags = leInt(b, off + 16)
            val strStart = leInt(b, off + 20)
            val utf8 = (flags and 0x100) != 0
            val base = off + strStart
            return (0 until strCount).map { i ->
                try {
                    val p = base + leInt(b, off + 28 + i * 4)
                    if (p < 0 || p >= b.size) ""
                    else if (utf8) {
                        var q = p
                        q += if ((b[q].toInt() and 0x80) != 0) 2 else 1
                        q += if ((b[q].toInt() and 0x80) != 0) 2 else 1
                        var end = q
                        while (end < b.size && b[end].toInt() != 0) end++
                        String(b, q, end - q, Charsets.UTF_8)
                    } else {
                        var q = p
                        q += if ((b[q].toInt() and 0x80) != 0) 4 else 2
                        val sb = StringBuilder()
                        while (q + 1 < b.size && !(b[q].toInt() == 0 && b[q + 1].toInt() == 0)) {
                            sb.append(((b[q].toInt() and 0xFF) or ((b[q + 1].toInt() and 0xFF) shl 8)).toChar())
                            q += 2
                        }
                        sb.toString()
                    }
                } catch (e: Exception) {
                    ""
                }
            }
        }
        if (size <= 0) break
        off += size
    }
    return emptyList()
}

data class ApkManifestInfo(val pkg: String, val versionCode: String, val versionName: String)

fun parseManifestInfo(manifest: ByteArray): ApkManifestInfo? {
    return try {
        val strings = axmlStringPool(manifest)
        var off = 8
        while (off + 8 <= manifest.size) {
            val type = leShort(manifest, off)
            val size = leInt(manifest, off + 4)
            if (type == 0x0102) {
                val nameIdx = leInt(manifest, off + 20)
                val elemName = strings.getOrNull(nameIdx) ?: ""
                if (elemName == "manifest") {
                    val attrStart = leShort(manifest, off + 24)
                    val attrSize = leShort(manifest, off + 26)
                    val attrCount = leShort(manifest, off + 28)
                    var pkg = ""
                    var vCode = ""
                    var vName = ""
                    for (i in 0 until attrCount) {
                        val a = off + 16 + attrStart + i * attrSize
                        if (a + 20 > manifest.size) break
                        val attrName = strings.getOrNull(leInt(manifest, a + 4)) ?: ""
                        val rawValue = leInt(manifest, a + 8)
                        val dataType = manifest[a + 15].toInt() and 0xFF
                        val data = leInt(manifest, a + 16)
                        val value = when (dataType) {
                            0x03 -> strings.getOrNull(rawValue) ?: strings.getOrNull(data) ?: ""
                            0x10 -> data.toString()
                            0x12 -> data.toString()
                            else -> strings.getOrNull(rawValue) ?: ""
                        }
                        when (attrName) {
                            "package" -> pkg = value
                            "versionCode" -> vCode = value
                            "versionName" -> vName = value
                        }
                    }
                    return ApkManifestInfo(pkg, vCode, vName)
                }
            }
            if (size <= 0) break
            off += size
        }
        null
    } catch (e: Exception) {
        null
    }
}

fun findApkIconEntry(entries: List<FmEntry>): FmEntry? {
    val candidates = entries.filter {
        val n = it.name.substringAfterLast('/', "").lowercase()
        (n.startsWith("ic_launcher") || n.contains("icon")) && (n.endsWith(".png") || n.endsWith(".webp") || n.endsWith(".jpg"))
    }
    if (candidates.isNotEmpty()) return candidates.maxByOrNull { it.size }
    return entries.filter { it.name.startsWith("res/") && it.name.substringAfterLast('.', "").lowercase() in setOf("png", "webp", "jpg") }
        .maxByOrNull { it.size }
}

fun readZipEntry(file: File, name: String): ByteArray? {
    return try {
        ZipInputStream(file.inputStream()).use { z ->
            var e = z.nextEntry
            while (e != null) {
                if (e.name == name) {
                    val buf = ByteArrayOutputStream()
                    z.copyTo(buf)
                    return buf.toByteArray()
                }
                e = z.nextEntry
            }
        }
        null
    } catch (e: Exception) {
        null
    }
}

fun dexStrings(file: File, limitBytes: Long = 8L * 1024 * 1024, onProgress: ((Long, Long) -> Unit)? = null): String {
    val sb = StringBuilder()
    val total = file.length()
    var done = 0L
    try {
        ZipInputStream(file.inputStream().buffered()).use { z ->
            var e = z.nextEntry
            while (e != null) {
                if (e.name.endsWith(".dex")) {
                    val buf = ByteArrayOutputStream()
                    val b = ByteArray(1048576)
                    var total2 = 0L
                    while (total2 < limitBytes) {
                        val want = minOf(b.size.toLong(), limitBytes - total2).toInt()
                        val n = z.read(b, 0, want)
                        if (n < 0) break
                        buf.write(b, 0, n)
                        total2 += n
                    }
                    sb.append(String(buf.toByteArray(), Charsets.ISO_8859_1))
                }
                done += e.size.coerceAtLeast(0)
                onProgress?.invoke(done, total)
                e = z.nextEntry
            }
        }
    } catch (e: Exception) {
    }
    return sb.toString()
}

@Composable
fun ModifyFilePage(onClose: () -> Unit) {
    val context = LocalContext.current
    var page by remember { mutableStateOf(0) }
    var pickedFile by remember { mutableStateOf<File?>(null) }
    var pickedName by remember { mutableStateOf("") }
    var jumpMsg by remember { mutableStateOf("") }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            val r = copyUriToCache(context, uri)
            if (r == null) {
                jumpMsg = "读取文件失败，请重试"
            } else {
                pickedFile = r.first
                pickedName = r.second
                page = 1
            }
        }
    }
    ToolDialog(title = "修改文件", onClose = onClose) {
        Text("支持 APK、HTML、TXT 等各类文件", fontSize = 13.sp, color = SubText)
        Spacer(Modifier.height(12.dp))
        Button(
            onClick = { picker.launch("*/*") },
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(14.dp),
            colors = ButtonDefaults.buttonColors(containerColor = AccentColor)
        ) {
            Text("选择文件", fontSize = 16.sp, fontWeight = FontWeight.Bold)
        }
        if (jumpMsg.isNotEmpty()) {
            Spacer(Modifier.height(12.dp))
            Text(jumpMsg, fontSize = 13.sp, color = Color(0xFFD0453E), modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
        }
    }
    if (page == 1 && pickedFile != null) {
        if (pickedFile!!.extension.lowercase() == "apk") {
            ZipEditorPage(file = pickedFile!!, name = pickedName, onClose = { pickedFile?.delete(); pickedFile = null; page = 0 })
        } else if (isTextFile(pickedName)) {
            TextEditorPage(file = pickedFile!!, name = pickedName, onClose = { pickedFile?.delete(); pickedFile = null; page = 0 })
        } else {
            BinaryPage(file = pickedFile!!, name = pickedName, onClose = { pickedFile?.delete(); pickedFile = null; page = 0 })
        }
    }
}

@Composable
fun ModifyAppPage(onClose: () -> Unit) {
    val context = LocalContext.current
    var pickedFile by remember { mutableStateOf<File?>(null) }
    var pickedName by remember { mutableStateOf("") }
    var jumpMsg by remember { mutableStateOf("") }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            val r = copyUriToCache(context, uri)
            if (r == null) {
                jumpMsg = "读取文件失败，请重试"
            } else if (!r.second.endsWith(".apk", true)) {
                jumpMsg = "只能上传 APK 文件"
            } else {
                pickedFile = r.first
                pickedName = r.second
                jumpMsg = ""
            }
        }
    }
    ToolDialog(title = "修改应用", onClose = onClose) {
        Text("只能上传 APK 文件，可修改包内文件并导出", fontSize = 13.sp, color = SubText)
        Spacer(Modifier.height(12.dp))
        Button(
            onClick = { picker.launch("application/vnd.android.package-archive") },
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(14.dp),
            colors = ButtonDefaults.buttonColors(containerColor = AccentColor)
        ) {
            Text("选择 APK 文件", fontSize = 16.sp, fontWeight = FontWeight.Bold)
        }
        if (jumpMsg.isNotEmpty()) {
            Spacer(Modifier.height(12.dp))
            Text(jumpMsg, fontSize = 13.sp, color = Color(0xFFD0453E), modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
        }
    }
    if (pickedFile != null) {
        ZipEditorPage(file = pickedFile!!, name = pickedName, onClose = { pickedFile?.delete(); pickedFile = null }, funcName = "修改应用")
    }
}

fun copyUriToCache(context: Context, uri: android.net.Uri, onProgress: ((Long, Long) -> Unit)? = null): Pair<File, String>? {
    return try {
        var name = "file"
        var total = -1L
        context.contentResolver.query(uri, null, null, null, null)?.use { c ->
            if (c.moveToFirst()) {
                val idx = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (idx >= 0) name = c.getString(idx) ?: "file"
                val szIdx = c.getColumnIndex(OpenableColumns.SIZE)
                if (szIdx >= 0) total = c.getLong(szIdx)
            }
        }
        val f = File(context.cacheDir, "fm_" + System.currentTimeMillis() + "_" + name)
        var written = 0L
        context.contentResolver.openInputStream(uri)?.use { input ->
            f.outputStream().buffered().use { output ->
                val buf = ByteArray(1048576)
                while (true) {
                    val n = input.read(buf)
                    if (n < 0) break
                    output.write(buf, 0, n)
                    written += n
                    onProgress?.invoke(written, total)
                }
            }
        }
        f to name
    } catch (e: Exception) {
        null
    }
}

fun cleanTempFiles(context: Context) {
    val dir = context.cacheDir
    val files = dir.listFiles() ?: return
    for (f in files) {
        if (f.name == "fi_result.apk") continue
        if (f.name.startsWith("fm_") || f.name.startsWith("fi_") || f.name.startsWith("raw_") || f.name.startsWith("arsc_")) f.delete()
    }
}

fun fiResultFile(context: Context): File = File(context.cacheDir, "fi_result.apk")

fun fiResultName(context: Context): String =
    context.getSharedPreferences("fi_result", Context.MODE_PRIVATE).getString("name", "安装包.apk") ?: "安装包.apk"

fun setFiResultName(context: Context, name: String) {
    context.getSharedPreferences("fi_result", Context.MODE_PRIVATE).edit().putString("name", name).apply()
}

data class HistoryEntry(val id: Long, val func: String, val premium: Boolean, val time: String, val detail: String)

fun historyLimit(context: Context): Int = if (isPremium(context)) 10000 else 4

fun loadHistory(context: Context): List<HistoryEntry> {
    val raw = currentAccountPrefs(context).getString("history", "") ?: ""
    if (raw.isBlank()) return emptyList()
    return try {
        val arr = org.json.JSONArray(raw)
        (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            HistoryEntry(o.getLong("id"), o.getString("func"), o.getBoolean("premium"), o.getString("time"), o.getString("detail"))
        }
    } catch (e: Exception) {
        emptyList()
    }
}

fun saveHistory(context: Context, list: List<HistoryEntry>) {
    val arr = org.json.JSONArray()
    list.forEach { e ->
        arr.put(org.json.JSONObject().put("id", e.id).put("func", e.func).put("premium", e.premium).put("time", e.time).put("detail", e.detail))
    }
    currentAccountPrefs(context).edit().putString("history", arr.toString()).apply()
}

fun addHistory(context: Context, func: String, detail: String) {
    val list = loadHistory(context)
    val entry = HistoryEntry(
        System.currentTimeMillis(),
        func,
        isPremium(context),
        java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", java.util.Locale.CHINA).format(java.util.Date()),
        detail
    )
    val out = list + entry
    val limit = historyLimit(context)
    saveHistory(context, if (out.size > limit) out.drop(out.size - limit) else out)
}

fun deleteHistory(context: Context, id: Long) {
    saveHistory(context, loadHistory(context).filterNot { it.id == id })
}

fun digestFile(file: File, algo: String): String {
    val md = MessageDigest.getInstance(algo)
    file.inputStream().use { input ->
        val buf = ByteArray(8192)
        while (true) {
            val n = input.read(buf)
            if (n < 0) break
            md.update(buf, 0, n)
        }
    }
    return md.digest().joinToString("") { "%02x".format(it) }
}

fun extractPermissions(manifest: ByteArray): List<String> {
    val s = String(manifest, Charsets.ISO_8859_1)
    return Regex("android\\.permission\\.[A-Z0-9_]+").findAll(s).map { it.value }.distinct().sorted().toList()
}

fun hasV2Signature(file: File, onProgress: ((Long, Long) -> Unit)? = null): Boolean {
    return try {
        val len = file.length()
        val tailLen = minOf(len, 16L * 1024 * 1024)
        val raf = java.io.RandomAccessFile(file, "r")
        try {
            raf.seek(len - tailLen)
            val buf = ByteArray(65536)
            var done = 0L
            var carry = ""
            while (done < tailLen) {
                val want = minOf(buf.size.toLong(), tailLen - done).toInt()
                val n = raf.read(buf, 0, want)
                if (n < 0) break
                done += n
                onProgress?.invoke(len, len)
                val s = carry + String(buf, 0, n, Charsets.ISO_8859_1)
                if (s.contains("APK Sig Block 42")) return true
                carry = if (s.length > 20) s.substring(s.length - 20) else s
            }
            false
        } finally {
            raf.close()
        }
    } catch (e: Exception) {
        false
    }
}

fun permissionDesc(p: String): String {
    val short = p.removePrefix("android.permission.")
    val map = mapOf(
        "INTERNET" to "访问网络",
        "ACCESS_NETWORK_STATE" to "查看网络状态",
        "ACCESS_WIFI_STATE" to "查看WiFi状态",
        "WRITE_EXTERNAL_STORAGE" to "写入存储",
        "READ_EXTERNAL_STORAGE" to "读取存储",
        "READ_MEDIA_IMAGES" to "读取照片",
        "READ_MEDIA_VIDEO" to "读取视频",
        "READ_MEDIA_AUDIO" to "读取音频",
        "CAMERA" to "使用相机",
        "RECORD_AUDIO" to "录音",
        "ACCESS_FINE_LOCATION" to "精确定位",
        "ACCESS_COARSE_LOCATION" to "大致定位",
        "READ_PHONE_STATE" to "读取手机状态",
        "CALL_PHONE" to "拨打电话",
        "SEND_SMS" to "发送短信",
        "READ_SMS" to "读取短信",
        "RECEIVE_SMS" to "接收短信",
        "READ_CONTACTS" to "读取联系人",
        "WRITE_CONTACTS" to "写入联系人",
        "REQUEST_INSTALL_PACKAGES" to "安装应用",
        "QUERY_ALL_PACKAGES" to "查看全部应用",
        "FOREGROUND_SERVICE" to "前台服务",
        "POST_NOTIFICATIONS" to "发送通知",
        "VIBRATE" to "振动",
        "WAKE_LOCK" to "保持唤醒",
        "BLUETOOTH" to "蓝牙",
        "BLUETOOTH_CONNECT" to "连接蓝牙",
        "NFC" to "近场通信",
        "USE_FINGERPRINT" to "指纹识别",
        "USE_BIOMETRIC" to "生物识别"
    )
    return map[short] ?: "未知权限"
}

@Composable
fun ApkAnalysisPage(onClose: () -> Unit) {
    val context = LocalContext.current
    var file by remember { mutableStateOf<File?>(null) }
    var name by remember { mutableStateOf("") }
    var jumpMsg by remember { mutableStateOf("") }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            val r = copyUriToCache(context, uri)
            if (r == null) {
                jumpMsg = "读取文件失败，请重试"
            } else if (!r.second.endsWith(".apk", true)) {
                jumpMsg = "只能上传 APK 文件"
            } else {
                file = r.first
                name = r.second
                jumpMsg = ""
            }
        }
    }
    ToolDialog(title = "分析APK", onClose = onClose) {
        Text("选择 APK，拆包查看权限、签名等信息", fontSize = 13.sp, color = SubText)
        Spacer(Modifier.height(12.dp))
        Button(
            onClick = { picker.launch("application/vnd.android.package-archive") },
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(14.dp),
            colors = ButtonDefaults.buttonColors(containerColor = AccentColor)
        ) {
            Text("选择 APK 文件", fontSize = 16.sp, fontWeight = FontWeight.Bold)
        }
        if (jumpMsg.isNotEmpty()) {
            Spacer(Modifier.height(12.dp))
            Text(jumpMsg, fontSize = 13.sp, color = Color(0xFFD0453E), modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
        }
    }
    LaunchedEffect(file) {
        if (file != null) addHistory(context, "分析APK", "文件：$name\n已解析包内信息")
    }
    if (file != null) {
        ApkInfoPage(file = file!!, name = name, onClose = { file?.delete(); file = null })
    }
}

@Composable
fun SectionCard(title: String, content: @Composable ColumnScope.() -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(CardColor, RoundedCornerShape(12.dp))
            .padding(horizontal = 14.dp, vertical = 10.dp)
    ) {
        Text(title, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = MainText)
        Spacer(Modifier.height(6.dp))
        content()
    }
    Spacer(Modifier.height(8.dp))
}

@Composable
fun ApkInfoPage(file: File, name: String, onClose: () -> Unit) {
    val clipboard = LocalClipboardManager.current
    val entries = remember(file) { loadZipEntries(file) }
    val md5 = remember(file) { digestFile(file, "MD5") }
    val sha256 = remember(file) { digestFile(file, "SHA-256") }
    val manifest = remember(file) { entries.firstOrNull { it.name == "AndroidManifest.xml" }?.content }
    val permissions = remember(file) { manifest?.let { extractPermissions(it) } ?: emptyList() }
    val v1 = remember(file) { entries.any { it.name.startsWith("META-INF/") && (it.name.endsWith(".RSA") || it.name.endsWith(".DSA") || it.name.endsWith(".EC")) } }
    val v2 = remember(file) { hasV2Signature(file) }
    val cats = remember(file) {
        val d = entries.count { it.name.endsWith(".dex") }
        val so = entries.count { it.name.endsWith(".so") }
        val res = entries.count { it.name.startsWith("res/") }
        val assets = entries.count { it.name.startsWith("assets/") }
        val meta = entries.count { it.name.startsWith("META-INF/") }
        listOf(
            "dex 代码：${d} 个",
            "so 库：${so} 个",
            "res 资源：${res} 个",
            "assets 资源：${assets} 个",
            "META-INF：${meta} 个",
            "其他：${entries.size - d - so - res - assets - meta} 个"
        )
    }
    ToolDialog(title = name, onClose = onClose) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .heightIn(max = 400.dp)
                .verticalScroll(rememberScrollState())
        ) {
            SectionCard("基本信息") {
                InfoRow("文件名", name)
                InfoRow("大小", fmtSize(file.length()))
                InfoRow("文件数", "${entries.size} 个")
            }
            SectionCard("校验值（点击复制）") {
                CopyRow(clipboard, "MD5", md5)
                CopyRow(clipboard, "SHA-256", sha256)
            }
            SectionCard("签名") {
                Text("v1 签名：${if (v1) "有" else "无"}", fontSize = 13.sp, color = SubText)
                Spacer(Modifier.height(3.dp))
                Text("v2/v3 签名：${if (v2) "有" else "无"}", fontSize = 13.sp, color = SubText)
                Spacer(Modifier.height(3.dp))
                Text("修改后未重新签名的包会显示 v1/v2 均无", fontSize = 11.sp, color = Color(0xFFB07A1E))
            }
            SectionCard("权限（${permissions.size}）") {
                if (permissions.isEmpty()) {
                    Text("未在清单中找到权限声明", fontSize = 13.sp, color = SubText)
                } else {
                    permissions.forEach { p ->
                        Text("· $p", fontSize = 12.sp, color = MainText)
                        Text("  ${permissionDesc(p)}", fontSize = 11.sp, color = SubText)
                        Spacer(Modifier.height(4.dp))
                    }
                }
            }
            SectionCard("拆包统计") {
                cats.forEach {
                    Text(it, fontSize = 12.sp, color = SubText)
                    Spacer(Modifier.height(3.dp))
                }
            }
            SectionCard("包内文件（点击复制路径）") {
                entries.forEach { e ->
                    Text(
                        "${e.name}（${fmtSize(e.size)}）",
                        fontSize = 11.sp,
                        color = SubText,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier
                            .fillMaxWidth()
                            .tap {
                                clipboard.setText(AnnotatedString(e.name))
                            }
                    )
                    Spacer(Modifier.height(3.dp))
                }
            }
        }
    }
}

@Composable
fun InfoRow(label: String, value: String) {
    Row(Modifier.fillMaxWidth()) {
        Text("$label：", fontSize = 13.sp, color = SubText)
        Text(value, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = MainText, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
    Spacer(Modifier.height(3.dp))
}

@Composable
fun CopyRow(clipboard: ClipboardManager, label: String, value: String) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .tap { clipboard.setText(AnnotatedString(value)) }
    ) {
        Text("$label：$value", fontSize = 12.sp, color = SubText, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
    Spacer(Modifier.height(3.dp))
}

@Composable
fun PremiumModPage(onClose: () -> Unit) {
    val context = LocalContext.current
    var pickedFile by remember { mutableStateOf<File?>(null) }
    var pickedName by remember { mutableStateOf("") }
    var jumpMsg by remember { mutableStateOf("") }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            val r = copyUriToCache(context, uri)
            if (r == null) {
                jumpMsg = "读取文件失败，请重试"
            } else if (!r.second.endsWith(".apk", true)) {
                jumpMsg = "只能上传 APK 文件"
            } else {
                pickedFile = r.first
                pickedName = r.second
                jumpMsg = ""
            }
        }
    }
    ToolDialog(title = "修改文件", onClose = onClose) {
        Text("上传 APK，像 MT 管理器一样查看、删改、添加包内文件", fontSize = 13.sp, color = SubText)
        Spacer(Modifier.height(12.dp))
        Button(
            onClick = { picker.launch("application/vnd.android.package-archive") },
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(14.dp),
            colors = ButtonDefaults.buttonColors(containerColor = AccentColor)
        ) {
            Text("选择 APK 文件", fontSize = 16.sp, fontWeight = FontWeight.Bold)
        }
        if (jumpMsg.isNotEmpty()) {
            Spacer(Modifier.height(12.dp))
            Text(jumpMsg, fontSize = 13.sp, color = Color(0xFFD0453E), modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
        }
    }
    if (pickedFile != null) {
        PremiumZipEditor(file = pickedFile!!, name = pickedName, onClose = { pickedFile?.delete(); pickedFile = null })
    }
}

@Composable
fun PremiumZipEditor(file: File, name: String, onClose: () -> Unit) {
    val context = LocalContext.current
    var entries by remember(file) { mutableStateOf(loadZipEntries(file)) }
    val edits = remember(file) { mutableStateMapOf<String, ByteArray?>() }
    val added = remember(file) { mutableStateListOf<Pair<String, ByteArray>>() }
    var editing by remember { mutableStateOf<FmEntry?>(null) }
    var adding by remember { mutableStateOf<ByteArray?>(null) }
    var addPath by remember { mutableStateOf("") }
    var jumpMsg by remember { mutableStateOf("") }
    val addPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            try {
                val bytes = context.contentResolver.openInputStream(uri)?.use { it.readBytes() }
                if (bytes == null) {
                    jumpMsg = "读取文件失败，请重试"
                } else {
                    var fn = "file"
                    context.contentResolver.query(uri, null, null, null, null)?.use { c ->
                        if (c.moveToFirst()) {
                            val idx = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                            if (idx >= 0) fn = c.getString(idx) ?: "file"
                        }
                    }
                    addPath = fn
                    adding = bytes
                }
            } catch (e: Exception) {
                jumpMsg = "读取文件失败，请重试"
            }
        }
    }
    val export = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/octet-stream")) { uri ->
        if (uri != null) {
            jumpMsg = try {
                context.contentResolver.openOutputStream(uri)?.use { rewriteZipAdd(file, edits, added.toList(), it) }
                addHistory(context, "修改文件", "文件：$name\n已导出修改后的文件（改动 ${edits.size} 处，新增 ${added.size} 个）")
                "已导出修改后的文件"
            } catch (e: Exception) {
                "导出失败，请重试"
            }
        }
    }
    ToolDialog(title = name, onClose = onClose) {
        Text("共 ${entries.size + added.size} 个文件，已改动 ${edits.size} 处，已添加 ${added.size} 个", fontSize = 13.sp, color = SubText)
        if (jumpMsg.isNotEmpty()) {
            Spacer(Modifier.height(8.dp))
            Text(jumpMsg, fontSize = 12.sp, color = Color(0xFF1E9E6A))
        }
        Spacer(Modifier.height(10.dp))
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .heightIn(max = 300.dp)
                .verticalScroll(rememberScrollState())
        ) {
            added.forEach { (n, b) ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color(0xFFEAF3FF), RoundedCornerShape(12.dp))
                        .padding(horizontal = 14.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(fileIcon(n), contentDescription = null, tint = AccentColor, modifier = Modifier.size(22.dp))
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) {
                        Text(n, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = MainText, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text("新增 ${fmtSize(b.size.toLong())}", fontSize = 11.sp, color = AccentColor)
                    }
                    Icon(Icons.Filled.Close, contentDescription = "移除", tint = Color(0xFFD0453E), modifier = Modifier.size(20.dp).tap {
                        added.removeAll { it.first == n }
                    })
                }
                Spacer(Modifier.height(6.dp))
            }
            entries.forEach { e ->
                val changed = edits.containsKey(e.name)
                val deleted = changed && edits[e.name] == null
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(CardColor, RoundedCornerShape(12.dp))
                        .tap { editing = e }
                        .padding(horizontal = 14.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(fileIcon(e.name), contentDescription = null, tint = if (deleted) SubText else AccentColor, modifier = Modifier.size(22.dp))
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) {
                        Text(
                            e.name,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (deleted) SubText else MainText,
                            textDecoration = if (deleted) TextDecoration.LineThrough else null,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Spacer(Modifier.height(2.dp))
                        Text(
                            if (changed) (if (deleted) "已删除" else "已修改") else fmtSize(e.size),
                            fontSize = 11.sp,
                            color = if (changed) Color(0xFF1E9E6A) else SubText
                        )
                    }
                    Icon(Icons.Filled.ChevronRight, contentDescription = null, tint = SubText)
                }
                Spacer(Modifier.height(6.dp))
            }
        }
        Spacer(Modifier.height(10.dp))
        Row(modifier = Modifier.fillMaxWidth()) {
            Button(
                onClick = { addPicker.launch("*/*") },
                modifier = Modifier.weight(1f),
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E9E6A))
            ) {
                Text("添加文件", fontSize = 14.sp, fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.width(10.dp))
            Button(
                onClick = { export.launch(name) },
                modifier = Modifier.weight(1f),
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(containerColor = AccentColor)
            ) {
                Text("导出修改后的文件", fontSize = 14.sp, fontWeight = FontWeight.Bold)
            }
        }
        Spacer(Modifier.height(6.dp))
        Text("修改后的 APK 需重新签名才能安装", fontSize = 12.sp, color = Color(0xFFB07A1E))
    }
    if (editing != null) {
        val target = editing!!
        EntryEditDialog(
            entry = target,
            current = edits[target.name],
            onDismiss = { editing = null },
            onSave = { bytes ->
                edits[target.name] = bytes
                editing = null
            },
            onDelete = {
                edits[target.name] = null
                editing = null
            }
        )
    }
    if (adding != null) {
        AlertDialog(
            onDismissRequest = { adding = null },
            title = { Text("添加到包内", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = MainText) },
            text = {
                Column {
                    Text("填写在包内的完整路径（含文件名）", fontSize = 12.sp, color = SubText)
                    Spacer(Modifier.height(8.dp))
                    BasicTextField(
                        value = addPath,
                        onValueChange = { addPath = it },
                        textStyle = TextStyle(fontSize = 13.sp, color = MainText),
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(BgColor, RoundedCornerShape(10.dp))
                            .padding(10.dp)
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    val p = addPath.trim()
                    if (p.isNotEmpty()) {
                        added.add(p to adding!!)
                        adding = null
                    }
                }) { Text("添加", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = AccentColor) }
            },
            dismissButton = {
                TextButton(onClick = { adding = null }) { Text("取消", fontSize = 14.sp, color = SubText) }
            }
        )
    }
}

@Composable
fun PremiumAppInfoPage(onClose: () -> Unit) {
    val context = LocalContext.current
    var file by remember { mutableStateOf<File?>(null) }
    var name by remember { mutableStateOf("") }
    var jumpMsg by remember { mutableStateOf("") }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            val r = copyUriToCache(context, uri)
            if (r == null) {
                jumpMsg = "读取文件失败，请重试"
            } else if (!r.second.endsWith(".apk", true)) {
                jumpMsg = "只能上传 APK 文件"
            } else {
                file = r.first
                name = r.second
                jumpMsg = ""
            }
        }
    }
    LaunchedEffect(file) {
        if (file != null) addHistory(context, "应用信息", "文件：$name\n已解析图标、包名、版本号与大小")
    }
    ToolDialog(title = "应用信息", onClose = onClose) {
        Text("上传 APK，查看图标、包名、版本号、内版本和大小", fontSize = 13.sp, color = SubText)
        Spacer(Modifier.height(12.dp))
        Button(
            onClick = { picker.launch("application/vnd.android.package-archive") },
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(14.dp),
            colors = ButtonDefaults.buttonColors(containerColor = AccentColor)
        ) {
            Text("选择 APK 文件", fontSize = 16.sp, fontWeight = FontWeight.Bold)
        }
        if (jumpMsg.isNotEmpty()) {
            Spacer(Modifier.height(12.dp))
            Text(jumpMsg, fontSize = 13.sp, color = Color(0xFFD0453E), modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
        }
    }
    if (file != null) {
        val f = file!!
        val entries = remember(f) { loadZipEntries(f) }
        val info = remember(f) { entries.firstOrNull { it.name == "AndroidManifest.xml" }?.content?.let { parseManifestInfo(it) } }
        val iconEntry = remember(entries) { findApkIconEntry(entries) }
        val iconBitmap = remember(f, iconEntry) {
            iconEntry?.let { readZipEntry(f, it.name) }?.let { b ->
                try {
                    BitmapFactory.decodeByteArray(b, 0, b.size)
                } catch (e: Exception) {
                    null
                }
            }
        }
        ToolDialog(title = name, onClose = { file?.delete(); file = null; onClose() }) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
            ) {
                SectionCard("应用图标") {
                    if (iconBitmap != null) {
                        Image(
                            bitmap = iconBitmap.asImageBitmap(),
                            contentDescription = "应用图标",
                            modifier = Modifier.size(64.dp)
                        )
                    } else {
                        Text("未在包内找到可用图标", fontSize = 13.sp, color = SubText)
                    }
                }
                SectionCard("应用信息") {
                    InfoRow("文件名", name)
                    InfoRow("大小", fmtSize(f.length()))
                    InfoRow("包名", info?.pkg?.ifEmpty { "未解析到" } ?: "未解析到")
                    InfoRow("版本号", info?.versionName?.ifEmpty { "未解析到" } ?: "未解析到")
                    InfoRow("内版本", info?.versionCode?.ifEmpty { "未解析到" } ?: "未解析到")
                    InfoRow("文件数", "${entries.size} 个")
                }
            }
        }
    }
}

@Composable
fun PremiumSecurityPage(onClose: () -> Unit) {
    val context = LocalContext.current
    var file by remember { mutableStateOf<File?>(null) }
    var name by remember { mutableStateOf("") }
    var jumpMsg by remember { mutableStateOf("") }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            val r = copyUriToCache(context, uri)
            if (r == null) {
                jumpMsg = "读取文件失败，请重试"
            } else if (!r.second.endsWith(".apk", true)) {
                jumpMsg = "只能上传 APK 文件"
            } else {
                file = r.first
                name = r.second
                jumpMsg = ""
            }
        }
    }
    LaunchedEffect(file) {
        if (file != null) addHistory(context, "安全检测", "文件：$name\n已完成哈希、应用密码、防改代码与破解难度检测")
    }
    ToolDialog(title = "安全检测", onClose = onClose) {
        Text("上传 APK，检测哈希、应用密码、防改代码与破解难度", fontSize = 13.sp, color = SubText)
        Spacer(Modifier.height(12.dp))
        Button(
            onClick = { picker.launch("application/vnd.android.package-archive") },
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(14.dp),
            colors = ButtonDefaults.buttonColors(containerColor = AccentColor)
        ) {
            Text("选择 APK 文件", fontSize = 16.sp, fontWeight = FontWeight.Bold)
        }
        if (jumpMsg.isNotEmpty()) {
            Spacer(Modifier.height(12.dp))
            Text(jumpMsg, fontSize = 13.sp, color = Color(0xFFD0453E), modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
        }
    }
    if (file != null) {
        val f = file!!
        val clipboard = LocalClipboardManager.current
        val entries = remember(f) { loadZipEntries(f) }
        val md5 = remember(f) { digestFile(f, "MD5") }
        val sha1 = remember(f) { digestFile(f, "SHA-1") }
        val sha256 = remember(f) { digestFile(f, "SHA-256") }
        val v1 = remember(f) { entries.any { it.name.startsWith("META-INF/") && (it.name.endsWith(".RSA") || it.name.endsWith(".DSA") || it.name.endsWith(".EC")) } }
        val v2 = remember(f) { hasV2Signature(f) }
        val dex = remember(f) { dexStrings(f) }
        val foundHash = remember(dex) { listOf("MD5", "SHA-1", "SHA-256", "SHA-512").filter { dex.contains(it) } }
        val pwdKeys = listOf("password", "passwd", "pwd", "secret", "token", "api_key", "apikey", "app_secret")
        val foundPwd = remember(dex) { pwdKeys.filter { dex.contains(it, ignoreCase = true) } }
        val tamperKeys = listOf("getPackageInfo", "signatures", "GET_SIGNATURES", "checkSignature", "isSignatureValid", "PackageInfo")
        val foundTamper = remember(dex) { tamperKeys.filter { dex.contains(it) } }
        val dialogKeys = listOf("AlertDialog", "DialogInterface", "Toast", "BottomSheetDialog")
        val foundDialog = remember(dex) { dialogKeys.filter { dex.contains(it) } }
        val verdict = remember(v1, v2, foundTamper) {
            when {
                !v1 && !v2 -> "该包未签名或签名已失效，包内文件可随意修改后直接使用，防护已不存在"
                foundTamper.isEmpty() -> "未检测到防改校验代码，修改包内文件后重新签名即可绕过，容易破解"
                else -> "检测到防改校验代码，修改后会被识别，有一定防护；但防改代码仍可能被定位移除，无法完全防破解"
            }
        }
        ToolDialog(title = name, onClose = { file?.delete(); file = null; onClose() }) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 400.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                SectionCard("哈希值（点击复制）") {
                    CopyRow(clipboard, "MD5", md5)
                    CopyRow(clipboard, "SHA-1", sha1)
                    CopyRow(clipboard, "SHA-256", sha256)
                }
                SectionCard("哈希函数") {
                    if (foundHash.isEmpty()) {
                        Text("未在代码中检测到哈希函数调用", fontSize = 13.sp, color = SubText)
                    } else {
                        Text("代码中使用了以下哈希函数：", fontSize = 13.sp, color = MainText)
                        Spacer(Modifier.height(4.dp))
                        foundHash.forEach {
                            Text("· $it", fontSize = 12.sp, color = SubText)
                            Spacer(Modifier.height(3.dp))
                        }
                    }
                }
                SectionCard("哈希校验") {
                    Text("v1 签名：${if (v1) "有" else "无"}", fontSize = 13.sp, color = SubText)
                    Text("v2/v3 签名：${if (v2) "有" else "无"}", fontSize = 13.sp, color = SubText)
                    Spacer(Modifier.height(4.dp))
                    Text(
                        if (foundHash.isEmpty()) "未检测到哈希校验逻辑" else "检测到哈希校验相关代码（${foundHash.joinToString("、")}），包内可能存在完整性校验",
                        fontSize = 12.sp,
                        color = Color(0xFFB07A1E)
                    )
                }
                SectionCard("应用密码") {
                    if (foundPwd.isEmpty()) {
                        Text("未在代码中检测到密码类字段", fontSize = 13.sp, color = SubText)
                    } else {
                        Text("代码中出现以下密码类字段（明文存在于包内）：", fontSize = 13.sp, color = MainText)
                        Spacer(Modifier.height(4.dp))
                        foundPwd.forEach {
                            Text("· $it", fontSize = 12.sp, color = Color(0xFFD0453E))
                            Spacer(Modifier.height(3.dp))
                        }
                    }
                }
                SectionCard("防改代码") {
                    Text(
                        if (foundTamper.isEmpty()) "未检测到防改校验代码" else "检测到防改校验代码（${foundTamper.joinToString("、")}）",
                        fontSize = 13.sp,
                        color = if (foundTamper.isEmpty()) SubText else Color(0xFF1E9E6A)
                    )
                }
                SectionCard("弹窗") {
                    Text(
                        if (foundDialog.isEmpty()) "未检测到弹窗相关代码" else "检测到弹窗相关代码（${foundDialog.joinToString("、")}）",
                        fontSize = 13.sp,
                        color = SubText
                    )
                }
                SectionCard("能否破解") {
                    Text(verdict, fontSize = 13.sp, color = MainText)
                }
                SectionCard("文件数量") {
                    InfoRow("总文件数", "${entries.size} 个")
                }
            }
        }
    }
}

@Composable
fun ForceInstallPage(onClose: () -> Unit) {
    val context = LocalContext.current
    val premium = remember { isPremium(context) }
    var phase by remember { mutableStateOf(0) }
    var status by remember { mutableStateOf("") }
    var jumpMsg by remember { mutableStateOf("") }
    var installMsg by remember { mutableStateOf("") }
    var pickedFile by remember { mutableStateOf<File?>(null) }
    var pickedName by remember { mutableStateOf("") }
    var fixedFile by remember { mutableStateOf<File?>(null) }
    var fixedCount by remember { mutableStateOf(0) }
    var resultItems by remember { mutableStateOf(listOf<Pair<String, String>>()) }
    var uploading by remember { mutableStateOf(false) }
    var progDone by remember { mutableStateOf(0L) }
    var progTotal by remember { mutableStateOf(0L) }
    var progStart by remember { mutableStateOf(0L) }
    var progActive by remember { mutableStateOf(false) }
    var etaText by remember { mutableStateOf("") }
    var workStart by remember { mutableStateOf(0L) }
    var workElapsed by remember { mutableStateOf(0L) }
    var packMsg by remember { mutableStateOf("") }
    var packing by remember { mutableStateOf(false) }
    var installing by remember { mutableStateOf(false) }
    var resumeName by remember { mutableStateOf("") }
    val scope = rememberCoroutineScope()
    val limitBytes = (5.01 * 1024L * 1024L * 1024L).toDouble().toLong()
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            uploading = true
            jumpMsg = ""
            fiResultFile(context).delete()
            resumeName = ""
            scope.launch {
                val pre = withContext(Dispatchers.IO) {
                    var sz = -1L
                    try {
                        context.contentResolver.query(uri, null, null, null, null)?.use { c ->
                            if (c.moveToFirst()) {
                                val i = c.getColumnIndex(OpenableColumns.SIZE)
                                if (i >= 0) sz = c.getLong(i)
                            }
                        }
                    } catch (e: Exception) {
                    }
                    sz to android.os.StatFs(context.cacheDir.path).availableBytes
                }
                val need = if (pre.first > 0) pre.first * 3 else 0L
                if (need > 0 && pre.second < need) {
                    jumpMsg = "手机存储空间不足：处理该文件需要约 ${fmtSize(need)} 可用空间，当前仅 ${fmtSize(pre.second)}，已取消上传"
                    uploading = false
                } else {
                    progDone = 0
                    progTotal = if (pre.first > 0) pre.first else 0
                    progStart = System.currentTimeMillis()
                    workStart = System.currentTimeMillis()
                    workElapsed = 0
                    packMsg = ""
                    progActive = true
                    val r = try {
                        withContext(Dispatchers.IO) { copyUriToCache(context, uri) { d, t -> progDone = d; progTotal = t } }
                    } catch (e: Throwable) {
                        null
                    }
                    progActive = false
                    if (r == null) {
                        jumpMsg = "读取文件失败，请重试"
                    } else if (!r.second.endsWith(".apk", true)) {
                        r.first.delete()
                        jumpMsg = "只能上传 APK 文件"
                    } else if (!premium && r.first.length() > limitBytes) {
                        r.first.delete()
                        jumpMsg = "免费版最大支持 5.01GB，该文件过大，已取消上传；开通高级版可解除限制"
                    } else {
                        installMsg = ""
                        pickedFile = r.first
                        pickedName = r.second
                        phase = 1
                    }
                    uploading = false
                }
            }
        }
    }
    DisposableEffect(Unit) {
        val receiver = object : BroadcastReceiver() {
            override fun onReceive(c: Context, i: Intent) {
                val s = i.getIntExtra(android.content.pm.PackageInstaller.EXTRA_STATUS, -1)
                installMsg = when (s) {
                    android.content.pm.PackageInstaller.STATUS_PENDING_USER_ACTION -> {
                        val confirm = i.getParcelableExtra<Intent>(Intent.EXTRA_INTENT)
                        if (confirm != null) {
                            confirm.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            c.startActivity(confirm)
                        }
                        "请在弹出的安装界面点击确认，即可强制安装"
                    }
                    android.content.pm.PackageInstaller.STATUS_SUCCESS -> {
                        fixedFile?.delete()
                        fixedFile = null
                        fiResultFile(context).delete()
                        resumeName = ""
                        "安装完成，可以打开应用了"
                    }
                    else -> "安装未完成：" + (i.getStringExtra(android.content.pm.PackageInstaller.EXTRA_STATUS_MESSAGE) ?: "系统取消了安装")
                }
            }
        }
        ContextCompat.registerReceiver(context, receiver, IntentFilter("com.hairplnmo.app.FORCE_INSTALL"), ContextCompat.RECEIVER_NOT_EXPORTED)
        onDispose { context.unregisterReceiver(receiver) }
    }
    LaunchedEffect(Unit) {
        val rf = fiResultFile(context)
        if (rf.exists() && rf.length() > 0L) resumeName = fiResultName(context)
    }
    LaunchedEffect(phase, uploading, progActive) {
        while (uploading || progActive) {
            etaText = if (progTotal > 0 && progDone > 0) {
                val elapsed = System.currentTimeMillis() - progStart
                "剩余时间: " + fmtRemaining((progTotal - progDone) * elapsed / progDone)
            } else {
                "剩余时间: 计算中...."
            }
            delay(1000)
        }
        etaText = ""
    }
    LaunchedEffect(phase, pickedFile) {
        if (phase == 1 && pickedFile != null) {
            val f = pickedFile!!
            val results = mutableListOf<Pair<String, String>>()
            suspend fun <T> withProg(total: Long, block: ((Long, Long) -> Unit) -> T): T {
                progDone = 0
                progTotal = total
                progStart = System.currentTimeMillis()
                progActive = true
                val r = withContext(Dispatchers.IO) { block { d, t -> progDone = d; progTotal = t } }
                progActive = false
                return r
            }
            try {
                status = "检测 APK 中...."
                val names = withProg(f.length()) { p -> listZipNames(f, p) }
                if (names.isEmpty()) throw Exception("APK 结构异常，无法读取包内文件")
                val manifest = withContext(Dispatchers.IO) { readZipEntry(f, "AndroidManifest.xml") }
                if (manifest == null || parseManifestInfo(manifest) == null) throw Exception("AndroidManifest.xml 解析失败，安装包不完整")
                val v1 = names.any { it.startsWith("META-INF/") && (it.endsWith(".RSA") || it.endsWith(".DSA") || it.endsWith(".EC")) }
                val v2 = withProg(f.length()) { p -> hasV2Signature(f, p) }
                results.add("包内文件" to "共 ${names.size} 个，结构完整可读")
                results.add("签名状态" to when {
                    v1 -> "v1 签名有效，重打包后继续生效"
                    v2 -> "v2/v3 签名，重打包后交由系统重新校验"
                    else -> "包内无签名，将按未签名包强制提交安装"
                })

                status = "清除旧签名残留中...."
                val stale = names.count { it.startsWith("META-INF/") && (it.endsWith(".SF") || it.endsWith(".RSA") || it.endsWith(".DSA") || it.endsWith(".EC")) }
                results.add("旧签名残留" to if (stale > 0) "发现 $stale 个签名文件，重打包时原样保留以维持校验" else "未发现残留签名文件")

                status = "修复并修改安装包中...."
                val fixed = File(context.cacheDir, "fi_" + System.currentTimeMillis() + "_" + pickedName)
                val count = withProg(f.length()) { p -> rebuildApk(f, fixed, p) }
                results.add("重打包修复" to "已重建 $count 个文件，修复损坏的压缩结构")

                status = "对齐处理中...."
                results.add("对齐处理" to "resources.arsc 已按系统要求不压缩存储，避免安装报错")

                status = "适配修改包检测中...."
                val dex = withProg(fixed.length()) { p -> dexStrings(fixed, 8L * 1024 * 1024, p) }
                val offline = dex.contains("Offline") || dex.contains("offline")
                val tamperKeys = listOf("getPackageInfo", "signatures", "GET_SIGNATURES", "checkSignature", "isSignatureValid")
                val foundTamper = tamperKeys.filter { dex.contains(it) }
                results.add("修改包适配" to when {
                    offline && foundTamper.isNotEmpty() -> "检测到离线版特征与防改代码（修改版/AI 逆向包常见），已保留原签名绕过校验"
                    offline -> "检测到离线版特征，已按修改包方案处理"
                    foundTamper.isNotEmpty() -> "检测到防改校验代码，已保留原签名绕过校验"
                    else -> "未检测到修改包特征，按标准流程处理"
                })

                status = "权限检测中...."
                val perms = extractPermissions(manifest)
                results.add("权限检测" to if (perms.isEmpty()) "未声明特殊权限" else "共 ${perms.size} 项权限，安装时由系统逐项确认")

                status = "验证安装包中...."
                val check = withProg(fixed.length()) { p -> listZipNames(fixed, p) }
                if (check.size != count) throw Exception("修复后验证未通过，请重试")
                results.add("最终验证" to "安装包可正常安装")
                val stable = fiResultFile(context)
                if (stable.exists()) stable.delete()
                fixedFile = if (fixed.renameTo(stable)) {
                    setFiResultName(context, pickedName)
                    stable
                } else fixed
                fixedCount = count
                resultItems = results
                workElapsed = System.currentTimeMillis() - workStart
                addHistory(context, "APK强制安装", "文件：$pickedName\n" + results.joinToString("\n") { "${it.first}：${it.second}" } + "\n用时: " + fmtElapsed(workElapsed))
                pickedFile?.delete()
                pickedFile = null
                phase = 2
            } catch (e: Throwable) {
                jumpMsg = if (e is OutOfMemoryError) "文件过大，内存不足，已停止处理" else (e.message ?: "处理失败，请重试")
                phase = 0
            }
        }
    }
    if (phase == 0) {
        ToolDialog(title = "APK强制安装", onClose = onClose) {
            Text("强制安装被修改过的安装包，自动检测并修复后交给系统安装", fontSize = 13.sp, color = SubText)
            Spacer(Modifier.height(12.dp))
            Button(
                onClick = { picker.launch("application/vnd.android.package-archive") },
                enabled = !uploading,
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(containerColor = AccentColor)
            ) {
                Text(if (uploading) "上传中...." else "上传 APK", fontSize = 16.sp, fontWeight = FontWeight.Bold)
            }
            if (uploading) {
                Spacer(Modifier.height(12.dp))
                CircularProgressIndicator(color = AccentColor, modifier = Modifier.align(Alignment.CenterHorizontally))
                if (etaText.isNotEmpty()) {
                    Spacer(Modifier.height(8.dp))
                    Text(etaText, fontSize = 13.sp, color = SubText, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
                }
            }
            if (jumpMsg.isNotEmpty()) {
                Spacer(Modifier.height(12.dp))
                Text(jumpMsg, fontSize = 13.sp, color = Color(0xFFD0453E), modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
            }
            if (resumeName.isNotEmpty()) {
                Spacer(Modifier.height(12.dp))
                Text("发现上次处理完成的安装包：$resumeName，可直接下载或安装，无需重新处理", fontSize = 13.sp, color = Color(0xFF1E9E6A))
                Spacer(Modifier.height(8.dp))
                Button(
                    onClick = {
                        packing = true
                        packMsg = ""
                        scope.launch {
                            val out = withContext(Dispatchers.IO) {
                                try {
                                    val dir = context.getExternalFilesDir("HAirPLNmo")
                                    if (dir == null) null
                                    else {
                                        dir.mkdirs()
                                        val target = File(dir, resumeName)
                                        val rf = fiResultFile(context)
                                        progDone = 0
                                        progTotal = rf.length()
                                        progStart = System.currentTimeMillis()
                                        progActive = true
                                        target.outputStream().buffered().use { o ->
                                            rf.inputStream().use { i ->
                                                val buf = ByteArray(1048576)
                                                while (true) {
                                                    val n = i.read(buf)
                                                    if (n < 0) break
                                                    o.write(buf, 0, n)
                                                    progDone += n
                                                }
                                            }
                                        }
                                        progActive = false
                                        target.absolutePath
                                    }
                                } catch (e: Throwable) {
                                    progActive = false
                                    null
                                }
                            }
                            packing = false
                            packMsg = if (out != null) "下载完成，已保存到: $out" else "下载失败，请重试"
                        }
                    },
                    enabled = !packing,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = AccentColor)
                ) {
                    Text(if (packing) "下载中...." else "下载上次结果", fontSize = 16.sp, fontWeight = FontWeight.Bold)
                }
                Spacer(Modifier.height(8.dp))
                Button(
                    onClick = {
                        installing = true
                        installMsg = "提交安装中...."
                        val rf = fiResultFile(context)
                        progDone = 0
                        progTotal = rf.length()
                        progStart = System.currentTimeMillis()
                        progActive = true
                        forceInstallApk(context, rf, { d, t -> progDone = d; progTotal = t }) {
                            installing = false
                            progActive = false
                            installMsg = it
                        }
                    },
                    enabled = !installing,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = AccentColor)
                ) {
                    Text(if (installing) "提交安装中...." else "安装上次结果", fontSize = 16.sp, fontWeight = FontWeight.Bold)
                }
                if ((packing || installing) && etaText.isNotEmpty()) {
                    Spacer(Modifier.height(6.dp))
                    Text(etaText, fontSize = 13.sp, color = SubText, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
                }
                TextButton(onClick = { fiResultFile(context).delete(); resumeName = "" }, contentPadding = PaddingValues(0.dp)) {
                    Text("丢弃上次结果", fontSize = 13.sp, color = SubText)
                }
            }
        }
    }
    if (phase == 1) {
        ToolDialog(title = pickedName, onClose = onClose) {
            Text(status, fontSize = 14.sp, color = MainText)
            if (etaText.isNotEmpty()) {
                Spacer(Modifier.height(6.dp))
                Text(etaText, fontSize = 13.sp, color = SubText)
            }
            Spacer(Modifier.height(12.dp))
            CircularProgressIndicator(color = AccentColor, modifier = Modifier.align(Alignment.CenterHorizontally))
        }
    }
    if (phase == 2) {
        ToolDialog(title = "完成", onClose = onClose) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 340.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                Text("完成", fontSize = 16.sp, color = Color(0xFF1E9E6A), fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(4.dp))
                Text("安装包可正常安装", fontSize = 13.sp, color = SubText)
                Spacer(Modifier.height(4.dp))
                Text("上传的原始文件已自动清理，不占存储空间", fontSize = 13.sp, color = Color(0xFF1E9E6A))
                Spacer(Modifier.height(8.dp))
                resultItems.forEach { (t, d) ->
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(BgColor, RoundedCornerShape(10.dp))
                            .padding(horizontal = 12.dp, vertical = 8.dp)
                    ) {
                        Text(t, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = MainText)
                        Spacer(Modifier.height(2.dp))
                        Text(d, fontSize = 12.sp, color = SubText)
                    }
                    Spacer(Modifier.height(6.dp))
                }
                Text("用时: " + fmtElapsed(workElapsed), fontSize = 13.sp, color = MainText)
            }
            Spacer(Modifier.height(12.dp))
            Button(
                onClick = {
                    val ff = fixedFile ?: return@Button
                    val name = pickedName
                    packing = true
                    packMsg = ""
                    scope.launch {
                        val out = withContext(Dispatchers.IO) {
                            try {
                                val dir = context.getExternalFilesDir("HAirPLNmo")
                                if (dir == null) null
                                else {
                                    dir.mkdirs()
                                    val target = File(dir, name)
                                    progDone = 0
                                    progTotal = ff.length()
                                    progStart = System.currentTimeMillis()
                                    progActive = true
                                    target.outputStream().buffered().use { o ->
                                        ff.inputStream().use { i ->
                                            val buf = ByteArray(1048576)
                                            while (true) {
                                                val n = i.read(buf)
                                                if (n < 0) break
                                                o.write(buf, 0, n)
                                                progDone += n
                                            }
                                        }
                                    }
                                    progActive = false
                                    target.absolutePath
                                }
                            } catch (e: Throwable) {
                                progActive = false
                                null
                            }
                        }
                        packing = false
                        packMsg = if (out != null) "下载完成，已保存到: $out" else "下载失败，请重试"
                    }
                },
                enabled = !packing,
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(containerColor = AccentColor)
            ) {
                Text(if (packing) "下载中...." else "下载", fontSize = 16.sp, fontWeight = FontWeight.Bold)
            }
            if (packing && etaText.isNotEmpty()) {
                Spacer(Modifier.height(6.dp))
                Text(etaText, fontSize = 13.sp, color = SubText, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
            }
            if (packMsg.isNotEmpty()) {
                Spacer(Modifier.height(8.dp))
                Text(packMsg, fontSize = 13.sp, color = MainText, modifier = Modifier.fillMaxWidth())
            }
            Spacer(Modifier.height(12.dp))
            Button(
                onClick = {
                    val ff = fixedFile ?: return@Button
                    installing = true
                    installMsg = "提交安装中...."
                    progDone = 0
                    progTotal = ff.length()
                    progStart = System.currentTimeMillis()
                    progActive = true
                    forceInstallApk(context, ff, { d, t -> progDone = d; progTotal = t }) {
                        installing = false
                        progActive = false
                        installMsg = it
                    }
                },
                enabled = !installing,
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(containerColor = AccentColor)
            ) {
                Text(if (installing) "提交安装中...." else "安装", fontSize = 16.sp, fontWeight = FontWeight.Bold)
            }
            if (installing && etaText.isNotEmpty()) {
                Spacer(Modifier.height(6.dp))
                Text(etaText, fontSize = 13.sp, color = SubText, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
            }
            if (installMsg.isNotEmpty()) {
                Spacer(Modifier.height(12.dp))
                Text(installMsg, fontSize = 13.sp, color = MainText, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
            }
        }
    }
}

fun rebuildApk(src: File, out: File, onProgress: ((Long, Long) -> Unit)? = null): Int {
    var count = 0
    val total = src.length()
    var done = 0L
    var lastProg = 0L
    fun prog() {
        if (onProgress != null && done - lastProg > 4L * 1024 * 1024) {
            lastProg = done
            onProgress(done, total)
        }
    }
    val storeExt = listOf("png", "jpg", "jpeg", "webp", "gif", "mp3", "mp4", "ogg", "wav", "so", "ttf", "otf")
    ZipInputStream(src.inputStream().buffered()).use { input ->
        ZipOutputStream(out.outputStream().buffered()).use { output ->
            output.setLevel(1)
            val b = ByteArray(1048576)
            while (true) {
                val e = input.nextEntry ?: break
                if (e.isDirectory) continue
                val ext = e.name.substringAfterLast('.', "").lowercase()
                if (e.name == "resources.arsc") {
                    val tmp = File(out.parentFile, "arsc_" + System.currentTimeMillis() + ".tmp")
                    val crc = java.util.zip.CRC32()
                    var size = 0L
                    tmp.outputStream().use { t ->
                        while (true) {
                            val n = input.read(b)
                            if (n < 0) break
                            t.write(b, 0, n)
                            crc.update(b, 0, n)
                            size += n
                            done += n
                            prog()
                        }
                    }
                    val ne = ZipEntry(e.name)
                    ne.method = ZipEntry.STORED
                    ne.size = size
                    ne.crc = crc.value
                    output.putNextEntry(ne)
                    tmp.inputStream().use { t -> t.copyTo(output, 1048576) }
                    output.closeEntry()
                    tmp.delete()
                } else if (ext in storeExt) {
                    val crc = java.util.zip.CRC32()
                    val tmp = File(out.parentFile, "raw_" + System.currentTimeMillis() + ".tmp")
                    var size = 0L
                    tmp.outputStream().use { t ->
                        while (true) {
                            val n = input.read(b)
                            if (n < 0) break
                            t.write(b, 0, n)
                            crc.update(b, 0, n)
                            size += n
                            done += n
                            prog()
                        }
                    }
                    val ne = ZipEntry(e.name)
                    ne.method = ZipEntry.STORED
                    ne.size = size
                    ne.crc = crc.value
                    output.putNextEntry(ne)
                    tmp.inputStream().use { t -> t.copyTo(output, 1048576) }
                    output.closeEntry()
                    tmp.delete()
                } else {
                    output.putNextEntry(ZipEntry(e.name))
                    while (true) {
                        val n = input.read(b)
                        if (n < 0) break
                        output.write(b, 0, n)
                        done += n
                        prog()
                    }
                    output.closeEntry()
                }
                count++
            }
            onProgress?.invoke(total, total)
        }
    }
    return count
}

fun forceInstallApk(context: Context, file: File, onProgress: ((Long, Long) -> Unit)? = null, onResult: (String) -> Unit) {
    val main = android.os.Handler(context.mainLooper)
    Thread {
        try {
            val installer = context.packageManager.packageInstaller
            val params = android.content.pm.PackageInstaller.SessionParams(android.content.pm.PackageInstaller.SessionParams.MODE_FULL_INSTALL)
            val sessionId = installer.createSession(params)
            val session = installer.openSession(sessionId)
            try {
                session.openWrite("force_apk", 0, file.length()).use { out ->
                    file.inputStream().use { input ->
                        val buf = ByteArray(1048576)
                        var done = 0L
                        val total = file.length()
                        while (true) {
                            val n = input.read(buf)
                            if (n < 0) break
                            out.write(buf, 0, n)
                            done += n
                            onProgress?.invoke(done, total)
                        }
                    }
                    session.fsync(out)
                }
                val intent = Intent("com.hairplnmo.app.FORCE_INSTALL").setPackage(context.packageName)
                val flags = android.app.PendingIntent.FLAG_MUTABLE or android.app.PendingIntent.FLAG_UPDATE_CURRENT
                val sender = android.app.PendingIntent.getBroadcast(context, sessionId, intent, flags)
                session.commit(sender.intentSender)
            } finally {
                session.close()
            }
            main.post { onResult("已提交系统安装，请在弹出的安装界面确认") }
        } catch (e: Exception) {
            main.post { onResult("安装失败：" + (e.message ?: "未知错误")) }
        }
    }.start()
}

@Composable
fun CollapsibleSection(
    title: String,
    expanded: Boolean,
    onToggle: () -> Unit,
    content: @Composable ColumnScope.() -> Unit
) {
    Column(Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(CardColor, RoundedCornerShape(14.dp))
                .tap(onToggle)
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(title, fontSize = 15.sp, fontWeight = FontWeight.Bold, color = MainText, modifier = Modifier.weight(1f))
            Icon(
                if (expanded) Icons.Filled.KeyboardArrowUp else Icons.Filled.KeyboardArrowDown,
                contentDescription = null,
                tint = SubText
            )
        }
        if (expanded) {
            Spacer(Modifier.height(8.dp))
            content()
        }
    }
    Spacer(Modifier.height(10.dp))
}

@Composable
fun FileModifierDialog(onClose: () -> Unit, onBuy: () -> Unit = {}) {
    val context = LocalContext.current
    var page by remember { mutableStateOf(0) }
    var freeOpen by remember { mutableStateOf(true) }
    var premiumOpen by remember { mutableStateOf(false) }
    var premiumPage by remember { mutableStateOf(0) }
    var premiumSub by remember { mutableStateOf(0) }
    var showPremiumTip by remember { mutableStateOf(false) }
    val premium = remember { isPremium(context) }
    DisposableEffect(Unit) {
        onDispose {
            cleanTempFiles(context)
        }
    }
    ToolDialog(title = "文件修改器", onClose = onClose) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .heightIn(max = 420.dp)
                .verticalScroll(rememberScrollState())
        ) {
            CollapsibleSection(title = "免费版", expanded = freeOpen, onToggle = { freeOpen = !freeOpen }) {
                ToolMenuItem("1", "修改应用", "只能上传 APK，修改包内文件") { page = 1 }
                ToolMenuItem("2", "分析APK", "拆包，看权限、签名等信息") { page = 2 }
                ToolMenuItem("3", "修改文件", "支持 APK、HTML 等各类文件") { page = 3 }
                ToolMenuItem("4", "APK强制安装", "强制安装被修改过的安装包") { page = 4 }
            }
            CollapsibleSection(
                title = "高级版",
                expanded = premiumOpen,
                onToggle = {
                    if (premium) premiumOpen = !premiumOpen else showPremiumTip = true
                }
            ) {
                ToolMenuItem("1", "修改APK并安装", "修改包内文件、查看应用信息与安全检测") { premiumPage = 1 }
                CollapsibleSection(title = "容器2 APK加所有文件分析", expanded = false, onToggle = {}) {
                }
            }
        }
    }
    if (premiumPage == 1) {
        ToolDialog(title = "修改APK并安装", onClose = { premiumPage = 0 }) {
            ToolMenuItem("1", "修改文件", "像 MT 管理器那样显示文件，带图标，支持删、改、加") { premiumSub = 1 }
            ToolMenuItem("2", "应用信息", "文件大小、版本号、内版本、包名，上传的应用显示图标") { premiumSub = 2 }
            ToolMenuItem("3", "安全检测", "哈希值、哈希函数、哈希校验、应用密码、防改代码、弹窗、能否破解、文件数量") { premiumSub = 3 }
            Text("更多功能陆续添加中", fontSize = 12.sp, color = SubText, modifier = Modifier.padding(top = 4.dp))
        }
    }
    if (premiumSub == 1) {
        PremiumModPage(onClose = { premiumSub = 0 })
    }
    if (premiumSub == 2) {
        PremiumAppInfoPage(onClose = { premiumSub = 0 })
    }
    if (premiumSub == 3) {
        PremiumSecurityPage(onClose = { premiumSub = 0 })
    }
    if (showPremiumTip) {
        AlertDialog(
            onDismissRequest = { showPremiumTip = false },
            title = { Text("需要高级版", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = MainText) },
            text = { Text("高级版功能需要开通高级账号后才能使用，请先前往购买。", fontSize = 14.sp, color = SubText) },
            confirmButton = {
                TextButton(onClick = {
                    showPremiumTip = false
                    onClose()
                    onBuy()
                }) { Text("去购买", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = Color(0xFF1E6FD0)) }
            },
            dismissButton = {
                TextButton(onClick = { showPremiumTip = false }) { Text("确定", fontSize = 15.sp, color = SubText) }
            }
        )
    }
    if (page == 1) {
        ModifyAppPage(onClose = { page = 0 })
    }
    if (page == 2) {
        ApkAnalysisPage(onClose = { page = 0 })
    }
    if (page == 3) {
        ModifyFilePage(onClose = { page = 0 })
    }
    if (page == 4) {
        ForceInstallPage(onClose = { page = 0 })
    }
}

@Composable
fun ZipEditorPage(file: File, name: String, onClose: () -> Unit, funcName: String = "修改文件") {
    val context = LocalContext.current
    var entries by remember(file) { mutableStateOf(loadZipEntries(file)) }
    val edits = remember(file) { mutableStateMapOf<String, ByteArray?>() }
    var editing by remember { mutableStateOf<FmEntry?>(null) }
    var jumpMsg by remember { mutableStateOf("") }
    val export = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/octet-stream")) { uri ->
        if (uri != null) {
            jumpMsg = try {
                context.contentResolver.openOutputStream(uri)?.use { rewriteZip(file, edits, it) }
                addHistory(context, funcName, "文件：$name\n已导出修改后的文件（改动 ${edits.size} 处）")
                "已导出修改后的文件"
            } catch (e: Exception) {
                "导出失败，请重试"
            }
        }
    }
    ToolDialog(title = name, onClose = onClose) {
        Text("共 ${entries.size} 个文件，已改动 ${edits.size} 处", fontSize = 13.sp, color = SubText)
        if (jumpMsg.isNotEmpty()) {
            Spacer(Modifier.height(8.dp))
            Text(jumpMsg, fontSize = 12.sp, color = Color(0xFF1E9E6A))
        }
        Spacer(Modifier.height(10.dp))
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .heightIn(max = 340.dp)
                .verticalScroll(rememberScrollState())
        ) {
            entries.forEach { e ->
                val changed = edits.containsKey(e.name)
                val deleted = changed && edits[e.name] == null
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(CardColor, RoundedCornerShape(12.dp))
                        .tap { editing = e }
                        .padding(horizontal = 14.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(Modifier.weight(1f)) {
                        Text(
                            e.name,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (deleted) SubText else MainText,
                            textDecoration = if (deleted) TextDecoration.LineThrough else null,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Spacer(Modifier.height(2.dp))
                        Text(
                            if (changed) (if (deleted) "已删除" else "已修改") else fmtSize(e.size),
                            fontSize = 11.sp,
                            color = if (changed) Color(0xFF1E9E6A) else SubText
                        )
                    }
                    Icon(Icons.Filled.ChevronRight, contentDescription = null, tint = SubText)
                }
                Spacer(Modifier.height(6.dp))
            }
        }
        Spacer(Modifier.height(10.dp))
        Button(
            onClick = { export.launch(name) },
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(14.dp),
            colors = ButtonDefaults.buttonColors(containerColor = AccentColor)
        ) {
            Text("导出修改后的文件", fontSize = 15.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(6.dp))
        Text("修改后的 APK 需重新签名才能安装", fontSize = 12.sp, color = Color(0xFFB07A1E))
    }
    if (editing != null) {
        val target = editing!!
        EntryEditDialog(
            entry = target,
            current = edits[target.name],
            onDismiss = { editing = null },
            onSave = { bytes ->
                edits[target.name] = bytes
                editing = null
            },
            onDelete = {
                edits[target.name] = null
                editing = null
            }
        )
    }
}

@Composable
fun EntryEditDialog(entry: FmEntry, current: ByteArray?, onDismiss: () -> Unit, onSave: (ByteArray) -> Unit, onDelete: () -> Unit) {
    var text by remember(entry.name) { mutableStateOf(String(current ?: entry.content ?: ByteArray(0), Charsets.UTF_8)) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(entry.name, fontSize = 15.sp, fontWeight = FontWeight.Bold, color = MainText, maxLines = 2, overflow = TextOverflow.Ellipsis) },
        text = {
            Column {
                if (entry.isText) {
                    BasicTextField(
                        value = text,
                        onValueChange = { text = it },
                        textStyle = TextStyle(fontSize = 13.sp, color = MainText),
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(max = 260.dp)
                            .verticalScroll(rememberScrollState())
                            .background(BgColor, RoundedCornerShape(10.dp))
                            .padding(10.dp)
                    )
                } else {
                    Text("二进制文件不支持内容编辑", fontSize = 13.sp, color = SubText)
                }
                Spacer(Modifier.height(10.dp))
                Row {
                    if (entry.isText) {
                        TextButton(onClick = { onSave(text.toByteArray(Charsets.UTF_8)) }) {
                            Text("保存修改", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = AccentColor)
                        }
                        Spacer(Modifier.width(10.dp))
                    }
                    TextButton(onClick = onDelete) {
                        Text("删除该文件", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Color(0xFFD0453E))
                    }
                }
            }
        },
        confirmButton = {},
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("取消", fontSize = 14.sp, color = SubText) }
        }
    )
}

@Composable
fun TextEditorPage(file: File, name: String, onClose: () -> Unit) {
    val context = LocalContext.current
    var content by remember(file) { mutableStateOf(runCatching { file.readText(Charsets.UTF_8) }.getOrElse { "" }) }
    var find by remember { mutableStateOf("") }
    var replace by remember { mutableStateOf("") }
    var jumpMsg by remember { mutableStateOf("") }
    val export = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/plain")) { uri ->
        if (uri != null) {
            jumpMsg = try {
                context.contentResolver.openOutputStream(uri)?.use { it.write(content.toByteArray(Charsets.UTF_8)) }
                "已保存修改后的文件"
            } catch (e: Exception) {
                "保存失败，请重试"
            }
        }
    }
    val count = if (find.isEmpty()) 0 else content.split(find).size - 1
    ToolDialog(title = name, onClose = onClose) {
        BasicTextField(
            value = content,
            onValueChange = { content = it },
            textStyle = TextStyle(fontSize = 13.sp, color = MainText),
            modifier = Modifier
                .fillMaxWidth()
                .heightIn(max = 240.dp)
                .verticalScroll(rememberScrollState())
                .background(CardColor, RoundedCornerShape(12.dp))
                .padding(12.dp)
        )
        Spacer(Modifier.height(10.dp))
        FloatField(value = find, onValueChange = { find = it }, label = "查找内容", modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))
        FloatField(value = replace, onValueChange = { replace = it }, label = "替换为（留空即删除）", modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(10.dp))
        if (find.isNotEmpty()) {
            Text("找到 $count 处", fontSize = 13.sp, color = SubText)
            Spacer(Modifier.height(8.dp))
        }
        Row {
            Button(
                onClick = {
                    if (find.isNotEmpty()) {
                        content = content.replace(find, replace)
                        jumpMsg = "已替换 $count 处"
                    }
                },
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(containerColor = AccentColor)
            ) {
                Text("全部替换", fontSize = 14.sp, fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.width(10.dp))
            Button(
                onClick = { export.launch(name) },
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(containerColor = AccentColor)
            ) {
                Text("导出保存", fontSize = 14.sp, fontWeight = FontWeight.Bold)
            }
        }
        if (jumpMsg.isNotEmpty()) {
            Spacer(Modifier.height(8.dp))
            Text(jumpMsg, fontSize = 12.sp, color = Color(0xFF1E9E6A))
        }
    }
}

@Composable
fun BinaryPage(file: File, name: String, onClose: () -> Unit) {
    val context = LocalContext.current
    var jumpMsg by remember { mutableStateOf("") }
    val export = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/octet-stream")) { uri ->
        if (uri != null) {
            jumpMsg = try {
                context.contentResolver.openOutputStream(uri)?.use { out -> file.inputStream().use { it.copyTo(out) } }
                "已导出文件"
            } catch (e: Exception) {
                "导出失败，请重试"
            }
        }
    }
    val hex = remember(file) {
        val bytes = file.inputStream().use { input ->
            val b = ByteArray(256)
            val n = input.read(b)
            b.copyOf(n)
        }
        bytes.toList().chunked(16).joinToString("\n") { row -> row.joinToString(" ") { "%02x".format(it) } }
    }
    ToolDialog(title = name, onClose = onClose) {
        Text("二进制文件，共 ${fmtSize(file.length())}", fontSize = 13.sp, color = SubText)
        Spacer(Modifier.height(10.dp))
        Text("开头内容（十六进制）", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = MainText)
        Spacer(Modifier.height(6.dp))
        Text(
            hex,
            fontSize = 11.sp,
            color = SubText,
            lineHeight = 16.sp,
            modifier = Modifier
                .fillMaxWidth()
                .background(CardColor, RoundedCornerShape(12.dp))
                .padding(12.dp)
        )
        Spacer(Modifier.height(12.dp))
        Button(
            onClick = { export.launch(name) },
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(14.dp),
            colors = ButtonDefaults.buttonColors(containerColor = AccentColor)
        ) {
            Text("导出文件", fontSize = 15.sp, fontWeight = FontWeight.Bold)
        }
        if (jumpMsg.isNotEmpty()) {
            Spacer(Modifier.height(8.dp))
            Text(jumpMsg, fontSize = 12.sp, color = Color(0xFF1E9E6A))
        }
    }
}
