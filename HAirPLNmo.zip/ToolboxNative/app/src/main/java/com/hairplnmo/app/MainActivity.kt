package com.hairplnmo.app

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.border
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.Brush
import androidx.compose.material.icons.filled.EditNote
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Tag
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CardGiftcard
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.Handyman
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon

import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.composed
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import kotlinx.coroutines.delay
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import java.security.MessageDigest
import kotlin.system.exitProcess
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState

val BgColor = Color(0xFFF3F5F9)
val CardColor = Color(0xFFFFFFFF)
val AccentColor = Color(0xFF1A6DFF)
val MainText = Color(0xFF1B2230)
val SubText = Color(0xFF7A8499)
val LineColor = Color(0xFFE3E8F0)
val ExpectedSig = "241e92d50251dfce8965c4381888f231fb7a78d67b35ed7ee228a1533b1a1437"

fun Modifier.tap(onClick: () -> Unit): Modifier = composed {
    clickable(interactionSource = remember { MutableInteractionSource() }, indication = null, onClick = onClick)
}

@Composable
fun FloatField(
    value: String,
    onValueChange: (String) -> Unit,
    label: String,
    modifier: Modifier = Modifier,
    isPassword: Boolean = false
) {
    var focused by remember { mutableStateOf(false) }
    val up = focused || value.isNotEmpty()
    val labelSize by animateFloatAsState(if (up) 11f else 14f)
    val labelTop by animateDpAsState(if (up) 8.dp else 20.dp)
    val inputTop by animateDpAsState(if (up) 16.dp else 0.dp)
    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(56.dp)
            .border(1.dp, if (focused) AccentColor else LineColor, RoundedCornerShape(12.dp))
            .background(CardColor, RoundedCornerShape(12.dp))
    ) {
        Text(
            label,
            fontSize = labelSize.sp,
            color = if (focused) AccentColor else SubText,
            modifier = Modifier
                .align(Alignment.TopStart)
                .padding(start = 14.dp, top = labelTop)
        )
        BasicTextField(
            value = value,
            onValueChange = onValueChange,
            singleLine = true,
            textStyle = TextStyle(fontSize = 15.sp, color = MainText),
            visualTransformation = if (isPassword) PasswordVisualTransformation() else VisualTransformation.None,
            keyboardOptions = KeyboardOptions(keyboardType = if (isPassword) KeyboardType.Password else KeyboardType.Text),
            modifier = Modifier
                .align(Alignment.CenterStart)
                .padding(start = 14.dp, end = 14.dp, top = inputTop)
                .fillMaxWidth()
                .onFocusChanged { focused = it.isFocused }
        )
    }
}

class MainActivity : ComponentActivity() {
    fun isSignatureValid(): Boolean {
        return try {
            val info = packageManager.getPackageInfo(packageName, PackageManager.GET_SIGNATURES)
            val sig = info.signatures?.firstOrNull() ?: return false
            val digest = MessageDigest.getInstance("SHA-256").digest(sig.toByteArray())
            val hex = digest.joinToString("") { "%02x".format(it) }
            hex == ExpectedSig
        } catch (e: Exception) {
            false
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        val controller = WindowCompat.getInsetsController(window, window.decorView)
        controller.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        controller.hide(WindowInsetsCompat.Type.systemBars())
        val sigOk = isSignatureValid()
        val startUser = getLoggedInUser(this)
        setContent {
            var stage by remember {
                mutableStateOf(
                    when {
                        startUser.isEmpty() -> "login"
                        else -> "loading"
                    }
                )
            }
            var currentUser by remember { mutableStateOf(startUser) }
            var premiumPopup by remember { mutableStateOf(false) }
            Surface(color = BgColor, modifier = Modifier.fillMaxSize()) {
                if (!sigOk) {
                    TamperScreen(onExit = {
                        finishAffinity()
                        exitProcess(0)
                    })
                } else {
                    when (stage) {
                        "login" -> LoginScreen(onSuccess = { u ->
                            currentUser = u
                            stage = "loading"
                        })
                        "purchase" -> PurchaseScreen(onBack = { stage = "home" })
                        "loading" -> LoadingScreen(onDone = { stage = "home" })
                        "home" -> HomeScreen(
                            currentUser = currentUser,
                            showPremiumPopup = premiumPopup,
                            onDismissPremiumPopup = { premiumPopup = false },
                            onPremium = { premiumPopup = true },
                            onLogout = {
                                setLoggedInUser(applicationContext, "")
                                currentUser = ""
                                stage = "login"
                            },
                            onBuy = { stage = "purchase" }
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun TamperScreen(onExit: () -> Unit) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF1B2230)),
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(28.dp)
                .background(CardColor, RoundedCornerShape(22.dp))
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text("⚠", fontSize = 40.sp)
            Spacer(Modifier.height(12.dp))
            Text("检测到应用被修改", fontSize = 19.sp, fontWeight = FontWeight.Bold, color = MainText)
            Spacer(Modifier.height(8.dp))
            Text(
                "应用的文件或签名已被改动，为保护安全无法继续使用。",
                fontSize = 13.sp,
                color = SubText,
                textAlign = TextAlign.Center,
                lineHeight = 20.sp
            )
            Spacer(Modifier.height(20.dp))
            Button(
                onClick = onExit,
                modifier = Modifier.fillMaxWidth(),
                                colors = ButtonDefaults.buttonColors(containerColor = AccentColor)
            ) {
                Text("确定", fontSize = 15.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}


fun isKeyUsed(context: Context, key: String): Boolean {
    return (context.getSharedPreferences("hairplnmo", Context.MODE_PRIVATE)
        .getStringSet("used_keys", emptySet()) ?: emptySet()).contains(key)
}

fun bindKey(context: Context, key: String, account: String) {
    val sp = context.getSharedPreferences("hairplnmo", Context.MODE_PRIVATE)
    val binds = (sp.getStringSet("bindings", emptySet()) ?: emptySet()).toMutableSet()
    binds.add("$key|$account")
    sp.edit().putStringSet("bindings", binds).apply()
    val time = java.text.SimpleDateFormat("yyyy-MM-dd HH:mm", java.util.Locale.CHINA).format(java.util.Date())
    val times = (sp.getStringSet("binding_times", emptySet()) ?: emptySet()).toMutableSet()
    times.add("$key|$account|$time")
    sp.edit().putStringSet("binding_times", times).apply()
}

fun getKeyBoundAccount(context: Context, key: String): String? {
    val binds = context.getSharedPreferences("hairplnmo", Context.MODE_PRIVATE)
        .getStringSet("bindings", emptySet()) ?: emptySet()
    return binds.firstOrNull { it.substringBefore('|') == key }?.substringAfter('|')
}

val ValidKeys = listOf(
    "HAIR-KVMQ-WYJH-3MKY", "HAIR-TB6H-XJET-KCSF", "HAIR-WTEM-UKG4-A8DS",
    "HAIR-7MCY-NSNB-P44T", "HAIR-D28F-GHHH-522R", "HAIR-XJ6X-2JMS-Z4WV",
    "HAIR-7EZV-7KFL-7ETC", "HAIR-RS6R-5RWB-2HA3", "HAIR-BUJ3-D62Y-FHGH",
    "HAIR-4MZM-44BA-MMD6", "HAIR-FDU7-5ECA-MCHV", "HAIR-J2M6-GCQQ-T4CX",
    "HAIR-QJJR-Q83P-PAQV", "HAIR-7GDQ-NCAW-SP6G", "HAIR-E8F4-XWWK-2959",
    "HAIR-D69F-84KV-2S77", "HAIR-L3EL-4T8Q-B7KL", "HAIR-DEYZ-T6QH-Z4VE",
    "HAIR-7W8S-LBKG-9C2U", "HAIR-U5E8-NX4A-5QTV", "HAIR-YYAE-C27L-3RQ2",
    "HAIR-CE7J-D89R-GNZW", "HAIR-JWSG-K4RK-P5DJ", "HAIR-UD4S-S628-G8JD",
    "HAIR-V6EM-GK9W-BC7G", "HAIR-29P2-HADB-U9K6", "HAIR-93VD-LZ8N-73TG",
    "HAIR-5Z38-5MKF-WBPN", "HAIR-X8EJ-NATW-4EEY", "HAIR-PCKA-3CFH-HSV3"
)

val AdminUser = "admin"
val AdminPass = "VAY6JAPWNB"

fun getLoggedInUser(context: Context): String {
    return context.getSharedPreferences("hairplnmo", Context.MODE_PRIVATE).getString("logged_user", "") ?: ""
}

fun setLoggedInUser(context: Context, user: String) {
    context.getSharedPreferences("hairplnmo", Context.MODE_PRIVATE).edit().putString("logged_user", user).apply()
}

fun setLoggedNick(context: Context, nick: String) {
    context.getSharedPreferences("hairplnmo", Context.MODE_PRIVATE).edit().putString("logged_nick", nick).apply()
}

fun getLoggedNick(context: Context): String {
    return context.getSharedPreferences("hairplnmo", Context.MODE_PRIVATE).getString("logged_nick", "") ?: ""
}

fun checkLogin(context: Context, user: String, pass: String): String {
    if (user == AdminUser) return if (pass == AdminPass) "ok" else "密码错误"
    val users = context.getSharedPreferences("hairplnmo", Context.MODE_PRIVATE)
        .getStringSet("accounts", emptySet()) ?: emptySet()
    return if (users.contains("$user|$pass")) "ok" else "账号或密码错误"
}

fun registerAccount(context: Context, user: String, pass: String): String {
    val sp = context.getSharedPreferences("hairplnmo", Context.MODE_PRIVATE)
    val users = sp.getStringSet("accounts", emptySet()) ?: emptySet()
    return when {
        user.isBlank() || pass.isBlank() -> "账号和密码不能为空"
        user == AdminUser || users.any { it.substringBefore('|') == user } -> "该账号已存在"
        else -> {
            sp.edit().putStringSet("accounts", users + "$user|$pass").apply()
            "注册成功"
        }
    }
}

fun openPayApp(context: Context, pkg: String): Boolean = try {
    context.packageManager.getLaunchIntentForPackage(pkg)?.let {
        it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(it)
        true
    } ?: false
} catch (e: Exception) {
    false
}

fun recordPurchase(context: Context, amount: String, content: String) {
    val time = java.text.SimpleDateFormat("yyyy-MM-dd HH:mm", java.util.Locale.CHINA).format(java.util.Date())
    val sp = context.getSharedPreferences("hairplnmo", Context.MODE_PRIVATE)
    val account = sp.getString("logged_user", "") ?: ""
    val nick = sp.getString("logged_nick", "") ?: ""
    val name = nick.ifBlank { account }
    val records = sp.getStringSet("purchase_records", emptySet()) ?: emptySet()
    sp.edit().putStringSet("purchase_records", records + "$time|$name|$amount|$content").apply()
    cloudSyncOrders(context)
}

val CloudUrl = "https://dav.jianguoyun.com/dav/hairplnmo/orders.json"
val CloudAuth = "Basic " + android.util.Base64.encodeToString("dtyoq1@163.com:a87ajb4vr7frz99i".toByteArray(), android.util.Base64.NO_WRAP)
val CloudKeys = listOf("purchase_records", "issued_purchases", "completed_orders", "issued_keys", "bindings", "binding_times")

fun cloudJson(sp: android.content.SharedPreferences): String {
    val o = org.json.JSONObject()
    CloudKeys.forEach { k -> o.put(k, org.json.JSONArray(sp.getStringSet(k, emptySet()) ?: emptySet())) }
    return o.toString()
}

fun cloudGet(): String? = try {
    val c = java.net.URL(CloudUrl).openConnection() as java.net.HttpURLConnection
    c.requestMethod = "GET"
    c.setRequestProperty("Authorization", CloudAuth)
    val r = if (c.responseCode == 200) c.inputStream.bufferedReader().readText() else null
    c.disconnect()
    r
} catch (e: Exception) {
    null
}

fun cloudPut(body: String): Boolean = try {
    val c = java.net.URL(CloudUrl).openConnection() as java.net.HttpURLConnection
    c.requestMethod = "PUT"
    c.setRequestProperty("Authorization", CloudAuth)
    c.setDoOutput(true)
    c.setRequestProperty("Content-Type", "application/json")
    c.outputStream.use { it.write(body.toByteArray()) }
    val ok = c.responseCode in 200..299
    c.disconnect()
    ok
} catch (e: Exception) {
    false
}

fun cloudSyncOrders(context: Context) {
    Thread {
        try {
            val sp = context.getSharedPreferences("hairplnmo", Context.MODE_PRIVATE)
            val body = cloudGet()
            val o = if (body != null) org.json.JSONObject(body) else org.json.JSONObject()
            CloudKeys.forEach { k -> if (!o.has(k)) o.put(k, org.json.JSONArray()) }
            val arr = o.getJSONArray("purchase_records")
            val cloudSet = (0 until arr.length()).map { arr.getString(it) }.toSet()
            val local = sp.getStringSet("purchase_records", emptySet()) ?: emptySet()
            o.put("purchase_records", org.json.JSONArray((cloudSet + local).toList()))
            cloudPut(o.toString())
        } catch (e: Exception) {
        }
    }.start()
}

fun cloudPullAdmin(context: Context, onDone: () -> Unit) {
    Thread {
        var ok = false
        try {
            val body = cloudGet()
            if (body != null) {
                val sp = context.getSharedPreferences("hairplnmo", Context.MODE_PRIVATE)
                val o = org.json.JSONObject(body)
                val edit = sp.edit()
                CloudKeys.forEach { k ->
                    val arr = o.optJSONArray(k) ?: return@forEach
                    val cloudVals = (0 until arr.length()).map { arr.getString(it) }.toSet()
                    val local = sp.getStringSet(k, emptySet()) ?: emptySet()
                    if (k == "issued_purchases" || k == "issued_keys") edit.putStringSet(k, cloudVals)
                    else edit.putStringSet(k, local + cloudVals)
                }
                edit.apply()
                ok = true
            }
        } catch (e: Exception) {
        }
        android.os.Handler(android.os.Looper.getMainLooper()).post { if (ok) onDone() }
    }.start()
}

fun cloudPushAll(context: Context) {
    Thread {
        try {
            val sp = context.getSharedPreferences("hairplnmo", Context.MODE_PRIVATE)
            cloudPut(cloudJson(sp))
        } catch (e: Exception) {
        }
    }.start()
}

fun isOrderCompleted(context: Context, record: String): Boolean {
    val logs = context.getSharedPreferences("hairplnmo", Context.MODE_PRIVATE)
        .getStringSet("completed_orders", emptySet()) ?: emptySet()
    return logs.any { it.substringBefore('|') == record }
}

fun getOrderCompleteTime(context: Context, record: String): String? {
    val logs = context.getSharedPreferences("hairplnmo", Context.MODE_PRIVATE)
        .getStringSet("completed_orders", emptySet()) ?: emptySet()
    return logs.firstOrNull { it.substringBefore('|') == record }?.substringAfter('|')
}

@Composable
fun PurchaseScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val plans = listOf(
        Triple("1元", "0.9元", "功能不完全"),
        Triple("2元", "1.99元", "功能有点完整"),
        Triple("5元", "2.99元", "功能完整"),
        Triple("10元", "9.9元", "功能全齐")
    )
    var selected by remember { mutableStateOf(0) }
    var showConfirm by remember { mutableStateOf(false) }
    var showPayMethod by remember { mutableStateOf(false) }
    var payAppName by remember { mutableStateOf("") }
    var waiting by remember { mutableStateOf(false) }
    var jumpMsg by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(BgColor)
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            TextButton(onClick = onBack, contentPadding = PaddingValues(0.dp)) {
                Text("← 返回", fontSize = 14.sp, color = SubText)
            }
        }
        Text("购买卡密", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = MainText)
        Spacer(Modifier.height(6.dp))
        Text("选择套餐，支付后联系管理员领取卡密", fontSize = 13.sp, color = SubText)
        Spacer(Modifier.height(10.dp))
        Text(
            "支付说明：支付后钱款作废删除，不会进入任何账户。",
            fontSize = 12.sp,
            color = Color(0xFFB07A1E),
            lineHeight = 18.sp,
            modifier = Modifier
                .fillMaxWidth()
                .background(Color(0xFFFDF4E3), RoundedCornerShape(10.dp))
                .padding(horizontal = 12.dp, vertical = 8.dp)
        )
        Spacer(Modifier.height(20.dp))
        plans.forEachIndexed { i, (orig, price, desc) ->
            PlanCard(orig, price, desc, selected == i) { selected = i }
            Spacer(Modifier.height(14.dp))
        }
        Spacer(Modifier.height(10.dp))
        Button(
            onClick = { showConfirm = true },
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(14.dp),
            colors = ButtonDefaults.buttonColors(containerColor = AccentColor)
        ) {
            Text("购买", fontSize = 16.sp, fontWeight = FontWeight.Bold)
        }
        if (jumpMsg.isNotEmpty()) {
            Spacer(Modifier.height(12.dp))
            Text(jumpMsg, fontSize = 13.sp, color = Color(0xFFD0453E), modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
        }
        Spacer(Modifier.height(24.dp))
    }

    if (showConfirm) {
        AlertDialog(
            onDismissRequest = { showConfirm = false },
            title = { Text("确定支付？", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = MainText) },
            text = { Text("支付后钱款将作废删除，不会进入任何账户，也无法退钱。", fontSize = 14.sp, color = SubText, lineHeight = 20.sp) },
            confirmButton = {
                TextButton(onClick = {
                    showConfirm = false
                    showPayMethod = true
                }) { Text("确定", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = AccentColor) }
            },
            dismissButton = {
                TextButton(onClick = { showConfirm = false }) { Text("取消", fontSize = 15.sp, color = SubText) }
            }
        )
    }

    if (showPayMethod) {
        AlertDialog(
            onDismissRequest = { showPayMethod = false },
            title = { Text("选择支付方式", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = MainText) },
            text = {
                Column {
                    Button(
                        onClick = {
                            showPayMethod = false
                            payAppName = "支付宝"
                            jumpMsg = if (openPayApp(context, "com.eg.android.AlipayGphone")) "" else "未安装支付宝"
                            waiting = jumpMsg.isEmpty()
                            if (waiting) recordPurchase(context, plans[selected].second, plans[selected].third)
                        },
                        modifier = Modifier.fillMaxWidth(),
                                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1677FF))
                    ) {
                        Text("支付宝", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = Color.White)
                    }
                    Spacer(Modifier.height(10.dp))
                    Button(
                        onClick = {
                            showPayMethod = false
                            payAppName = "微信"
                            jumpMsg = if (openPayApp(context, "com.tencent.mm")) "" else "未安装微信"
                            waiting = jumpMsg.isEmpty()
                            if (waiting) recordPurchase(context, plans[selected].second, plans[selected].third)
                        },
                        modifier = Modifier.fillMaxWidth(),
                                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E9E6A))
                    ) {
                        Text("微信", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = Color.White)
                    }
                    Spacer(Modifier.height(10.dp))
                    Button(
                        onClick = {
                            showPayMethod = false
                            payAppName = "测试支付"
                            waiting = true
                            recordPurchase(context, plans[selected].second, plans[selected].third)
                        },
                        modifier = Modifier.fillMaxWidth(),
                                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFB07A1E))
                    ) {
                        Text("测试购买", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = Color.White)
                    }
                }
            },
            confirmButton = {},
            dismissButton = {}
        )
    }

    if (waiting) {
        AlertDialog(
            onDismissRequest = { },
            title = { Text("等待支付完成", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = MainText) },
            text = { Text("已跳转到${payAppName}。完成支付后，请将付款截图发给管理员领取卡密，回到本应用输入卡密即可解锁。", fontSize = 14.sp, color = SubText, lineHeight = 20.sp) },
            confirmButton = {
                TextButton(onClick = { waiting = false }) { Text("我知道了", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = AccentColor) }
            },
            dismissButton = {
                TextButton(onClick = { waiting = false }) { Text("取消", fontSize = 15.sp, color = SubText) }
            }
        )
    }
}

@Composable
fun PlanCard(orig: String, price: String, desc: String, selected: Boolean, onClick: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(CardColor, RoundedCornerShape(18.dp))
            .then(if (selected) Modifier.border(2.dp, AccentColor, RoundedCornerShape(18.dp)) else Modifier)
            .tap(onClick)
            .padding(18.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(orig, fontSize = 13.sp, color = SubText, textDecoration = TextDecoration.LineThrough)
            Spacer(Modifier.height(4.dp))
            Text(price, fontSize = 24.sp, fontWeight = FontWeight.Bold, color = if (selected) AccentColor else MainText)
            Spacer(Modifier.height(4.dp))
            Text(desc, fontSize = 13.sp, color = SubText)
        }
        Box(
            modifier = Modifier
                .size(24.dp)
                .then(
                    if (selected) Modifier.background(AccentColor, CircleShape)
                    else Modifier.border(2.dp, Color(0xFFC6CCD8), CircleShape)
                ),
            contentAlignment = Alignment.Center
        ) {
            if (selected) {
                Icon(Icons.Filled.Check, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
            }
        }
    }
}

@Composable
fun LoginScreen(onSuccess: (String) -> Unit) {
    val context = LocalContext.current
    var mode by remember { mutableStateOf("login") }
    var user by remember { mutableStateOf("") }
    var pass by remember { mutableStateOf("") }
    var nick by remember { mutableStateOf("") }
    var msg by remember { mutableStateOf("") }
    var msgColor by remember { mutableStateOf(AccentColor) }
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFFFFFFF))
            .padding(horizontal = 28.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Box(
            modifier = Modifier
                .size(64.dp)
                .background(Color(0xFF1C1C1E), RoundedCornerShape(18.dp)),
            contentAlignment = Alignment.Center
        ) {
            Icon(Icons.Filled.Handyman, contentDescription = null, tint = Color.White, modifier = Modifier.size(30.dp))
        }
        Spacer(Modifier.height(16.dp))
        Text("HAirPLNmo", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = MainText)
        Spacer(Modifier.height(6.dp))
        Text(if (mode == "login") "登录以继续" else "创建新账号", fontSize = 14.sp, color = SubText)
        Spacer(Modifier.height(30.dp))
        FloatField(
            value = user,
            onValueChange = { user = it; msg = "" },
            label = "账号",
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(14.dp))
        FloatField(
            value = pass,
            onValueChange = { pass = it; msg = "" },
            label = "密码",
            modifier = Modifier.fillMaxWidth(),
            isPassword = true
        )
        Spacer(Modifier.height(14.dp))
        if (mode == "register") {
            FloatField(
                value = nick,
                onValueChange = { nick = it; msg = "" },
                label = "请输入昵称",
                modifier = Modifier.fillMaxWidth()
            )
        }
        Spacer(Modifier.height(20.dp))
        Button(
            onClick = {
                if (mode == "login") {
                    val r = checkLogin(context, user.trim(), pass)
                    if (r == "ok") {
                        setLoggedInUser(context, user.trim())
                        onSuccess(user.trim())
                    } else {
                        msg = r
                        msgColor = Color(0xFFD0453E)
                    }
                } else {
                    if (nick.isBlank()) {
                        msg = "请输入昵称"
                        msgColor = Color(0xFFD0453E)
                        return@Button
                    }
                    val r = registerAccount(context, user.trim(), pass)
                    if (r == "注册成功") {
                        setLoggedNick(context, nick.trim())
                        mode = "login"
                        pass = ""
                        nick = ""
                        msg = "注册成功，请登录"
                        msgColor = Color(0xFF1E9E6A)
                    } else {
                        msg = r
                        msgColor = Color(0xFFD0453E)
                    }
                }
            },
            modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(containerColor = AccentColor)
        ) {
            Text(if (mode == "login") "登录" else "注册", fontSize = 15.sp, fontWeight = FontWeight.Bold)
        }
        if (msg.isNotEmpty()) {
            Spacer(Modifier.height(12.dp))
            Text(msg, fontSize = 14.sp, color = msgColor, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
        }
        Spacer(Modifier.height(10.dp))
        TextButton(onClick = {
            mode = if (mode == "login") "register" else "login"
            msg = ""
        }, contentPadding = PaddingValues(6.dp)) {
            Text(
                if (mode == "login") "没有账号？去注册" else "已有账号？去登录",
                fontSize = 13.sp,
                color = SubText
            )
        }
    }
}

@Composable
fun AdminDialog(initialTab: Int, onDismiss: () -> Unit) {
    val context = LocalContext.current
    val clipboard = LocalClipboardManager.current
    var issued by remember {
        mutableStateOf(
            context.getSharedPreferences("hairplnmo", Context.MODE_PRIVATE)
                .getStringSet("issued_keys", emptySet()) ?: emptySet()
        )
    }
    var issuedPurchases by remember {
        mutableStateOf(
            context.getSharedPreferences("hairplnmo", Context.MODE_PRIVATE)
                .getStringSet("issued_purchases", emptySet()) ?: emptySet()
        )
    }
    var records by remember {
        mutableStateOf(
            context.getSharedPreferences("hairplnmo", Context.MODE_PRIVATE)
                .getStringSet("purchase_records", emptySet()) ?: emptySet()
        )
    }
    var tab by remember { mutableStateOf(initialTab) }
    var copied by remember { mutableStateOf("") }
    var syncing by remember { mutableStateOf(true) }
    fun reloadCloud() {
        val sp = context.getSharedPreferences("hairplnmo", Context.MODE_PRIVATE)
        issued = sp.getStringSet("issued_keys", emptySet()) ?: emptySet()
        issuedPurchases = sp.getStringSet("issued_purchases", emptySet()) ?: emptySet()
        records = sp.getStringSet("purchase_records", emptySet()) ?: emptySet()
        syncing = false
    }
    LaunchedEffect(Unit) { cloudPullAdmin(context) { reloadCloud() } }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("管理员", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = MainText) },
        text = {
            Column {
                Row {
                    Box(
                        modifier = Modifier
                            .background(if (tab == 0) AccentColor else CardColor, RoundedCornerShape(20.dp))
                            .tap { tab = 0 }
                            .padding(horizontal = 14.dp, vertical = 8.dp)
                    ) {
                        Text("1. 未发放", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = if (tab == 0) Color.White else SubText)
                    }
                    Spacer(Modifier.width(6.dp))
                    Box(
                        modifier = Modifier
                            .background(if (tab == 1) AccentColor else CardColor, RoundedCornerShape(20.dp))
                            .tap { tab = 1 }
                            .padding(horizontal = 14.dp, vertical = 8.dp)
                    ) {
                        Text("2. 已发放", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = if (tab == 1) Color.White else SubText)
                    }
                    Spacer(Modifier.width(6.dp))
                    Box(
                        modifier = Modifier
                            .background(if (tab == 2) AccentColor else CardColor, RoundedCornerShape(20.dp))
                            .tap { tab = 2 }
                            .padding(horizontal = 14.dp, vertical = 8.dp)
                    ) {
                        Text("3. 卡密", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = if (tab == 2) Color.White else SubText)
                    }
                }
                Spacer(Modifier.height(12.dp))
                Column(
                    modifier = Modifier
                        .heightIn(max = 360.dp)
                        .verticalScroll(rememberScrollState())
                ) {
                    if (copied.isNotEmpty()) {
                        Text(copied, fontSize = 12.sp, color = Color(0xFF1E9E6A))
                        Spacer(Modifier.height(8.dp))
                    }
                    if (syncing) {
                        Text("云端同步中…", fontSize = 12.sp, color = SubText)
                        Spacer(Modifier.height(8.dp))
                    }
                    if (tab == 0 || tab == 1) {
                        val list = if (tab == 0) records.filter { !issuedPurchases.contains(it) } else records.filter { issuedPurchases.contains(it) }
                        if (list.isEmpty()) {
                            Text(if (tab == 0) "暂无未发放购买" else "暂无已发放购买", fontSize = 14.sp, color = SubText)
                        }
                        list.sortedDescending().forEach { r ->
                            val parts = r.split("|")
                            val time = parts.getOrElse(0) { "" }
                            val account = parts.getOrElse(1) { "" }
                            val amount = parts.getOrElse(2) { "" }
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(CardColor, RoundedCornerShape(14.dp))
                                    .tap {
                                        val next = issuedPurchases.toMutableSet()
                                        if (next.contains(r)) next.remove(r) else next.add(r)
                                        context.getSharedPreferences("hairplnmo", Context.MODE_PRIVATE)
                                            .edit().putStringSet("issued_purchases", next).apply()
                                        issuedPurchases = next
                                        cloudPushAll(context)
                                    }
                                    .padding(horizontal = 16.dp, vertical = 14.dp)
                            ) {
                                Text(account, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = MainText)
                                Spacer(Modifier.height(3.dp))
                                Text("支付 $amount · $time", fontSize = 12.sp, color = SubText)
                            }
                            Spacer(Modifier.height(8.dp))
                        }
                    } else {
                        ValidKeys.forEach { k ->
                            val boundAccount = getKeyBoundAccount(context, k)
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(CardColor, RoundedCornerShape(14.dp))
                                    .tap {
                                        val next = issued.toMutableSet()
                                        if (next.contains(k)) next.remove(k) else next.add(k)
                                        context.getSharedPreferences("hairplnmo", Context.MODE_PRIVATE)
                                            .edit().putStringSet("issued_keys", next).apply()
                                        issued = next
                                        cloudPushAll(context)
                                    }
                                    .padding(horizontal = 16.dp, vertical = 14.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(Modifier.weight(1f)) {
                                    Text(k, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = MainText)
                                    if (boundAccount != null) {
                                        Spacer(Modifier.height(3.dp))
                                        Text("绑定账号：$boundAccount", fontSize = 12.sp, color = Color(0xFF3B5BDB))
                                    }
                                }
                                Icon(
                                    Icons.Filled.ContentCopy,
                                    contentDescription = "复制",
                                    tint = SubText,
                                    modifier = Modifier
                                        .size(20.dp)
                                        .tap {
                                            clipboard.setText(AnnotatedString(k))
                                            copied = "已复制到剪贴板：$k"
                                        }
                                )
                                Spacer(Modifier.width(12.dp))
                                Text(
                                    if (issued.contains(k)) "已发放" else "未发放",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (issued.contains(k)) Color(0xFFD0453E) else Color(0xFF1E9E6A)
                                )
                            }
                            Spacer(Modifier.height(8.dp))
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) { Text("关闭", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = AccentColor) }
        }
    )
}

@Composable
fun OrdersDialog(currentUser: String, onDismiss: () -> Unit) {
    val context = LocalContext.current
    val sp = context.getSharedPreferences("hairplnmo", Context.MODE_PRIVATE)
    var records by remember {
        mutableStateOf(sp.getStringSet("purchase_records", emptySet()) ?: emptySet())
    }
    LaunchedEffect(Unit) { cloudPullAdmin(context) { records = sp.getStringSet("purchase_records", emptySet()) ?: emptySet() } }
    val nick = getLoggedNick(context)
    val displayName = nick.ifBlank { currentUser }
    val myRecords = records.filter {
        it.split("|").getOrElse(1) { "" } == displayName
    }.sortedDescending()
    val binds = sp.getStringSet("bindings", emptySet()) ?: emptySet()
    val bindingTimes = sp.getStringSet("binding_times", emptySet()) ?: emptySet()
    val hasKey = binds.any { it.substringAfter('|') == currentUser }
    val keyTime = bindingTimes.firstOrNull { it.substringAfter('|').substringBefore('|') == currentUser }
        ?.substringAfter('|')?.substringAfter('|')
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("我的订单", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = MainText) },
        text = {
            Column(
                modifier = Modifier
                    .heightIn(max = 360.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                if (myRecords.isEmpty()) {
                    Text("暂无订单", fontSize = 14.sp, color = SubText)
                }
                myRecords.forEach { r ->
                    val parts = r.split("|")
                    val time = parts.getOrElse(0) { "" }
                    val name = parts.getOrElse(1) { "" }
                    val amount = parts.getOrElse(2) { "" }
                    val content = parts.getOrElse(3) { "高级版" }
                    val completed = isOrderCompleted(context, r)
                    val completeTime = getOrderCompleteTime(context, r)
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(CardColor, RoundedCornerShape(14.dp))
                            .padding(horizontal = 16.dp, vertical = 14.dp)
                    ) {
                        Text("名称：$name", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = MainText)
                        Spacer(Modifier.height(3.dp))
                        Text("账号：$currentUser", fontSize = 12.sp, color = SubText)
                        Spacer(Modifier.height(3.dp))
                        Text("时间：$time", fontSize = 12.sp, color = SubText)
                        Spacer(Modifier.height(3.dp))
                        Text("内容：$content", fontSize = 12.sp, color = SubText)
                        Spacer(Modifier.height(3.dp))
                        Text("支付：$amount", fontSize = 12.sp, color = SubText)
                        Spacer(Modifier.height(6.dp))
                        Text(
                            "${if (completed) "已完成" else "未完成"}，卡密:${if (hasKey) "已发" else "未发"}",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (completed) Color(0xFF1E9E6A) else Color(0xFFD0453E)
                        )
                        if (completed && completeTime != null) {
                            Spacer(Modifier.height(3.dp))
                            Text("完成时间：$completeTime", fontSize = 12.sp, color = SubText)
                        }
                        if (hasKey && keyTime != null) {
                            Spacer(Modifier.height(3.dp))
                            Text("发卡密时间：$keyTime", fontSize = 12.sp, color = SubText)
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) { Text("关闭", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = AccentColor) }
        }
    )
}

@Composable
fun LoadingScreen(onDone: () -> Unit) {
    LaunchedEffect(Unit) {
        delay(1800)
        onDone()
    }
    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            CircularProgressIndicator(color = AccentColor)
            Spacer(Modifier.height(16.dp))
            Text("加载中…", fontSize = 14.sp, color = SubText)
        }
    }
}

@Composable
fun HomeScreen(
    currentUser: String,
    showPremiumPopup: Boolean,
    onDismissPremiumPopup: () -> Unit,
    onPremium: () -> Unit,
    onLogout: () -> Unit,
    onBuy: () -> Unit
) {
    var menuOpen by remember { mutableStateOf(false) }
    var showAccountInfo by remember { mutableStateOf(false) }
    var showAdminDialog by remember { mutableStateOf(false) }
    var adminTab by remember { mutableStateOf(0) }
    var showOrdersDialog by remember { mutableStateOf(false) }
    var showLogoutConfirm by remember { mutableStateOf(false) }
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFF2F0EB))
            .verticalScroll(rememberScrollState())
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(44.dp)
                    .background(Color(0xFF1C1C1E), RoundedCornerShape(12.dp)),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Filled.Build, contentDescription = null, tint = Color.White, modifier = Modifier.size(22.dp))
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text("HAirPLNmo", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = MainText)
                Spacer(Modifier.height(2.dp))
                Text("本地工具箱", fontSize = 12.sp, color = SubText)
            }
            Box(
                modifier = Modifier
                    .background(Color(0xFFC9EEDC), RoundedCornerShape(999.dp))
                    .padding(horizontal = 12.dp, vertical = 5.dp)
            ) {
                Text("免费版", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color(0xFF1E9E6A))
            }
            Spacer(Modifier.width(10.dp))
            Box {
                Icon(
                    Icons.Filled.MoreVert,
                    contentDescription = null,
                    tint = MainText,
                    modifier = Modifier.clickable { menuOpen = true }
                )
                DropdownMenu(
                    expanded = menuOpen,
                    onDismissRequest = { menuOpen = false },
                    shape = RoundedCornerShape(16.dp)
                ) {
                    DropdownMenuItem(
                        text = { Text("1. 账号信息", fontSize = 15.sp, color = MainText) },
                        onClick = {
                            menuOpen = false
                            showAccountInfo = true
                        }
                    )
                    DropdownMenuItem(
                        text = { Text("2. 高级版", fontSize = 15.sp, color = MainText) },
                        onClick = {
                            menuOpen = false
                            onPremium()
                        }
                    )
                    DropdownMenuItem(
                        text = { Text("3. 订单", fontSize = 15.sp, color = MainText) },
                        onClick = {
                            menuOpen = false
                            showOrdersDialog = true
                        }
                    )
                    if (currentUser == AdminUser) {
                        DropdownMenuItem(
                            text = { Text("4. 管理", fontSize = 15.sp, color = MainText) },
                            onClick = {
                                menuOpen = false
                                adminTab = 0
                                showAdminDialog = true
                            }
                        )
                    }
                    DropdownMenuItem(
                        text = { Text(if (currentUser == AdminUser) "5. 退出登录" else "4. 退出登录", fontSize = 15.sp, color = Color(0xFFD0453E)) },
                        onClick = {
                            menuOpen = false
                            showLogoutConfirm = true
                        }
                    )
                }
            }
        }
        Column(Modifier.padding(horizontal = 20.dp)) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color.White, RoundedCornerShape(20.dp))
                    .padding(20.dp)
            ) {
                Text("欢迎使用", fontSize = 13.sp, color = SubText)
                Spacer(Modifier.height(6.dp))
                Text("HAirPLNmo 免费版", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = MainText)
                Spacer(Modifier.height(8.dp))
                Text(
                    "常用工具正在陆续恢复中，敬请期待更多功能。",
                    fontSize = 14.sp,
                    color = Color(0xFF5A5F6B),
                    lineHeight = 22.sp
                )
            }
            Spacer(Modifier.height(24.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("工具", fontSize = 17.sp, fontWeight = FontWeight.Bold, color = MainText, modifier = Modifier.weight(1f))
                Text("开发中", fontSize = 13.sp, color = SubText)
            }
            Spacer(Modifier.height(14.dp))
            Row(Modifier.fillMaxWidth()) {
                ToolCard("哈希工具", "计算各类哈希值", Icons.Filled.Tag, Modifier.weight(1f))
                Spacer(Modifier.width(14.dp))
                ToolCard("文件修改器", "查找、替换、定位", Icons.Filled.EditNote, Modifier.weight(1f))
            }
            Spacer(Modifier.height(14.dp))
            Row(Modifier.fillMaxWidth()) {
                ToolCard("打包工具", "极速打包安装包", Icons.Filled.Inventory2, Modifier.weight(1f))
                Spacer(Modifier.width(14.dp))
                ToolCard("APK 分析", "安装包信息解析", Icons.Filled.Brush, Modifier.weight(1f))
            }
            Spacer(Modifier.height(14.dp))
            Row(Modifier.fillMaxWidth()) {
                ToolCard("加密工具", "加盐哈希与乱码", Icons.Filled.VerifiedUser, Modifier.weight(1f))
                Spacer(Modifier.width(14.dp))
                ToolCard("更多工具", "陆续上架中", Icons.Filled.Apps, Modifier.weight(1f))
            }
            Spacer(Modifier.height(28.dp))
            Text(
                "HAirPLNmo · 免费版",
                fontSize = 12.sp,
                color = Color(0xFFB9B4AA),
                modifier = Modifier.fillMaxWidth(),
                textAlign = TextAlign.Center
            )
            Spacer(Modifier.height(20.dp))
        }
    }
    if (showPremiumPopup) {
        PremiumPopup(onDismiss = onDismissPremiumPopup, onBuy = onBuy, currentUser = currentUser)
    }
    if (showAccountInfo) {
        val context = LocalContext.current
        AlertDialog(
            onDismissRequest = { showAccountInfo = false },
            title = { Text("账号信息", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = MainText) },
            text = {
                Column {
                    Text("账号：$currentUser", fontSize = 15.sp, color = MainText)
                    Spacer(Modifier.height(6.dp))
                    val nick = getLoggedNick(context)
                    Text("昵称：${nick.ifBlank { "未设置" }}", fontSize = 15.sp, color = MainText)
                }
            },
            confirmButton = {
                TextButton(onClick = { showAccountInfo = false }) { Text("确定", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = AccentColor) }
            }
        )
    }
    if (showLogoutConfirm) {
        AlertDialog(
            onDismissRequest = { showLogoutConfirm = false },
            title = { Text("退出登录", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = MainText) },
            text = { Text("确定退出登录吗？", fontSize = 14.sp, color = SubText) },
            confirmButton = {
                TextButton(onClick = {
                    showLogoutConfirm = false
                    onLogout()
                }) { Text("确定", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = Color(0xFFD0453E)) }
            },
            dismissButton = {
                TextButton(onClick = { showLogoutConfirm = false }) { Text("取消", fontSize = 15.sp, color = SubText) }
            }
        )
    }
    if (showAdminDialog) {
        AdminDialog(initialTab = adminTab, onDismiss = { showAdminDialog = false })
    }
    if (showOrdersDialog) {
        OrdersDialog(currentUser = currentUser, onDismiss = { showOrdersDialog = false })
    }
}

@Composable
fun PremiumPopup(onDismiss: () -> Unit, onBuy: () -> Unit, currentUser: String) {
    val context = LocalContext.current
    var key by remember { mutableStateOf("") }
    var msg by remember { mutableStateOf("") }
    var msgColor by remember { mutableStateOf(AccentColor) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("高级版", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = MainText) },
        text = {
            Column {
                FloatField(
                    value = key,
                    onValueChange = {
                        key = it
                        msg = ""
                    },
                    label = "输入卡密",
                    modifier = Modifier.fillMaxWidth()
                )
                if (msg.isNotEmpty()) {
                    Spacer(Modifier.height(10.dp))
                    Text(msg, fontSize = 13.sp, color = msgColor, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
                }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val input = key.trim().uppercase()
                val boundAccount = getKeyBoundAccount(context, input)
                when {
                    key.isBlank() -> {
                        msg = "请输入卡密"
                        msgColor = AccentColor
                    }
                    !ValidKeys.contains(input) -> {
                        msg = "卡密无效"
                        msgColor = AccentColor
                    }
                    boundAccount != null && boundAccount != currentUser -> {
                        msg = "该卡密已绑定其他账号"
                        msgColor = Color(0xFFD0453E)
                    }
                    isKeyUsed(context, input) -> {
                        msg = "该卡密已被使用"
                        msgColor = Color(0xFFD0453E)
                    }
                    else -> {
                        if (boundAccount == null) bindKey(context, input, currentUser)
                        msg = "卡密正确，已绑定本账号并解锁高级版"
                        msgColor = Color(0xFF1E9E6A)
                    }
                }
            }) { Text("确定", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = AccentColor) }
        },
        dismissButton = {
            TextButton(onClick = onBuy) { Text("购买卡密", fontSize = 14.sp, color = SubText) }
        }
    )
}

@Composable
fun ToolCard(title: String, sub: String, icon: ImageVector, modifier: Modifier = Modifier) {
    Column(
        modifier = modifier
            .background(Color.White, RoundedCornerShape(18.dp))
            .padding(16.dp)
    ) {
        Box(
            modifier = Modifier
                .size(48.dp)
                .background(Color(0xFFF0EEE8), RoundedCornerShape(14.dp)),
            contentAlignment = Alignment.Center
        ) {
            Icon(icon, contentDescription = null, tint = Color(0xFF3A3F4A), modifier = Modifier.size(24.dp))
        }
        Spacer(Modifier.height(12.dp))
        Text(title, fontSize = 16.sp, fontWeight = FontWeight.Bold, color = MainText)
        Spacer(Modifier.height(3.dp))
        Text(sub, fontSize = 12.sp, color = SubText)
        Spacer(Modifier.height(10.dp))
        Box(
            modifier = Modifier
                .background(Color(0xFFEFEDE8), RoundedCornerShape(999.dp))
                .padding(horizontal = 10.dp, vertical = 4.dp)
        ) {
            Text("敬请期待", fontSize = 11.sp, color = Color(0xFF8A8A85))
        }
    }
}
