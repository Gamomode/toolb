(function () {
  'use strict';

  var Store = window.Store;
  var pending = {};
  var seq = 0;
  var socket = null;
  var mode = 'local';

  function buildUrl(cfg) {
    var host = String((cfg && cfg.host) || '').trim();
    if (!host) return '';
    if (/^wss?:\/\//i.test(host)) return host;
    if (/^https?:\/\//i.test(host)) return host.replace(/^http/i, 'ws');
    var port = String((cfg && cfg.port) || '').trim();
    return 'ws://' + host + (port ? ':' + port : '');
  }

  function rejectAll(reason) {
    Object.keys(pending).forEach(function (id) {
      try {
        pending[id].reject(new Error(reason));
      } catch (e) {
        /* 忽略回调异常 */
      }
      delete pending[id];
    });
  }

  function closeSocket() {
    if (socket) {
      try {
        socket.onclose = null;
        socket.close();
      } catch (e) {
        /* 忽略关闭异常 */
      }
      socket = null;
    }
    rejectAll('连接已断开');
  }

  function onMessage(ev) {
    var msg;
    try {
      msg = JSON.parse(ev.data);
    } catch (e) {
      return;
    }
    var p = pending[msg.id];
    if (!p) return;
    delete pending[msg.id];
    if (msg.error) p.reject(new Error(String(msg.error)));
    else p.resolve(msg.result);
  }

  function rpc(method, params) {
    return new Promise(function (resolve, reject) {
      if (!socket || socket.readyState !== 1) {
        reject(new Error('未连接服务器'));
        return;
      }
      var id = 'r' + ++seq;
      pending[id] = { resolve: resolve, reject: reject };
      try {
        socket.send(JSON.stringify({ id: id, method: method, params: params || {} }));
      } catch (e) {
        delete pending[id];
        reject(e);
        return;
      }
      setTimeout(function () {
        if (pending[id]) {
          delete pending[id];
          reject(new Error('请求超时：' + method));
        }
      }, 8000);
    });
  }

  function localList() {
    return Store.get().files.map(function (f) {
      return { path: f.path, size: (f.content || '').length, mtime: f.mtime };
    });
  }

  function localRead(path) {
    var f = Store.findFile(path);
    return f ? f.content : '';
  }

  var Server = {
    isRemote: function () {
      return mode === 'remote' && !!socket && socket.readyState === 1;
    },

    connect: function (cfg) {
      var url = buildUrl(cfg);
      Store.setConnection({
        status: 'connecting',
        host: (cfg && cfg.host) || '',
        port: (cfg && cfg.port) || '',
        token: (cfg && cfg.token) || ''
      });

      if (!url) {
        mode = 'local';
        Store.setConnection({ status: 'local', mode: 'local', lastSync: Date.now(), latency: 0 });
        Store.addLog('未填写地址，使用本地离线镜像', 'warn');
        return Promise.resolve('local');
      }

      Store.addLog('正在连接 ' + url);

      return new Promise(function (resolve) {
        var ws;
        var settled = false;

        function done(ok, note) {
          if (settled) return;
          settled = true;
          if (note) Store.addLog(note, ok ? 'ok' : 'warn');
          resolve(ok ? 'remote' : 'local');
        }

        try {
          ws = new WebSocket(url);
        } catch (e) {
          Store.addLog('连接异常：' + e.message, 'err');
          done(false);
          return;
        }

        var timer = setTimeout(function () {
          try {
            ws.close();
          } catch (e) {
            /* 忽略关闭异常 */
          }
          done(false, '连接超时，切换到离线镜像');
        }, 6000);

        ws.onopen = function () {
          clearTimeout(timer);
          socket = ws;
          mode = 'remote';
          ws.onmessage = onMessage;
          ws.onclose = function () {
            if (socket !== ws) return;
            socket = null;
            mode = 'local';
            Store.setConnection({ status: 'offline', mode: 'local' });
            Store.addLog('服务器连接已断开，切换到离线镜像', 'warn');
          };
          Store.setConnection({ status: 'online', mode: 'remote', lastSync: Date.now() });
          Store.addLog('服务器连接成功：' + url, 'ok');
          Server.ping().then(function (ms) {
            if (ms >= 0) Store.setConnection({ latency: ms });
          });
          done(true);
        };

        ws.onerror = function () {
          clearTimeout(timer);
          done(false, '连接失败，已使用本地离线镜像（功能不受影响）');
        };
      });
    },

    disconnect: function () {
      closeSocket();
      mode = 'local';
      Store.setConnection({ status: 'local', mode: 'local', latency: 0 });
      Store.addLog('已断开连接，使用离线镜像', 'warn');
    },

    list: function () {
      if (!this.isRemote()) return Promise.resolve(localList());
      return rpc('fs.list', {}).then(function (res) {
        var arr = Array.isArray(res) ? res : [];
        return arr.map(function (x) {
          return typeof x === 'string' ? { path: x } : x;
        });
      }).catch(function (e) {
        Store.addLog('远程列目录失败：' + e.message + '，改用本地镜像', 'err');
        return localList();
      });
    },

    read: function (path) {
      if (!this.isRemote()) return Promise.resolve(localRead(path));
      return rpc('fs.read', { path: path }).then(function (res) {
        if (typeof res === 'string') return res;
        return (res && res.content) || '';
      }).catch(function (e) {
        Store.addLog('远程读取失败：' + e.message + '，改用本地副本', 'err');
        return localRead(path);
      });
    },

    write: function (path, content) {
      if (this.isRemote()) {
        rpc('fs.write', { path: path, content: content }).then(function () {
          Store.addLog('已写入服务器：' + path, 'ok');
        }).catch(function (e) {
          Store.addLog('远程写入失败：' + e.message + '，已保存到本地', 'err');
        });
      }
      Store.upsertFile(path, content);
      return Promise.resolve(true);
    },

    ping: function () {
      if (!this.isRemote()) return Promise.resolve(0);
      var t = Date.now();
      return rpc('ping', {}).then(function () {
        return Date.now() - t;
      }).catch(function () {
        return -1;
      });
    }
  };

  window.Server = Server;
})();