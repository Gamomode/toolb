(function () {
  'use strict';

  var Store = window.Store;
  var Server = window.Server;
  var UI = window.UI;
  var Assistant = window.Assistant;

  var GITHUB_URL = 'https://github.com/';

  function esc(s) {
    return String(s == null ? '' : s)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  }

  function ctx() {
    var st = Store.get();
    return { files: st.files, activePath: st.activeFile };
  }

  function syncHeader(st) {
    var c = st.connection;
    if (c.status === 'online') UI.setConn(true, '已连接 ' + (c.host || '') + (c.latency ? ' · ' + c.latency + 'ms' : ''));
    else if (c.status === 'connecting') UI.setConn(false, '连接中…');
    else UI.setConn(false, '离线镜像 · ' + st.files.length + ' 个文件');
  }

  function refresh() {
    var st = Store.get();
    UI.render(st);
    syncHeader(st);
  }

  function showGithubNotice(fileName, count) {
    UI.notice({
      title: '工程包已生成',
      body: '已导出 <span class="nt-path">' + esc(fileName) + '</span>，内含 ' + count + ' 个网页文件与完整的 Gradle 工程。<br><br>' +
        '下一步：打开 <span class="nt-path">' + GITHUB_URL + '</span> 新建一个仓库，把压缩包解压后的文件全部上传。' +
        '仓库自带的 Actions 会自动编译出 APK，构建完成后在 Actions → Artifacts 里下载即可安装到手机。<br><br>' +
        '需要注意：上传时要保留 <span class="nt-path">.github/workflows/build-apk.yml</span>，否则不会自动构建。',
      actions: [
        { label: '前往 GitHub', href: GITHUB_URL, primary: true },
        { label: '稍后再说' }
      ]
    });
  }

  /* ---------- 动作 ---------- */

  var actions = {
    'server-connect': function () {
      var host = document.getElementById('cfg-host');
      var port = document.getElementById('cfg-port');
      var token = document.getElementById('cfg-token');
      Server.connect({
        host: host ? host.value : '',
        port: port ? port.value : '',
        token: token ? token.value : ''
      }).then(function (mode) {
        UI.toast(mode === 'remote' ? '已连接服务器' : '已切换到离线镜像');
      });
    },

    'server-offline': function () {
      Server.disconnect();
      UI.toast('已切换到离线镜像');
    },

    'server-clear': function () {
      Store.clearLogs();
    },

    'file-new': function () {
      var input = document.getElementById('new-path');
      var p = input ? input.value.trim() : '';
      if (!p) {
        UI.toast('请输入文件路径');
        return;
      }
      var path = Store.cleanPath(p);
      if (Store.findFile(path)) {
        UI.openSheet(path, Store.findFile(path).content);
        return;
      }
      Store.upsertFile(path, '');
      Store.setActiveFile(path);
      UI.openSheet(path, '');
    },

    'file-open': function (el) {
      var path = el.getAttribute('data-path');
      var f = Store.findFile(path);
      if (!f) return;
      Store.setActiveFile(path);
      Server.read(path).then(function (content) {
        UI.openSheet(path, content || f.content);
      });
    },

    'file-del': function (el, e) {
      e.stopPropagation();
      var path = el.getAttribute('data-path');
      if (!path) return;
      Store.removeFile(path);
      UI.toast('已删除 ' + path);
    },

    'file-refresh': function () {
      UI.loading(true, '同步中…');
      Server.list().then(function (list) {
        var chain = Promise.resolve();
        (list || []).forEach(function (item) {
          var p = typeof item === 'string' ? item : item.path;
          if (!p || Store.findFile(p)) return;
          chain = chain.then(function () {
            return Server.read(p).then(function (c) {
              Store.upsertFile(p, c || '');
            });
          });
        });
        return chain;
      }).then(function () {
        UI.loading(false);
        UI.toast('同步完成');
      }).catch(function (err) {
        UI.loading(false);
        UI.toast('同步失败：' + err.message);
      });
    },

    'file-reset': function () {
      Store.reset();
      UI.toast('已恢复示例数据');
    },

    'file-ask': function () {
      var st = Store.get();
      if (!st.activeFile) {
        UI.toast('先选中一个文件');
        return;
      }
      UI.setView('reverse');
      Assistant.send('分析 ' + st.activeFile, ctx());
    },

    'chat-quick': function (el) {
      Assistant.send(el.getAttribute('data-q'), ctx());
    },

    'chat-send': function () {
      var box = document.getElementById('chat-text');
      if (!box) return;
      var text = box.value.trim();
      if (!text) return;
      box.value = '';
      Assistant.send(text, ctx());
    },

    'chat-clear': function () {
      Assistant.clear();
      UI.toast('对话已清空');
    },

    'ai-config': function () {
      var url = document.getElementById('ai-url');
      var key = document.getElementById('ai-key');
      var model = document.getElementById('ai-model');
      Assistant.setConfig({
        url: url ? url.value.trim() : '',
        key: key ? key.value.trim() : '',
        model: model ? model.value.trim() : 'gpt-4o-mini'
      });
      UI.toast('配置已保存');
    },

    'ai-action': function (el) {
      var msgs = Assistant.getMessages();
      var m = msgs[parseInt(el.getAttribute('data-mi'), 10)];
      if (!m || !m.actions) return;
      var act = m.actions[parseInt(el.getAttribute('data-ai'), 10)];
      if (!act) return;

      if (act.type === 'apply-file') {
        Server.write(act.path, act.content).then(function () {
          UI.toast('已应用修改：' + act.path);
          refresh();
        });
      } else if (act.type === 'apply-many') {
        (act.files || []).forEach(function (f) {
          Store.upsertFile(f.path, f.content);
        });
        UI.toast('已应用 ' + (act.files || []).length + ' 个文件');
      }
    },

    'reanalyze': function () {
      var st = Store.get();
      Store.setReport(window.AI.analyze(st.files));
      UI.toast('分析完成');
    },

    'offline-all': function () {
      var st = Store.get();
      var built = window.Exporter.buildOffline(st.files);
      built.files.forEach(function (f) {
        Store.upsertFile(f.path, f.content);
      });
      (built.extras || []).forEach(function (f) {
        if (!Store.findFile(f.path)) Store.upsertFile(f.path, f.content);
      });
      Store.setReport(built.report);
      UI.toast('已离线化 ' + built.entries.length + ' 条外链');
    },

    'export-offline': function () {
      var st = Store.get();
      var built = window.Exporter.buildOffline(st.files);
      var all = built.files.concat(built.extras || []);
      UI.loading(true, '打包中…');
      window.Exporter.zipOf(all).then(function (blob) {
        return window.Exporter.saveBlob(blob, 'offline-site.zip');
      }).then(function (how) {
        UI.loading(false);
        UI.toast(how === 'share' ? '已调起系统分享' : how === 'cancel' ? '已取消' : '已开始下载');
      }).catch(function (err) {
        UI.loading(false);
        UI.toast('打包失败：' + err.message);
      });
    },

    'export-raw': function () {
      var st = Store.get();
      UI.loading(true, '打包中…');
      window.Exporter.zipOf(st.files).then(function (blob) {
        return window.Exporter.saveBlob(blob, 'workspace.zip');
      }).then(function () {
        UI.loading(false);
        UI.toast('已导出原始文件');
      }).catch(function (err) {
        UI.loading(false);
        UI.toast('打包失败：' + err.message);
      });
    },

    'export-report': function () {
      var st = Store.get();
      var report = window.AI.analyze(st.files);
      var md = window.AI.markdown(report, st.files);
      var blob = new Blob([md], { type: 'text/markdown;charset=utf-8' });
      window.Exporter.saveBlob(blob, 'reverse-report.md').then(function () {
        UI.toast('报告已导出');
      });
    },

    'apk-build': function () {
      var name = document.getElementById('apk-name');
      var pkg = document.getElementById('apk-pkg');
      var ver = document.getElementById('apk-ver');
      var code = document.getElementById('apk-code');

      var cfg = {
        appName: name ? name.value.trim() : '',
        packageName: pkg ? pkg.value.trim() : '',
        versionName: ver ? ver.value.trim() : '1.0.0',
        versionCode: code ? code.value : 1
      };

      Store.setApk(cfg);
      UI.loading(true, '生成 HAirPLNmo.zip…');

      window.Apk.build(cfg).then(function (res) {
        return window.Exporter.saveBlob(res.blob, res.name).then(function (how) {
          UI.loading(false);
          if (how === 'cancel') {
            UI.toast('已取消');
            return;
          }
          UI.toast('已生成 ' + res.name);
          showGithubNotice(res.name, res.files);
        });
      }).catch(function (err) {
        UI.loading(false);
        UI.toast('生成失败：' + err.message);
      });
    },

    'apk-pwa': function () {
      UI.toast('浏览器菜单 → 添加到主屏幕，即可离线使用');
    },

    'apk-github': function () {
      showGithubNotice(window.Apk ? window.Apk.outputName : 'HAirPLNmo.zip', Store.get().files.length);
    }
  };

  /* ---------- 事件绑定 ---------- */

  document.addEventListener('click', function (e) {
    var tab = e.target.closest('.tab');
    if (tab) {
      UI.setView(tab.getAttribute('data-view'));
      refresh();
      return;
    }

    var el = e.target.closest('[data-act]');
    if (!el) return;
    var fn = actions[el.getAttribute('data-act')];
    if (fn) fn(el, e);
  });

  document.getElementById('sheet-close').addEventListener('click', function () {
    UI.closeSheet();
  });

  document.getElementById('sheet-save').addEventListener('click', function () {
    var editor = document.getElementById('sheet-editor');
    var path = UI.sheetPath();
    if (!path || !editor) return;
    Server.write(path, editor.value).then(function () {
      UI.closeSheet();
      UI.toast('已保存 ' + path);
    });
  });

  var noticeEl = document.getElementById('notice');
  if (noticeEl) {
    noticeEl.addEventListener('click', function (e) {
      if (e.target === noticeEl) UI.closeNotice();
    });
  }

  /* ---------- 启动 ---------- */

  UI.mount(document.getElementById('view'));
  Store.subscribe(refresh);
  Assistant.subscribe(function () {
    if (UI.view() === 'reverse') refresh();
  });

  refresh();

  if (!Store.get().report) {
    Store.setReport(window.AI.analyze(Store.get().files));
  }

  if ('serviceWorker' in navigator && location.protocol.indexOf('http') === 0) {
    navigator.serviceWorker.register('sw.js').catch(function () {
      /* 注册失败不影响使用 */
    });
  }
})();