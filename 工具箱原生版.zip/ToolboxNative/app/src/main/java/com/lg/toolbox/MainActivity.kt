package com.lg.toolbox

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.MenuBook
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.EnhancedEncryption
import androidx.compose.material.icons.filled.Factory
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Shuffle
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material.icons.filled.Tag
import androidx.compose.material.icons.filled.VpnKey
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

fun Modifier.tap(onClick: () -> Unit): Modifier = composed {
    clickable(
        interactionSource = remember { MutableInteractionSource() },
        indication = ripple(),
        onClick = onClick
    )
}

val FieldShape = RoundedCornerShape(14.dp)

@Composable
fun fieldColors(th: ThemeSpec) = OutlinedTextFieldDefaults.colors(
    focusedBorderColor = th.accent,
    unfocusedBorderColor = th.line,
    focusedContainerColor = th.panel,
    unfocusedContainerColor = th.panel,
    cursorColor = th.accent,
    focusedLabelColor = th.accent,
    unfocusedLabelColor = th.muted,
    focusedTextColor = th.ink,
    unfocusedTextColor = th.ink
)

data class ThemeSpec(
    val name: String,
    val bg: Color,
    val panel: Color,
    val ink: Color,
    val muted: Color,
    val accent: Color,
    val accentSoft: Color,
    val line: Color
)

val THEMES = listOf(
    ThemeSpec("teal", Color(0xFFEAF7F4), Color(0xFFFFFFFF), Color(0xFF12312B), Color(0xFF5C7A73), Color(0xFF0E9F8A), Color(0xFFD7F2EC), Color(0xFFD8E8E4)),
    ThemeSpec("sky", Color(0xFFEAF3FB), Color(0xFFFFFFFF), Color(0xFF12283A), Color(0xFF5A7186), Color(0xFF2B7FD4), Color(0xFFD9EAF8), Color(0xFFD6E4F0)),
    ThemeSpec("violet", Color(0xFFF3EFFB), Color(0xFFFFFFFF), Color(0xFF241A3E), Color(0xFF6B5F8A), Color(0xFF6D4FD0), Color(0xFFE6DFF9), Color(0xFFE0DAF0)),
    ThemeSpec("rose", Color(0xFFFBEEF1), Color(0xFFFFFFFF), Color(0xFF3A1220), Color(0xFF8A5A6B), Color(0xFFD4436E), Color(0xFFF9DCE4), Color(0xFFF0DAE0)),
    ThemeSpec("amber", Color(0xFFFBF3E4), Color(0xFFFFFFFF), Color(0xFF3A2A10), Color(0xFF8A7350), Color(0xFFD08A1F), Color(0xFFF8EAD0), Color(0xFFF0E4CC)),
    ThemeSpec("night", Color(0xFF0F172A), Color(0xFF1B2740), Color(0xFFE2E8F0), Color(0xFF94A3B8), Color(0xFF38BDF8), Color(0xFF23324D), Color(0xFF2C3B5C))
)

data class TabInfo(
    val key: String,
    val title: String,
    val sub: String,
    val need: Level,
    val tag: String?,
    val tagColor: Long
)

val TABS = listOf(
    TabInfo("tutorial", "新手教程", "查看工具箱使用说明", Level.NONE, null, 0),
    TabInfo("convert", "格式转换", "Hex 转 Base64", Level.NORMAL, "普通版", 0xFF2FA46A),
    TabInfo("salt", "加盐慢哈希", "10 万次迭代，抗破解", Level.MID, "中级版", 0xFF2B7FD4),
    TabInfo("hash", "基础哈希计算", "SHA-1 / 256 / 384 / 512", Level.VIP, "高级版", 0xFF6D4FD0),
    TabInfo("garbled", "HTML 转乱码", "实体编码 / 不可逆混淆", Level.PAID, "付费版", 0xFFD08A1F),
    TabInfo("encrypt", "加密网页", "带密码锁的网页", Level.SVIP, "SVIP", 0xFFD4436E),
    TabInfo("fastpack", "高级打包-极速版", "一键极速打包，最少选项", Level.SVIP, "SVIP", 0xFFD4436E),
    TabInfo("analyzer", "APK 分析器", "拆包看清单、权限、签名", Level.SVIP, "SVIP", 0xFFD4436E),
    TabInfo("apkenc", "安装包加密", "给 APK 上密码锁，可还原", Level.NONE, null, 0),
    TabInfo("apkmod", "APK 修改", "改版本号、应用名，重新打包签名", Level.NONE, null, 0),
    TabInfo("fileedit", "文件修改器", "改文本文件，定位密码与解码", Level.NONE, null, 0),
    TabInfo("workshop", "深度重置 APK 工程", "生成极高APK,加密等,打包等", Level.SPECIAL, "特殊", 0xFFB8860B)
)

fun tabInfo(key: String): TabInfo = TABS.first { it.key == key }

fun tabIcon(key: String): ImageVector = when (key) {
    "tutorial" -> Icons.AutoMirrored.Filled.MenuBook
    "convert" -> Icons.Filled.SwapHoriz
    "salt" -> Icons.Filled.VpnKey
    "hash" -> Icons.Filled.Tag
    "garbled" -> Icons.Filled.Shuffle
    "encrypt" -> Icons.Filled.Lock
    "fastpack" -> Icons.Filled.Bolt
    "analyzer" -> Icons.Filled.Search
    "apkenc" -> Icons.Filled.EnhancedEncryption
    "apkmod" -> Icons.Filled.Edit
    "fileedit" -> Icons.Filled.Description
    "workshop" -> Icons.Filled.Factory
    else -> Icons.AutoMirrored.Filled.MenuBook
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val store = Store(this)
        setContent {
            ToolboxApp(store)
        }
    }
}

@Composable
fun ToolboxApp(store: Store) {
    var themeIdx by remember { mutableStateOf(store.themeIndex()) }
    val th = THEMES[themeIdx.coerceIn(0, THEMES.size - 1)]
    var screen by remember { mutableStateOf("tutorial") }
    var userTick by remember { mutableStateOf(0) }
    var clockTick by remember { mutableStateOf(0) }
    var toast by remember { mutableStateOf<String?>(null) }
    var showAuth by remember { mutableStateOf(false) }
    var showShop by remember { mutableStateOf(false) }
    var showTasks by remember { mutableStateOf(false) }
    var showPremium by remember { mutableStateOf(false) }
    var showUserMenu by remember { mutableStateOf(false) }
    var showDelConfirm by remember { mutableStateOf(false) }
    var drawerOpen by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        while (true) {
            kotlinx.coroutines.delay(1000)
            clockTick++
        }
    }
    LaunchedEffect(toast) {
        if (toast != null) {
            kotlinx.coroutines.delay(2200)
            toast = null
        }
    }

    fun notify(msg: String) { toast = msg }

    fun openTab(key: String) {
        val info = tabInfo(key)
        val eff = store.effectiveLevel()
        if (info.need != Level.NONE && eff.weight < info.need.weight) {
            notify("当前身份为「${eff.label}」，请先登录或购买对应权限")
            return
        }
        screen = key
        drawerOpen = false
    }

    val info = tabInfo(screen)

    Box(
        Modifier
            .fillMaxSize()
            .background(th.bg)
    ) {
        Column(Modifier.fillMaxSize()) {
            Surface(color = th.panel, shadowElevation = 2.dp) {
                Row(
                    Modifier
                        .fillMaxWidth()
                        .statusBarsPadding()
                        .padding(horizontal = 14.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        Modifier
                            .size(40.dp)
                            .tap { drawerOpen = true },
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Filled.Menu, null, tint = th.ink, modifier = Modifier.size(24.dp))
                    }
                    Spacer(Modifier.width(6.dp))
                    Column(Modifier.weight(1f)) {
                        Text(info.title, fontSize = 19.sp, fontWeight = FontWeight.Bold, color = th.ink)
                        Text(info.sub, fontSize = 11.sp, color = th.muted)
                    }
                    Text(
                        "$" + "%.2f".format(store.balance()),
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                        modifier = Modifier
                            .background(th.accent, RoundedCornerShape(999.dp))
                            .tap { showTasks = true }
                            .padding(horizontal = 12.dp, vertical = 6.dp)
                    )
                }
            }

            Box(Modifier.weight(1f)) {
                AnimatedContent(
                    targetState = screen,
                    transitionSpec = {
                        (slideInHorizontally(tween(220)) { it / 8 } + fadeIn(tween(220)))
                            .togetherWith(slideOutHorizontally(tween(220)) { -it / 8 } + fadeOut(tween(220)))
                    },
                    label = "page"
                ) { s ->
                    when (s) {
                        "hash" -> ToolScreen(th, store, ToolKind.HASH) { notify(it) }
                        "salt" -> ToolScreen(th, store, ToolKind.SALT) { notify(it) }
                        "convert" -> ToolScreen(th, store, ToolKind.CONVERT) { notify(it) }
                        "encrypt" -> ToolScreen(th, store, ToolKind.ENCRYPT) { notify(it) }
                        "garbled" -> ToolScreen(th, store, ToolKind.GARBLED) { notify(it) }
                        "analyzer" -> AnalyzerScreen(th) { notify(it) }
                        "apkenc" -> ApkEncScreen(th) { notify(it) }
                        "apkmod" -> ApkModScreen(th) { notify(it) }
                        "fileedit" -> FileEditScreen(th) { notify(it) }
                        "fastpack" -> FastpackScreen(th) { notify(it) }
                        "workshop" -> WorkshopScreen(th) { notify(it) }
                        else -> TutorialScreen(th)
                    }
                }
            }
        }

        if (drawerOpen) {
            Box(
                Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.4f))
                    .tap { drawerOpen = false }
            )
            Surface(
                color = th.panel,
                modifier = Modifier
                    .fillMaxHeight()
                    .fillMaxWidth(0.86f)
            ) {
                Column(
                    Modifier
                        .fillMaxSize()
                        .verticalScroll(rememberScrollState())
                        .padding(16.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            Modifier
                                .size(44.dp)
                                .background(th.accentSoft, RoundedCornerShape(14.dp)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Filled.Build, null, tint = th.accent, modifier = Modifier.size(22.dp))
                        }
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text("工具箱", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = th.ink)
                            Text("v2.1 · 原生版", fontSize = 11.sp, color = th.muted)
                        }
                        Box(
                            Modifier
                                .size(36.dp)
                                .tap { drawerOpen = false },
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Filled.Close, null, tint = th.muted, modifier = Modifier.size(22.dp))
                        }
                    }
                    Spacer(Modifier.height(14.dp))
                    DrawerRow(Icons.Filled.Star, "高级版", "工具箱 · 新手教程", "下载", 0xFFFBBF24, th, iconTint = Color(0xFFFBBF24)) {
                        showPremium = true
                        drawerOpen = false
                    }
                    TABS.forEach { t ->
                        DrawerRow(tabIcon(t.key), t.title, t.sub, t.tag, t.tagColor, th, selected = t.key == info.key) { openTab(t.key) }
                    }
                    if (store.currentUser != null) {
                        Spacer(Modifier.height(14.dp))
                        Text("我的订单（实时倒计时）", fontSize = 12.sp, color = th.muted)
                        Spacer(Modifier.height(6.dp))
                        clockTick
                        Text(
                            store.ordersText(),
                            fontSize = 12.sp,
                            color = th.ink,
                            lineHeight = 19.sp
                        )
                    }
                    Spacer(Modifier.height(14.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            Modifier
                                .size(34.dp)
                                .background(th.accentSoft, CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            if (store.currentUser == null) {
                                Icon(Icons.Filled.Person, null, tint = th.accent, modifier = Modifier.size(18.dp))
                            } else {
                                Text(
                                    store.currentUser!!.substring(0, 1),
                                    fontSize = 15.sp,
                                    color = th.accent,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                        Spacer(Modifier.width(10.dp))
                        Text(
                            store.maskedUser(),
                            fontSize = 14.sp,
                            color = th.ink,
                            modifier = Modifier
                                .weight(1f)
                                .tap {
                                    if (store.currentUser == null) showAuth = true else showUserMenu = true
                                }
                        )
                        if (store.currentUser != null) {
                            Text(
                                "升级",
                                fontSize = 12.sp,
                                color = Color.White,
                                modifier = Modifier
                                    .background(th.accent, RoundedCornerShape(999.dp))
                                    .tap {
                                        showShop = true
                                        drawerOpen = false
                                    }
                                    .padding(horizontal = 12.dp, vertical = 5.dp)
                            )
                            Spacer(Modifier.width(8.dp))
                            Box(
                                Modifier
                                    .size(32.dp)
                                    .tap { showUserMenu = true },
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(Icons.Filled.MoreVert, null, tint = th.ink, modifier = Modifier.size(20.dp))
                            }
                        }
                    }
                    Spacer(Modifier.height(18.dp))
                    Text("背景颜色", fontSize = 12.sp, color = th.muted)
                    Spacer(Modifier.height(8.dp))
                    Row {
                        THEMES.forEachIndexed { i, t ->
                            Box(
                                Modifier
                                    .padding(end = 10.dp)
                                    .size(30.dp)
                                    .background(
                                        Brush.linearGradient(listOf(t.accent, t.accent.copy(alpha = 0.6f))),
                                        CircleShape
                                    )
                                    .border(
                                        width = if (i == themeIdx) 3.dp else 1.dp,
                                        color = if (i == themeIdx) th.ink else th.line,
                                        shape = CircleShape
                                    )
                                    .tap {
                                        themeIdx = i
                                        store.setThemeIndex(i)
                                    }
                            )
                        }
                    }
                    Spacer(Modifier.height(20.dp))
                }
            }
        }

        if (showAuth) {
            AuthDialog(th, store, onClose = { showAuth = false }, onDone = {
                showAuth = false
                userTick++
                notify(it)
            })
        }
        if (showShop) {
            ShopDialog(th, store, onClose = { showShop = false }, notify = { notify(it); userTick++ })
        }
        if (showTasks) {
            TasksDialog(th, store, onClose = { showTasks = false }, notify = { notify(it); userTick++ })
        }
        if (showPremium) {
            PremiumDialog(th, store, onClose = { showPremium = false }, notify = { notify(it) })
        }
        if (showUserMenu) {
            AlertDialog(
                onDismissRequest = { showUserMenu = false },
                containerColor = th.panel,
                title = { Text("账号", color = th.ink, fontWeight = FontWeight.Bold) },
                text = { Text(store.maskedUser(), color = th.muted) },
                confirmButton = {
                    TextButton(onClick = {
                        showUserMenu = false
                        store.logout()
                        userTick++
                        notify("已退出登录")
                    }) { Text("退出登录", color = Color(0xFFE5484D)) }
                },
                dismissButton = {
                    TextButton(onClick = { showUserMenu = false; showDelConfirm = true }) { Text("注销账号", color = th.muted) }
                }
            )
        }
        if (showDelConfirm) {
            AlertDialog(
                onDismissRequest = { showDelConfirm = false },
                containerColor = th.panel,
                title = { Text("注销账号", color = th.ink, fontWeight = FontWeight.Bold) },
                text = { Text("将删除该账号的全部数据（订单、余额、任务记录），且无法恢复。确定注销吗？", color = th.muted) },
                confirmButton = {
                    TextButton(onClick = {
                        showDelConfirm = false
                        store.deleteAccount()
                        userTick++
                        notify("账号已注销")
                    }) { Text("确定注销", color = Color(0xFFE5484D)) }
                },
                dismissButton = {
                    TextButton(onClick = { showDelConfirm = false }) { Text("取消", color = th.muted) }
                }
            )
        }

        toast?.let { msg ->
            Box(
                Modifier
                    .align(Alignment.BottomCenter)
                    .padding(bottom = 40.dp)
                    .background(Color(0xFF141923).copy(alpha = 0.92f), RoundedCornerShape(999.dp))
                    .padding(horizontal = 20.dp, vertical = 10.dp)
            ) {
                Text(msg, color = Color.White, fontSize = 14.sp)
            }
        }
    }
}

@Composable
fun DrawerRow(icon: ImageVector, title: String, sub: String, tag: String?, tagColor: Long, th: ThemeSpec, strike: Boolean = false, selected: Boolean = false, iconTint: Color? = null, onClick: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(vertical = 3.dp)
            .background(if (selected) th.accentSoft else Color.Transparent, RoundedCornerShape(16.dp))
            .tap { onClick() }
            .padding(horizontal = 10.dp, vertical = 9.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier
                .size(38.dp)
                .background(th.bg, RoundedCornerShape(12.dp)),
            contentAlignment = Alignment.Center
        ) {
            Icon(icon, null, tint = iconTint ?: th.accent, modifier = Modifier.size(20.dp))
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(
                title,
                fontSize = 15.sp,
                fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
                color = if (selected) th.accent else th.ink,
                textDecoration = if (strike) TextDecoration.LineThrough else null
            )
            Text(
                sub,
                fontSize = 11.sp,
                color = th.muted,
                textDecoration = if (strike) TextDecoration.LineThrough else null
            )
        }
        if (tag != null) {
            Text(
                tag,
                fontSize = 10.sp,
                color = Color.White,
                modifier = Modifier
                    .background(Color(tagColor), RoundedCornerShape(999.dp))
                    .padding(horizontal = 8.dp, vertical = 3.dp)
            )
        }
    }
}

@Composable
fun AuthDialog(th: ThemeSpec, store: Store, onClose: () -> Unit, onDone: (String) -> Unit) {
    var isLogin by remember { mutableStateOf(true) }
    var phone by remember { mutableStateOf("") }
    var pwd by remember { mutableStateOf("") }
    var err by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onClose,
        containerColor = th.panel,
        title = { Text(if (isLogin) "登录" else "注册账号", color = th.ink, fontWeight = FontWeight.Bold) },
        text = {
            Column {
                OutlinedTextField(shape = FieldShape, colors = fieldColors(th), 
                    value = phone,
                    onValueChange = { phone = it },
                    label = { Text("手机号") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(10.dp))
                OutlinedTextField(shape = FieldShape, colors = fieldColors(th), 
                    value = pwd,
                    onValueChange = { pwd = it },
                    label = { Text("密码（至少 6 位）") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(8.dp))
                err?.let {
                    Text(it, color = Color(0xFFE5484D), fontSize = 13.sp)
                    Spacer(Modifier.height(4.dp))
                }
                Text(
                    if (isLogin) "还没有账号？去注册" else "已有账号？去登录",
                    fontSize = 13.sp,
                    color = th.accent,
                    modifier = Modifier
                        .tap { isLogin = !isLogin; err = null }
                        .padding(vertical = 6.dp)
                )
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val e = if (isLogin) store.login(phone.trim(), pwd.trim()) else store.register(phone.trim(), pwd.trim())
                if (e != null) err = e
                else onDone(if (isLogin) "登录成功" else "注册成功，已自动登录")
            }) { Text(if (isLogin) "登 录" else "注 册", color = th.accent, fontWeight = FontWeight.Bold) }
        },
        dismissButton = {
            TextButton(onClick = onClose) { Text("取消", color = th.muted) }
        }
    )
}

@Composable
fun TutorialScreen(th: ThemeSpec) {
    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        Box(
            Modifier
                .fillMaxWidth()
                .background(th.accentSoft, RoundedCornerShape(20.dp))
                .padding(14.dp)
        ) {
            Column {
                TyperWelcome(th)
                Spacer(Modifier.height(6.dp))
                Text(
                    "所有功能均在您的设备本地运行，不上传任何数据，极致保护隐私。",
                    fontSize = 13.sp,
                    color = th.muted,
                    lineHeight = 21.sp
                )
            }
        }
        Spacer(Modifier.height(14.dp))
        TutorialPanel("💰 赚取积分与开通权限", "点击右上角的金额按钮即可打开「任务中心」。完成每日签到、体验功能等任务可免费领取余额。\n攒够余额后，在侧边栏底部点击「升级」按钮进入购买中心，购买对应权限即可解锁高级工具。", th)
        TutorialPanel("🔧 主要功能说明", "· 基础哈希 / 格式转换：日常开发中常用的数据摘要与编码转换工具。\n· 加密网页：给网页或文本加一层密码锁，只有输入正确密码才能查看。\n· 高级打包-极速版：贴上网页一键出包，最快最简。\n· 深度重置 APK 工程：可加锁、转乱码、改包名、选图标、加权限的完整打包。\n· APK 分析器：把安装包选进来，直接查看清单、权限和包内文件。", th)
        TutorialPanel("关于", "该应用不适合用于做别的或做敏感信息，请勿转发，盗版必究。\n生效时间：2026年11月21日 · 结束时间：长期有效", th)
        Spacer(Modifier.height(30.dp))
    }
}

@Composable
fun TutorialPanel(title: String, body: String, th: ThemeSpec) {
    Box(
        Modifier
            .fillMaxWidth()
            .padding(bottom = 14.dp)
            .background(th.panel, RoundedCornerShape(20.dp))
            .border(1.dp, th.line, RoundedCornerShape(20.dp))
            .padding(16.dp)
    ) {
        Column {
            Text(title, fontSize = 16.sp, fontWeight = FontWeight.Bold, color = th.accent)
            Spacer(Modifier.height(6.dp))
            Text(body, fontSize = 13.sp, color = th.muted, lineHeight = 21.sp)
        }
    }
}

@Composable
fun TyperWelcome(th: ThemeSpec) {
    val texts = listOf(
        "欢迎使用高级版-金城时代，在这里，你会看到功能更多，每一个都有不同的效果，更多功能敬请期待。",
        "Welcome to Premium-Jincheng Era! More features here, each with its own effect. Stay tuned for more.",
        "Добро пожаловать в Премиум-Эпоха Цзиньчэн! Здесь функций больше, и у каждой свой эффект. Ждите новых.",
        "プレミアム版・金城時代へようこそ！ここでは機能がさらに多く、それぞれに異なる効果があります。新機能にご期待ください。",
        "རིམ་པ་མཐོ་བའི་པར་གཞི་-གསེར་གྲོང་དུས་རབས་ལ་དགའ་བསུ་ཞུ། འདིར་ནུས་པ་མང་པོ་ཡོད་ལ། རེ་རེར་ཕན་ནུས་མི་འདྲ་བ་ཡོད། གསར་པ་མུ་མཐུད་སྒུགས།"
    )
    var idx by remember { mutableStateOf(0) }
    var n by remember { mutableStateOf(0) }
    var del by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        while (true) {
            val t = texts[idx]
            if (!del) {
                if (n < t.length) {
                    n++
                    delay(100)
                } else {
                    del = true
                    delay(10000)
                }
            } else {
                if (n > 0) {
                    n--
                    delay(80)
                } else {
                    del = false
                    idx = (idx + 1) % texts.size
                    delay(500)
                }
            }
        }
    }
    val shine = rememberInfiniteTransition(label = "shine")
    val off by shine.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(3000, easing = LinearEasing)),
        label = "off"
    )
    val blink by shine.animateFloat(
        initialValue = 1f,
        targetValue = 0f,
        animationSpec = infiniteRepeatable(tween(500, easing = LinearEasing)),
        label = "blink"
    )
    val brush = Brush.linearGradient(
        listOf(Color(0xFF1A6DFF), Color(0xFF4FACFE), Color(0xFF1A6DFF)),
        start = Offset(off * 400f - 200f, 0f),
        end = Offset(off * 400f + 200f, 0f)
    )
    Column {
        Text(
            buildAnnotatedString {
                withStyle(SpanStyle(brush = brush, fontWeight = FontWeight.Bold)) {
                    append("🏠 欢迎使用本地工具箱！")
                }
            },
            fontSize = 14.sp,
            lineHeight = 21.sp
        )
        Spacer(Modifier.height(6.dp))
        Text(
            buildAnnotatedString {
                withStyle(SpanStyle(brush = brush)) { append(texts[idx].take(n)) }
                withStyle(SpanStyle(brush = brush)) { append("▏") }
            },
            fontSize = 13.sp,
            lineHeight = 21.sp,
            modifier = Modifier.alpha(blink.coerceIn(0.25f, 1f))
        )
    }
}
