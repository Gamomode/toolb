package com.hairplnmo.app

import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.CardGiftcard
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Key
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.composed
import kotlinx.coroutines.delay
import java.security.MessageDigest
import kotlin.system.exitProcess

val BgColor = Color(0xFFF3F5F9)
val CardColor = Color(0xFFFFFFFF)
val AccentColor = Color(0xFF1A6DFF)
val MainText = Color(0xFF1B2230)
val SubText = Color(0xFF7A8499)
val LineColor = Color(0xFFE3E8F0)
val ExpectedSig = "241e92d50251dfce8965c4381888f231fb7a78d67b35ed7ee228a1533b1a1437"

fun Modifier.tap(onClick: () -> Unit): Modifier = composed {
    clickable(interactionSource = remember { MutableInteractionSource() }, indication = null, onClick = onClick)
}

class MainActivity : ComponentActivity() {
    fun isSignatureValid(): Boolean {
        return try {
            val info = packageManager.getPackageInfo(packageName, PackageManager.GET_SIGNATURES)
            val sig = info.signatures?.firstOrNull() ?: return false
            val digest = MessageDigest.getInstance("SHA-256").digest(sig.toByteArray())
            val hex = digest.joinToString("") { "%02x".format(it) }
            hex == ExpectedSig
        } catch (e: Exception) {
            false
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val sigOk = isSignatureValid()
        setContent {
            var stage by remember { mutableStateOf("select") }
            Surface(color = BgColor, modifier = Modifier.fillMaxSize()) {
                if (!sigOk) {
                    TamperScreen(onExit = {
                        finishAffinity()
                        exitProcess(0)
                    })
                } else {
                    when (stage) {
                        "select" -> SelectScreen(onPremium = { stage = "premium" }, onFree = { stage = "loading" })
                        "premium" -> PremiumScreen(onBack = { stage = "select" })
                        "loading" -> LoadingScreen(onDone = { stage = "home" })
                        "home" -> HomeScreen()
                    }
                }
            }
        }
    }
}

@Composable
fun TamperScreen(onExit: () -> Unit) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF1B2230)),
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(28.dp)
                .background(CardColor, RoundedCornerShape(22.dp))
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text("⚠", fontSize = 40.sp)
            Spacer(Modifier.height(12.dp))
            Text("检测到应用被修改", fontSize = 19.sp, fontWeight = FontWeight.Bold, color = MainText)
            Spacer(Modifier.height(8.dp))
            Text(
                "应用的文件或签名已被改动，为保护安全无法继续使用。",
                fontSize = 13.sp,
                color = SubText,
                textAlign = TextAlign.Center,
                lineHeight = 20.sp
            )
            Spacer(Modifier.height(20.dp))
            Button(
                onClick = onExit,
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = AccentColor)
            ) {
                Text("确定", fontSize = 15.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
fun SelectScreen(onPremium: () -> Unit, onFree: () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFFFFFFF))
            .padding(horizontal = 24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Box(
            modifier = Modifier
                .size(64.dp)
                .background(Color(0xFF1C1C1E), RoundedCornerShape(18.dp)),
            contentAlignment = Alignment.Center
        ) {
            Icon(Icons.Filled.Build, contentDescription = null, tint = Color.White, modifier = Modifier.size(30.dp))
        }
        Spacer(Modifier.height(16.dp))
        Text("HAirPLNmo", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = MainText)
        Spacer(Modifier.height(6.dp))
        Text("选择版本，开始使用", fontSize = 14.sp, color = SubText)
        Spacer(Modifier.height(30.dp))
        OptionCard(
            iconBg = Color(0xFFFBEBC4),
            icon = Icons.Filled.Key,
            iconTint = Color(0xFFC98A1E),
            title = "高级版-卡密",
            sub = "输入卡密，解锁完整功能",
            onClick = onPremium
        )
        Spacer(Modifier.height(14.dp))
        OptionCard(
            iconBg = Color(0xFFC9EEDC),
            icon = Icons.Filled.CardGiftcard,
            iconTint = Color(0xFF1E9E6A),
            title = "免费版",
            sub = "无需卡密，加载后进入首页",
            onClick = onFree
        )
    }
}

@Composable
fun OptionCard(
    iconBg: Color,
    icon: ImageVector,
    iconTint: Color,
    title: String,
    sub: String,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .background(Color(0xFFF6F6F4), RoundedCornerShape(18.dp))
            .tap(onClick)
            .padding(16.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .size(52.dp)
                    .background(iconBg, RoundedCornerShape(14.dp)),
                contentAlignment = Alignment.Center
            ) {
                Icon(icon, contentDescription = null, tint = iconTint, modifier = Modifier.size(26.dp))
            }
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(title, fontSize = 16.sp, fontWeight = FontWeight.Bold, color = MainText)
                Spacer(Modifier.height(3.dp))
                Text(sub, fontSize = 12.sp, color = SubText)
            }
            Icon(Icons.Filled.ChevronRight, contentDescription = null, tint = Color(0xFFB9BEC9))
        }
    }
}

@Composable
fun PremiumScreen(onBack: () -> Unit) {
    var key by remember { mutableStateOf("") }
    var msg by remember { mutableStateOf("") }
    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(28.dp)
                .background(CardColor, RoundedCornerShape(22.dp))
                .padding(22.dp)
        ) {
            TextButton(onClick = onBack, contentPadding = PaddingValues(0.dp)) {
                Text("← 返回", fontSize = 14.sp, color = SubText)
            }
            Spacer(Modifier.height(8.dp))
            Text("请输入卡密以解锁", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = MainText)
            Spacer(Modifier.height(18.dp))
            OutlinedTextField(
                value = key,
                onValueChange = {
                    key = it
                    msg = ""
                },
                modifier = Modifier.fillMaxWidth(),
                placeholder = { Text("输入卡密", fontSize = 14.sp, color = SubText) },
                singleLine = true,
                shape = RoundedCornerShape(12.dp)
            )
            Spacer(Modifier.height(16.dp))
            Button(
                onClick = { msg = "敬请期待" },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = AccentColor)
            ) {
                Text("确定", fontSize = 15.sp, fontWeight = FontWeight.Bold)
            }
            if (msg.isNotEmpty()) {
                Spacer(Modifier.height(12.dp))
                Text(msg, fontSize = 14.sp, color = AccentColor, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
            }
            Spacer(Modifier.height(10.dp))
            TextButton(
                onClick = { },
                modifier = Modifier.fillMaxWidth(),
                contentPadding = PaddingValues(6.dp)
            ) {
                Text("购买卡密", fontSize = 14.sp, color = SubText)
            }
        }
    }
}

@Composable
fun LoadingScreen(onDone: () -> Unit) {
    LaunchedEffect(Unit) {
        delay(1800)
        onDone()
    }
    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            CircularProgressIndicator(color = AccentColor)
            Spacer(Modifier.height(16.dp))
            Text("加载中…", fontSize = 14.sp, color = SubText)
        }
    }
}

@Composable
fun HomeScreen() {
    Column(modifier = Modifier.fillMaxSize()) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(CardColor)
                .padding(vertical = 18.dp, horizontal = 20.dp)
        ) {
            Text("HAirPLNmo", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = MainText)
        }
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("首页", fontSize = 16.sp, color = SubText)
        }
    }
}
